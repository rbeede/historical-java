//==============================================================================
//  CLASSNAME.java -- Rodney Beede -- ##/##/00
//------------------------------------------------------------------------------
//
//  Class Description:
//
//
//
//  Public Variables:  type NAME - description
//
//
//  Public Methods:  return-type NAME  (params) - description
//
//
//  Protected Variables:  (see above)
//
//
//  Protected Methods:  (see above)
//
//
//  Private Variables:  (see above)
//
//
//  Private Methods:  (see above)
//
//
//==============================================================================


// Import
import ;

public CLASSNAME {

	//**********************************************************************
	// Method:  class constructor
	//
	// Preconditions:  PARAMS HERE
	//
	// Postconditions:  None
	//
	// Description:  What this does here
	//
	//**********************************************************************
	public CLASSNAME( params ) {

	}


	//**********************************************************************
	// Method:  NAME
	//
	// Preconditions:  PARAMS HERE
	//
	// Postconditions:  RETURN VALUE HERE
	//
	// Description:  What this does here
	//
	//**********************************************************************
	public type METHODNAME( params ) {

	}

}  //End of CLASSNAME
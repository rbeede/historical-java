// Routines used for testing assertions.  Used in structure package.
// (c) 1998 McGraw-Hill

package structure;

/**
 * A class to manage assertion testing.
 * Assertions (preconditions, postconditions, and others) are tested
 * by verifying a boolean expression, and throwing an error if the
 * expression is false.  A message is provided to describe the condition
 * tested.
 * <p>
 * @version $Id: Assert.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public class Assert
{
    private Assert()
    // pre: An Assert cannot be constructed.
    {
	Assert.fail("Attempt to construct an Assert!?");
    }

    /**
     * Test a precondition.  If the assertion fails the message
     * indicates that a precondition failed.  A precondition is something
     * you require to be true for the method to be executed correctly.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Result of precondition test
     * <dt><b>Postcondition:</b><dd> Does nothing if test true, otherwise abort w/message
     * </dl>
     * 
     * @param test A boolean expression describing precondition.
     * @param message A string describing precondition.
     */
    static public void pre(boolean test, String message)
    // pre: result of precondition test
    // post: does nothing if test true, otherwise abort w/message
    {
	if (test == false) throw new FailedPrecondition(message);
    }

    /**
     * Test a postcondition.  If the assertion fails, the message
     * indicates that a postcondition failed.  A postcondition is
     * something expected to be true after a method invocation,
     * provided the preconditions are met.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Result of postcondition test
     * <dt><b>Postcondition:</b><dd> Does nothing if test true, otherwise abort w/message
     * </dl>
     * 
     * @param test A boolean expression describing postcondition.
     * @param message A string describing postcondition.
     */
    static public void post(boolean test, String message)
    // pre: result of postcondition test
    // post: does nothing if test true, otherwise abort w/message
    {
	if (test == false) {
	    throw new FailedPostcondition(message);
	}
    }

    /**
     * Test a general condition.  If the assertion fails, the message
     * indicates that a general condition failed.  The condition may
     * be anything that needs to be verified during the course of program
     * execution.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Result of general condition test
     * <dt><b>Postcondition:</b><dd> Does nothing if test true, otherwise abort w/message
     * </dl>
     * 
     * @param test A boolean expression describing the condition.
     * @param message A string describing the condition.
     */
    static public void condition(boolean test, String message)
    // pre: result of general condition test
    // post: does nothing if test true, otherwise abort w/message
    {
	if (test == false) throw new FailedAssertion(message);
    }

    /**
     * Indicate certain failure.  Stops the program with a message
     * indicating why failure occurred.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Throws error with message
     * </dl>
     * 
     * @param message A string describing the reason for failure.
     */
    static public void fail(String message)
    // post: throws error with message
    {
	throw new FailedAssertion(message);
    }
}

/**
 * A class of error indicating failure.
 *
 * @version $Id: Assert.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 * @see Assert#fail
 */
class FailedAssertion extends Error
{
    /**
     * Constructs an error indicating failure to meet condition.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Constructs a new failed assertion error
     * </dl>
     * 
     * @param reason String describing failed condition.
     */
    public FailedAssertion(String reason)
    // post: constructs a new failed assertion error
    {
	super("\nAssertion that failed: " + reason);
    }
}

/**
 * A class of error indicating failed precondition.
 *
 * @version $Id: Assert.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 * @see Assert#pre
 */
class FailedPrecondition extends FailedAssertion
{
    /**
     * Constructs an error indicating failure to meet a precondition.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Constructs a new failed precondition
     * </dl>
     * 
     * @param reason String describing precondition.
     */
    public FailedPrecondition(String reason)
    // post: constructs a new failed precondition
    {
	super("\nA precondition: " + reason);
    }
}

/**
 * A class of error indicating failed postcondition.
 * <p>
 * @version $Id: Assert.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class FailedPostcondition extends FailedAssertion
{
    /**
     * Constructs an error indicating failure to meet a postcondition.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Constructs a new failed postcondition
     * </dl>
     * 
     * @param reason String describing postcondition.
     */
    public FailedPostcondition(String reason)
    // post: constructs a new failed postcondition
    {
	super("\nA postcondition: " + reason);
    }
}
 

// In-order iterator for binary trees.
// (c) 1998 McGraw-Hill
package structure;

/**
 * An iterator for traversing binary trees constructed from
 * BinaryTreeNodes.  The iterator performs minimal work before
 * traversal.  Every node is considered after every left descendant,
 * but before any right descendant.  Traversal finishes when
 * all descendants of the start node have been considered.
 *
 * @version $Id: BTInorderIterator.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class BTInorderIterator implements Iterator
{
    /**
     * The root of the subtree being traversed.
     */
    protected BinaryTreeNode root; // root of subtree to be traversed
    /** 
     * Stack of nodes that maintain the state of the iterator.
     */
    protected Stack todo; // stack of unvisited ancestors of current

    /**
     * Construct a new inorder iterator of a tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Constructs an iterator to traverse inorder
     * </dl>
     * 
     * @param root The root of the subtree to be traversed.
     */
    public BTInorderIterator(BinaryTreeNode root)
    // post: constructs an iterator to traverse inorder
    {
	todo = new StackList();
	this.root = root;
	reset();
    }	

    /**
     * Reset the iterator to its initial state.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Resets the iterator to retraverse
     * </dl>
     */
    public void reset()
    // post: resets the iterator to retraverse
    {
	todo.clear();
	// stack is empty.  Push on nodes from root to
	// leftmost descendant
	BinaryTreeNode current = root;
	while (current != null) {
	    todo.push(current);
	    current = current.left();
	}
    }

    /**
     * Returns true iff the iterator has more nodes to be considered.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff iterator is not finished
     * </dl>
     * 
     * @return True iff more nodes are to be considered.
     */
    public boolean hasMoreElements()
    // post: returns true iff iterator is not finished
    {
	return !todo.isEmpty();
    }

    /**
     * Return the node currently being considered.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> Returns reference to current value
     * </dl>
     * 
     * @return The node currently under consideration.
     */
    public Object value()
    // pre: hasMoreElements()
    // post: returns reference to current value
    {	
	return ((BinaryTreeNode)todo.peek()).value();
    }

    /**
     * Return current node, and increment iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements();
     * <dt><b>Postcondition:</b><dd> Returns current value, increments iterator
     * </dl>
     * 
     * @return The value of the current node, before iterator iterated.
     */
    public Object nextElement()
    // pre: hasMoreElements();
    // post: returns current value, increments iterator
    {
	BinaryTreeNode old = (BinaryTreeNode)todo.pop();
	Object result = old.value();
	// we know this node has no unconsidered left children.
	// if this node has a right child, 
	//  we push the right child and its leftmost descendants:
	// else top element of stack is next node to be visited
	if (old.right() != null) {
	    BinaryTreeNode current = old.right();
	    do {
		todo.push(current);
		current = current.left();
	    } while (current != null);
	}
	return result;
    }
}

// An implementation of Vectors, similar to that defined in java.utils
// (c) 1998 McGraw-Hill

package structure;
import java.util.Enumeration;

/**
 * An implementation of vectors, similar to that found in java.util.Vector.
 *
 * @version $Id: Vector.java,v 3.2 1998/01/22 02:20:27 bailey Exp bailey $
 * @author duane a. bailey
 */
public class Vector implements Cloneable
{
    /**
     * Data associated with vector.
     */
    protected Object elementData[];	// the data
    /**
     * The number of elements stored in vector.
     */
    protected int elementCount;		// # of elements in vector
    /**
     * The size of size increment, should the vector become full.
     * 0 indicates the vector should be doubled.
     */
    protected int capacityIncrement;	// the rate of growth for vector
    /**
     * The initial value of the vector when vector size is expanded.
     */
    protected Object initialValue;	// new elements have this value
    /**
     * The default size of the array.
     */
    protected final static int defaultCapacity = 10; // def't capacity, must be>0

    /**
     * Construct an empty vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a vector with capacity for 10 elements
     * </dl>
     */
    public Vector()
    // post: constructs an empty vector
    {
	this(10); // call one-parameter constructor
    }
    
    /**
     * Construct an empty vector capable of storing initial capacity
     * values before the vector must be extended.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> initialCapacity >= 0
     * <dt><b>Postcondition:</b><dd> constructs an empty vector with initialCapacity capacity
     * </dl>
     * 
     * @param initialCapacity The size of vector before reallocation is necessary
     */
    public Vector(int initialCapacity)
    // pre: initialCapacity >= 0
    // post: constructs an empty vector with initialCapacity capacity
    {
	Assert.pre(initialCapacity >= 0,"Nonnegative capacity.");
	elementData = new Object[initialCapacity];
	elementCount = 0;
	capacityIncrement = 0;
	initialValue = null;
    }

    /**
     * Construct a vector with initial capacity, and growth characteristic.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> initialCapacity >= 0, capacityIncr >= 0
     * <dt><b>Postcondition:</b><dd> constructs an empty vector with initialCapacity capacity
     *    that extends capacity by capacityIncr, or doubles if 0
     * </dl>
     * 
     * @param initialCapacity The initial number of slots in vector.
     * @param capacityIncr The size of growth of vector.
     */
    public Vector(int initialCapacity, int capacityIncr)
    // pre: initialCapacity >= 0, capacityIncr >= 0
    // post: constructs an empty vector with initialCapacity capacity
    //    that extends capacity by capacityIncr, or doubles if 0
    {
	Assert.pre(initialCapacity >= 0, "Nonnegative capacity.");
	elementData = new Object[initialCapacity];
	elementCount = 0;
	capacityIncrement = capacityIncr;
	initialValue = null;
    }

    /**
     * Construct a vector with initial size, growth rate and default
     * value.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> initialCapacity, capacityIncr >= 0
     * <dt><b>Postcondition:</b><dd> constructs empty vector with capacity that begins at
     *       initialCapacity and extends by capacityIncr or doubles
     *       if 0.  New entries in vector are initialized to initValue.
     * </dl>
     * 
     * @param initialCapacity The initial number of slots in vector.
     * @param capacityIncr The size of the increment when vector grows.
     * @param initValue The initial value stored in vector elements.
     */
    public Vector(int initialCapacity, int capacityIncr, Object initValue)
    // pre: initialCapacity, capacityIncr >= 0
    // post: constructs empty vector with capacity that begins at
    //       initialCapacity and extends by capacityIncr or doubles
    //       if 0.  New entries in vector are initialized to initValue.
    {
	Assert.pre(initialCapacity >= 0, "Nonnegative capacity.");
	capacityIncrement = capacityIncr;
	elementData = new Object[initialCapacity];
	elementCount = 0;
	initialValue = initValue;
    }

    /**
     * Ensure that the vector is capable of holding at least
     * minCapacity values without expansion.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the capacity of this vector is at least minCapacity.
     * </dl>
     * 
     * @param minCapacity The minimum size of array before expansion.
     */
    public void ensureCapacity(int minCapacity)
    // post: the capacity of this vector is at least minCapacity.
    {
	if (elementData.length < minCapacity) {
	    int newLength = elementData.length; // initial guess
	    if (capacityIncrement == 0) {
		// increment of 0 suggests doubling (default)
		if (newLength == 0) newLength = 1;
		while (newLength < minCapacity) {
		    newLength *= 2;
		}
	    } else {
		// increment != 0 suggests incremental increase
		while (newLength < minCapacity)
		{
		    newLength += capacityIncrement;
		}
	    }
	    // assertion: newLength > elementData.length.
    	    Object newElementData[] = new Object[newLength];
	    int i;
	    // copy old data to array
	    for (i = 0; i < elementCount; i++) {
		newElementData[i] = elementData[i];
	    }
	    elementData = newElementData;
	    // N.B. Garbage collector will pick up old elementData
	}
	// assertion: capacity is at least minCapacity
    }

    /**
     * Add an element to the high end of the array, possibly expanding
     * vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds new element to end of possibly extended vector
     * </dl>
     * 
     * @param obj The object to be added to the end of the vector.
     */
    public void addElement(Object obj)
    // post: adds new element to end of possibly extended vector
    {
	ensureCapacity(elementCount+1);
	elementData[elementCount] = obj;
	elementCount++;
    }

    /**
     * Determine the capacity of the vector.  The capacity is always
     * at least as large as its size.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns allocated size of the vector
     * </dl>
     * 
     * @return The size of the array underlying the vector.
     */
    public int capacity()
    // post: returns allocated size of the vector
    {
	return elementData.length;
    }

    /**
     * Construct a shallow copy of the vector.  The vector
     * store is copied, but the individual elements are shared
     * objects.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a copy of the vector, using same objects.
     * </dl>
     * 
     * @return A copy of the original vector.
     */
    public Object clone()
    // post: returns a copy of the vector, using same objects.
    {

	// generate new (empty) vector
	Vector copy =
            new Vector(elementData.length,capacityIncrement,initialValue);

	int i;
	for (i = 0; i < elementCount; i++) {
	    copy.addElement(elementData[i]);
	}
	return copy;
    }

    /**
     * Determine if a value appears in a vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff Vector contains the value
     *       (could be faster, if orderedVector is used)
     * </dl>
     * 
     * @param elem The value sought.
     * @return True iff the value appears in the vector.
     */
    public boolean contains(Object elem)
    // post: returns true iff Vector contains the value
    //       (could be faster, if orderedVector is used)
    {
	int i;
	for (i = 0; i < elementCount; i++) {
	    if (elem.equals(elementData[i])) return true;
	}
	return false;
    }

    /**
     * Copy the contents of the vector into an array.
     * The array must be large enough to accept all the values in
     * the vector.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> dest has at least size() elements
     * <dt><b>Postcondition:</b><dd> a copy of the vector is stored in the dest array
     * </dl>
     * 
     * @param dest An array of size at least size(). 
     */
    public void copyInto(Object dest[])
    // pre: dest has at least size() elements
    // post: a copy of the vector is stored in the dest array
    {
	int i;
	for (i = 0; i < elementCount; i++) {
	    dest[i] = elementData[i];
	}
    }

    /**
     * Fetch the element at a particular index.
     * The index of the first element is zero.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= index && index < size()
     * <dt><b>Postcondition:</b><dd> returns the element stored in location index
     * </dl>
     * 
     * @param index The index of the value sought.
     * @return A reference to the value found in the vector.
     */
    public Object elementAt(int index)
    // pre: 0 <= index && index < size()
    // post: returns the element stored in location index
    {
	return elementData[index];
    }

    /**
     * Construct an iterator over the elements of the vector.
     * The iterator considers elements with increasing
     * index.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator (ordered enumeration) allowing one to
     *       view elements of vector
     * </dl>
     * 
     * @return An iterator to traverse the vector.
     */
    public Iterator elements()
    // post: returns an iterator (ordered enumeration) allowing one to
    //       view elements of vector
    {
	return new VectorIterator(this);
    }

    /**
     * Get access to the first element of the vector.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vector contains an element
     * <dt><b>Postcondition:</b><dd> returns first value in vector
     * </dl>
     * 
     * @return Access to the first element of the vector.
     */
    public Object firstElement()
    // pre: vector contains an element
    // post: returns first value in vector
    {
	return elementAt(0);
    }

    /**
     * Assuming the data is not in order, find the index of a
     * value, or return -1 if not found.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns index of element equal to object, or -1.  Starts at 0.
     * </dl>
     * 
     * @param elem The value sought in vector.
     * @return The index of the first occurrence of the value.
     */
    public int indexOf(Object elem)
    // post: returns index of element equal to object, or -1.  Starts at 0.
    {
	return indexOf(elem,0);
    }

    /**
     * Assuming the data is not in order, find the index of a value
     * or return -1 if the value is not found.  Search starts at index.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns index of element equal to object, or -1.  Starts at index.
     * </dl>
     * 
     * @param elem The value sought.
     * @param index The first location considered.
     * @return The index of the first location, or -1 if not found.
     */
    public int indexOf(Object elem, int index)
    // post: returns index of element equal to object, or -1.  Starts at index.
    {
	int i;
	for (i = index; i < elementCount; i++)
	{
	    if (elem.equals(elementData[i])) return i;
	}
	return -1;
    }

    /**
     * Insert an element at a particular location.
     * Vector is grown as needed
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= index <= size()
     * <dt><b>Postcondition:</b><dd> inserts new value in vector with desired index,
     *   moving elements from index to size()-1 to right
     * </dl>
     * 
     * @param obj The value to be inserted.
     * @param index The location of the new value.
     */
    public void insertElementAt(Object obj, int index)
    // pre: 0 <= index <= size()
    // post: inserts new value in vector with desired index,
    //   moving elements from index to size()-1 to right
    {
	int i;
	ensureCapacity(elementCount+1);
	// N.B. must copy from right to left to avoid destroying data
	for (i = elementCount; i > index; i--) {
	    elementData[i] = elementData[i-1];
	}
	// assertion: i == index and element[index] is available
	elementData[index] = obj;
	elementCount++;
    }
    /* A recursive version of insert element at
    public void insertElementAt(Object value, int index)
    // pre: 0 <= index <= size()
    // post: inserts new value in vector with desired index
    //   moving elements from index to size()-1 to right
    {
        if (index >= size()) addElement(value); // base case
        else {
    	    Object previous = elementAt(index); // work
	    insertElementAt(previous,index+1);  // progress
	    setElementAt(value,index);  // work
        }
    }
    */

    /**
     * Determine if the Vector contains no values.	
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff there are no elements in the vector
     * </dl>
     * 
     * @return True iff the vector is empty.
     */
    public boolean isEmpty()
    // post: returns true iff there are no elements in the vector
    {
	return size() == 0;
    }

    /**
     * Fetch a reference to the last value in the vector.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vector is not empty
     * <dt><b>Postcondition:</b><dd> returns last element of the vector
     * </dl>
     * 
     * @return A reference to the last value.
     */
    public Object lastElement()
    // pre: vector is not empty
    // post: returns last element of the vector
    {
	return elementAt(elementCount-1);
    }

    /**
     * Search for the last occurrence of a value within the
     * vector.  If none is found, return -1.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns index of last occurrence of object in the vector, or -1
     * </dl>
     * 
     * @param obj The value sought.
     * @return The index of the last occurrence in the vector.
     */
    public int lastIndexOf(Object obj)
    // post: returns index of last occurrence of object in the vector, or -1
    {
	return lastIndexOf(obj,elementCount-1);
    }

    /**
     * Find the index of the last occurrence of the value in the vector before
     * the indexth position.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> index >= 0
     * <dt><b>Postcondition:</b><dd> returns the index of last occurrence of object at or before
     *       index.
     * </dl>
     * 
     * @param obj The value sought.
     * @param index The last acceptable index.
     * @return The index of the last occurrence of the value, or -1 if none.
     */
    public int lastIndexOf(Object obj, int index)
    // pre: index >= 0
    // post: returns the index of last occurrence of object at or before
    //       index.
    {
	int i;
	for (i = index; i >= 0; i--) {
	    if (obj.equals(elementData[i])) return i;
	}
	return -1;
    }

    /**
     * Remove all the values of the vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> vector is empty
     * </dl>
     */
    public void clear()
    // post: vector is empty
    {
	setSize(0);
    }

    /**
     * Remove all the elements of the vector.
     * Kept for compatibility with java.util.Vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> vector is empty
     * </dl>
     *
     * @see clear
     */
    public void removeAllElements()
    // post: vector is empty
    {
	setSize(0);
    }

    /**
     * Remove an element, by value, from vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> element equal to parameter is removed
     * </dl>
     * 
     * @param element The element to be removed.
     * @return The element actually removed, or if none, null.
     */
    public boolean removeElement(Object element)
    // post: element equal to parameter is removed
    {
	int where = indexOf(element);
	if (where == -1) return false;
	removeElementAt(where);
	return true;
    }

    /**
     * Remove an element at a particular location.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= where && where < size()
     * <dt><b>Postcondition:</b><dd> indicated element is removed, size decreases by 1
     * </dl>
     * 
     * @param where The location of the element to be removed.
     */
    public void removeElementAt(int where)
    // pre: 0 <= where && where < size()
    // post: indicated element is removed, size decreases by 1
    {
	elementCount--;
	while (where < elementCount) {
	    elementData[where] = elementData[where+1];
	    where++;
	}
	elementData[elementCount] = null; // free reference
    }

    /**
     * Change the value stored at location index.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= index && index < size()
     * <dt><b>Postcondition:</b><dd> element value is changed to obj
     * </dl>
     * 
     * @param obj The new value to be stored.
     * @param index The index of the new value.
     */
    public void setElementAt(Object obj, int index)
    // pre: 0 <= index && index < size()
    // post: element value is changed to obj
    {
	elementData[index] = obj;
    }

    /**
     * Explicitly set the size of the array.
     * Any new elements are initialized to the default value.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> newSize >= 0
     * <dt><b>Postcondition:</b><dd> vector is resized, any new elements are initialized
     * </dl>
     * 
     * @param newSize The ultimate size of the vector.
     */
    public void setSize(int newSize)
    // pre: newSize >= 0
    // post: vector is resized, any new elements are initialized
    {
	int i;
	if (newSize < elementCount) {
	    for (i = newSize; i < elementCount; i++) elementData[i] = null;
	} else {
	    for (i = elementCount; i < newSize; i++)
	        elementData[i] = initialValue;
	}
	elementCount = newSize;
    }

    /**
     * Determine the number of elements in the vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the size of the vector
     * </dl>
     * 
     * @return The number of elements within the vector.
     */
    public int size()
    // post: returns the size of the vector
    {
	return elementCount;
    }

    /**
     * Trim the vector to exactly the correct size.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> minimizes allocated size of vector
     * </dl>
     */
    public void trimToSize()
    // post: minimizes allocated size of vector
    {
	Object newElementData[] = new Object[elementCount];
	copyInto(newElementData);
	elementData = newElementData;
    }

    /**
     * Determine a string representation for the vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representation of vector
     * </dl>
     * 
     * @return A string representation for the vector.
     */
    public String toString()
    // post: returns a string representation of vector
    {
	StringBuffer sb = new StringBuffer();
	int i;

	sb.append("<Vector:");
	for (i = 0; i < size(); i++)
	{
	    sb.append(" "+elementAt(i));
	}
	sb.append(">");
	return sb.toString();
    }
    /*
    public void print()
    // post: print the elements of the vector
    {
	printFrom(0);
    }
    
    protected void printFrom(int index)
    // pre: index <= size()
    // post: print elements indexed between index and size()
    {
	if (index < size()) {
	    System.out.println(elementAt(index));
	    printFrom(index+1);
	}
    }
    */
}


/**
 * An iterator for traversing vectors.
 * 
 * @version $Id: Vector.java,v 3.2 1998/01/22 02:20:27 bailey Exp bailey $
 * @author duane a. bailey
 */
class VectorIterator implements Iterator
{
    /**
     * The associated vector
     */
    protected Vector theVector;
    /**
     * The index of the current value.
     */
    protected int current;

    /**
     * Construct a vector iterator to traverse vector v
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an initialized iterator associated with v
     * </dl>
     * 
     * @param v The underlying vector.
     */
    public VectorIterator(Vector v)
    // post: constructs an initialized iterator associated with v
    {
	theVector = v;
	reset();
    }

    /**
     * Reset the vector iterator to the first value in the vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the iterator is reset to beginning of the traversal
     * </dl>
     */
    public void reset()
    // post: the iterator is reset to beginning of the traversal
    {
	current = 0;
    }

    /**
     * Determine if some of the elements have yet to be considered.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if there is more structure to be traversed.
     * </dl>
     * 
     * @return True if more elements are to be considered.
     */
    public boolean hasMoreElements()
    // post: returns true if there is more structure to be traversed
    {
	return current < theVector.size();
    }

    /**
     * Fetch a reference to the current value.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> traversal has more elements
     * <dt><b>Postcondition:</b><dd> returns the current value referenced by the iterator 
     * </dl>
     * 
     * @return A reference to the current value being considered.
     */
    public Object value()
    // pre: traversal has more elements
    // post: returns the current value referenced by the iterator 
    {
	return theVector.elementAt(current);
    }
    
    /**
     * Return current value, and increment iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> traversal has more elements
     * <dt><b>Postcondition:</b><dd> increments the iterated traversal
     * </dl>
     * 
     * @return A reference to the current value, before increment.
     */
    public Object nextElement()
    // pre: traversal has more elements
    // post: increments the iterated traversal
    {
	return theVector.elementAt(current++);
    }
}


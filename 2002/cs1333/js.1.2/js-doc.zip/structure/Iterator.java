// Abstract iteration class.  Like enumerable, but values are ordered.
// (c) 1998 McGraw-Hill

package structure;
import java.util.Enumeration;

/**
 * The interface describing iterators.  An iterator is an enumeration
 * whose traversal order can be guaranteed in some way.  In addition
 * the iterator provides a reset primitive that allows the iterator
 * to be restarted without reallocation.  A value primitive also
 * provides access to the current element without incrementing the iterator.
 * <p>
 * Iterators are the result of calling the elements, keys, edges, or
 * neighbors methods of various structures in the structure package.
 * Since iterators are independent objects, multiple iterators may be
 * constructed to traverse a single object.
 * <p>
 * Because iterators provide access to data within a structure, it is important
 * not to modify or destroy data that you get access to from the value 
 * or nextElement methods.  The state of these values may determine how
 * they are found in the underlying structure.  Their modification could
 * cause the associated structure to become corrupt.
 * <p>
 * Typical use:
 * <pre>
 *      List l = new SinglyLinkedList();
 *      // ...list gets built up...
 *      Iterator li = l.elements();
 *      while (li.hasMoreElements())
 *      {
 *          System.out.println(li.value());
 *          li.nextElement();
 *      }
 *      li.reset();
 *      while (li.hasMoreElements())
 *      { .... }
 * </pre>
 * Iterators extend Java's java.util.Enumeration interface,
 * so the more traditional
 * use of Enumerations is also possible.
 * 
 * @version $Id: Iterator.java,v 3.1 1998/01/22 04:34:11 bailey Exp bailey $
 * @author duane a. bailey
 * @see java.util.Enumeration
 */
public interface Iterator extends Enumeration
{
    /**
     * Determine if the iteration is finished.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if there is more structure to be viewed:
     *       i.e., if value (nextElement) can return a useful value.
     * </dl>
     * 
     * @return True if the iterator has more elements to be considered.
     */
    public boolean hasMoreElements();
    // post: returns true if there is more structure to be viewed:
    //       i.e., if value (nextElement) can return a useful value.

    /**
     * Return current value and increment Iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> traversal has more elements
     * <dt><b>Postcondition:</b><dd> returns current value and increments the iterator
     * </dl>
     * 
     * @return The current value, before increment.
     */
    public Object nextElement();
    // pre: traversal has more elements
    // post: returns current value and increments the iterator

    /**
     * Reset iterator to the beginning of the structure.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the iterator is reset to the beginning of the traversal
     * </dl>
     */
    public void reset();
    // post: the iterator is reset to the beginning of the traversal

    /**
     * Return structure's current object reference.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> traversal has more elements
     * <dt><b>Postcondition:</b><dd> returns the current value referenced by the iterator 
     * </dl>
     * 
     * @return Object currently referenced.
     */
    public Object value();
    // pre: traversal has more elements
    // post: returns the current value referenced by the iterator 
}


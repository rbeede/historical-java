// Vertex base class, to be extended as needed.
// (c) 1998 McGraw-Hill

package structure;

/**
 * A private implementation of a vertex for use in graphs.
 *        
 * @version $Id: Vertex.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class Vertex
{
    /**
     * A label associated with vertex.
     */
    protected Object label;	// the user's label
    /**
     * Whether or not a vertex has been visited.
     */
    protected boolean visited;	// this vertex visited

    /**
     * Construct a vertex with an associated label.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs unvisited vertex with label
     * </dl>
     * 
     * @param label A label to be associated with vertex.
     */
    public Vertex(Object label)
    // post: constructs unvisited vertex with label
    {
	Assert.pre(label != null, "Vertex key is non-null");
	this.label = label;
	visited = false;
    }

    /**
     * Fetch the label associated with vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns user label associated w/vertex
     * </dl>
     * 
     * @return The label associated with vertex.
     */
    public Object label()
    // post: returns user label associated w/vertex
    {
	return label;
    }

    /**
     * Test and set the visited flag.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns, then marks vertex as being visited.
     * </dl>
     * 
     * @return The value of the flag before marking
     */
    public boolean visit()
    // post: returns, then marks vertex as being visited
    {
	boolean was = visited;
	visited = true;
	return was;
    }

    /**
     * Determine if the vertex has been visited.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff vertex has been visited
     * </dl>
     * 
     * @return True iff the vertex has been visited.
     */
    public boolean isVisited()
    // post: returns true iff vertex has been visited
    {
	return visited;
    }
 
    /**
     * Clears the visited flag.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> marks vertex unvisited
     * </dl>
     */
    public void reset()
    // post: marks vertex unvisited
    {
	visited = false;
    }
    
    /**
     * Returns true iff the labels of two vertices are equal.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff vertex labels are equal
     * </dl>
     * 
     * @param o Another vertex.
     * @return True iff the vertex labels are equal.
     */
    public boolean equals(Object o)
    // post: returns true iff vertex labels are equal
    {
	Vertex v = (Vertex)o;
	return label.equals(v.label());
    }

    /**
     * Return a hashcode associated with the vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns hash code for vertex
     * </dl>
     * 
     * @return An integer for use in hashing values into tables.
     */
    public int hashCode()
    // post: returns hash code for vertex
    {
	return label.hashCode();
    }

    /**
     * Construct a string representing vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of vertex.
     * </dl>
     * 
     * @return A string representing vertex.
     */
    public String toString()
    // post: returns string representation of vertex.
    {
	return "<Vertex: "+label+">";
    }
}
  

// Interface for queues.
// (c) 1998 McGraw-Hill

package structure;

/**
 * A first-in, first-out structure.  Values are added at the tail, and removed
 * from the head.  Used to process values in the order that they appear.
 * 
 * @see structure.Stack
 * @version $Id: Queue.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public interface Queue extends Linear
{
    /**
     * Add a value to the tail of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value added.
     * @see #enqueue
     */
    public void add(Object value);
    // post: the value is added to the tail of the structure

    /**
     * Add a value to the tail of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void enqueue(Object value);
    // post: the value is added to the tail of the structure

    /**
     * Remove a value form the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the head of the queue is removed and returned
     * </dl>
     * 
     * @return The value actually removed.
     * @see #dequeue
     */
    public Object remove();
    // pre: the queue is not empty
    // post: the head of the queue is removed and returned

    /**
     * Remove a value from the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the head of the queue is removed and returned
     * </dl>
     * 
     * @return The value removed from the queue.
     */
    public Object dequeue();
    // pre: the queue is not empty
    // post: the head of the queue is removed and returned

    /**
     * Fetch the value at the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the element at the head of the queue is returned
     * </dl>
     * 
     * @return Reference to the first value of the queue.
     */
    public Object peek();
    // pre: the queue is not empty
    // post: the element at the head of the queue is returned
}

// Implementation of circular lists, using singly linked elements.
// (c) 1998 McGraw-Hill

package structure;
/**
 * A class implementing a singly linked circular list.
 * 
 * @version $Id: CircularList.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public class CircularList implements List
{
    /**
     * A reference to the tail of the list.  The tail points to head.
     */
    protected SinglyLinkedListElement tail;
    /**
     * Number of elements within the circular list.
     */
    protected int count;

    /**
     * Construct an empty circular list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> constructs a new circular list
     * </dl>
     */
    public CircularList()
    // pre: constructs a new circular list
    {
	tail = null;
	count = 0;
    }

    /**
     * Add an element to the head of the circular list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds value to beginning of list.
     * </dl>
     * 
     * @param value The value to be added to the list.
     */
    public void add(Object value)
    // post: adds value to beginning of list.
    {
	addToHead(value);
    }

    /**
     * Add an element to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value non-null
     * <dt><b>Postcondition:</b><dd> adds element to head of list
     * </dl>
     * 
     * @param value  The value added to the head of the list.	
     */
    public void addToHead(Object value)
    // pre: value non-null
    // post: adds element to head of list
    {
	SinglyLinkedListElement temp =
	    new SinglyLinkedListElement(value);
	if (tail == null) { // first value added
	    tail = temp;
	    tail.setNext(tail);
	} else { // element exists in list
	    temp.setNext(tail.next());
	    tail.setNext(temp);
	}
	count++;
    }

    /**
     * Add a value to the tail of the circular list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value non-null
     * <dt><b>Postcondition:</b><dd> adds element to tail of list
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void addToTail(Object value)
    // pre: value non-null
    // post: adds element to tail of list
    {
	// new entry:
	addToHead(value);
	tail = tail.next();
    }

    /**
     * Determine if a list is empty.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns value at head of list
     * </dl>
     * 
     * @return True if there are no elements within the list.
     */
    public Object peek()
    // pre: !isEmpty()
    // post: returns value at head of list
    {
	return tail.next().value();
    }

    /**
     * Peek at the last element of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns value at tail of list
     * </dl>
     * 
     * @return The value of the last element of the list.
     */
    public Object tailPeek()
    // pre: !isEmpty()
    // post: returns value at tail of list
    {
	return tail.value();
    }

    /**
     * Remove a value from the head of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns and removes value from head of list
     * </dl>
     * 
     * @return The value removed.
     */
    public Object removeFromHead()
    // pre: !isEmpty()
    // post: returns and removes value from head of list
    {
	SinglyLinkedListElement temp = tail.next(); // ie. the head of the list
	if (tail == tail.next()) {
	    tail = null;
	} else {
	    tail.setNext(temp.next());
	    temp.setNext(null);	// helps clean things up; temp is free
	}
	count--;
	return temp.value();
    }

    /**
     * Remove a value from the tail of the list.	
     * <p> 
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns and removes value from tail of list
     * </dl>
     * 
     * @return  The value removed.
     */
    public Object removeFromTail()
    // pre: !isEmpty()
    // post: returns and removes value from tail of list
    {
	Assert.pre(!isEmpty(),"The list is not empty.");
	SinglyLinkedListElement finger = tail;
	while (finger.next() != tail) {
	    finger = finger.next();
	}
	// finger now points to second-to-last value
	SinglyLinkedListElement temp = tail;
	if (finger == tail)
	{
	    tail = null;
	} else {
	    finger.setNext(tail.next());
	    tail = finger;
	}
	count--;
	return temp.value();
    }

    /**
     * Check if a list contains an element.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value != null
     * <dt><b>Postcondition:</b><dd> returns true if list contains value, else false
     * </dl>
     * 
     * @param value  The value sought.
     * @return True iff the value is within the list.
     */
    public boolean contains(Object value)
    // pre: value != null
    // post: returns true if list contains value, else false
    {
	if (tail == null) return false;

	SinglyLinkedListElement finger;
	finger = tail.next();
	while ((finger != tail) && (!finger.value().equals(value)))
	{
	    finger = finger.next();
	}
	return finger.value().equals(value);
    }

    /**
     * Remove a value from  a list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value != null
     * <dt><b>Postcondition:</b><dd> removes and returns element equal to value, or null
     * </dl>
     * 
     * @param value The value sought.
     * @return The value removed from the list.
     */
    public Object remove(Object value)
    // pre: value != null
    // post: removes and returns element equal to value, or null
    {
        if (tail == null) return null;
	SinglyLinkedListElement finger = tail.next();
	SinglyLinkedListElement previous = tail;
	int compares;
	for (compares = 0;
	     (compares < count) && (!finger.value().equals(value));
	     compares++) 
	{
	    previous = finger;
	    finger = finger.next();
	}
	if (finger.value().equals(value)) {
	    // an example of the pigeon-hole principle
	    if (tail == tail.next()) { tail = null; }
	    else {
		if (finger == tail) tail = previous;
		previous.setNext(previous.next().next());
	    }
	    // finger value free
	    finger.setNext(null); // to keep things disconnected
	    count--;		// fewer elements
	    return finger.value();
	} else return null;
    }

    /**
     * Determine the size of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements in list
     * </dl>
     * 
     * @return  The number of elements in list.
     */
    public int size()
    // post: returns number of elements in list
    {
	return count;
    }

    /**
     * Construct an iterator over the elements of the list.
     * Elements are traversed from head to tail.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator to traverse list elements.
     * </dl>
     * 
     * @return The iterator associated with the list.
     */
    public Iterator elements()
    // post: returns iterator to traverse list elements.
    {
	return new CircularListIterator(tail);
    }

    /**
     * Determine if a list is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if no elements in list
     * </dl>
     * 
     * @return True iff the list is empty.
     */
    public boolean isEmpty()
    // post: returns true if no elements in list
    {
	return tail == null;
    }

    /**
     * Remove the elements of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from list.
     * </dl>
     */
    public void clear()
    // post: removes all elements from list.
    {
	count = 0;
        tail = null;
    }

    /**
     * Generate a string representation of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representing list
     * </dl>
     * 
     * @return String representing the list.
     */
    public String toString()
    // post: returns a string representing list
    {
	StringBuffer s = new StringBuffer();
	s.append("<CircularList:");
	Iterator li = elements();
	while (li.hasMoreElements())
	{
	    s.append(" "+li.nextElement());
	}
	s.append(">");
	return s.toString();
    }
}

/**
 * An implementation of an iterator over a circular list.
 * 
 * @version $Id: CircularList.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
class CircularListIterator implements Iterator
{
    /**
     * The tail of the traversed list.
     */
    protected SinglyLinkedListElement tail;
    /**
     * The current value of the iterator.
     */
    protected SinglyLinkedListElement current;

    /**
     * Constructs an iterator over circular list whose tail is t
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> t is a reference to a circular list element
     * <dt><b>Postcondition:</b><dd> constructs an iterator for traversing circular list
     * </dl>
     * 
     * @param t The tail of the list to be traversed.
     */
    public CircularListIterator(SinglyLinkedListElement t)
    // pre: t is a reference to a circular list element
    // post: constructs an iterator for traversing circular list
    {
	tail = t;
	reset();
    }

    /**
     * Resets iterator to consider the head of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> rests iterator to point to head of list
     * </dl>
     */
    public void reset()
    // post: rests iterator to point to head of list
    {
	if (tail == null) current = null;
	else current = tail.next();
    }

    /**
     * Determine if there are unconsidered elements.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if some elements not visited
     * </dl>
     * 
     * @return True iff some element has not been considered.
     */
    public boolean hasMoreElements()
    // post: returns true if some elements not visited
    {
	return current != null;
    }

    /**
     * Return the current value and increment iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current element, increments iterator
     * </dl>
     * 
     * @return The current value before incrementing.
     */
    public Object nextElement()
    // pre: hasMoreElements()
    // post: returns current element, increments iterator
    {
	Object result = current.value();
	if (current == tail) current = null;
	else current = current.next();
	return result;
    }

    /**
     * Determine the current value of iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current value
     * </dl>
     * 
     * @return The current value of the iterator.
     */
    public Object value()
    // pre: hasMoreElements()
    // post: returns current value
    {
	return current.value();
    }
}

// Interface for lists.
// (c) 1998 McGraw-Hill

package structure;

/**
 * Interface describing lists.  Lists are collections of data with
 * a head and tail.  Values may be added or removed from either end,
 * as well as by value from the middle.
 * <p>
 * @version $Id: List.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 * @see SinglyLinkedList
 * @see DoublyLinkedList
 * @see CircularlyLinkedList
 */
public interface List extends Collection 
{
    /**
     * Construct an iterator to traverse elements of the list
     * from head to tail, in order.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator allowing 
     *   ordered traversal of elements in list
     * </dl>
     * 
     * @return Iterator that traverses list.
     */
    public Iterator elements();
    // post: returns an iterator allowing 
    //   ordered traversal of elements in list

    /**
     * Determine size of list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements in list
     * </dl>
     * 
     * @return The number of elements in list.
     */
    public int size();
    // post: returns number of elements in list

    /**
     * Determine if list is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff list has no elements
     * </dl>
     * 
     * @return True if list has no elements.
     */
    public boolean isEmpty();
    // post: returns true iff list has no elements

    /**
     * Remove all elements of list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> empties list
     * </dl>
     */
    public void clear();
    // post: empties list

    /**
     * Add an object to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> value is added to beginning of list (see addToHead)
     * </dl>
     * 
     * @param value The value to be added to the head of the list.
     * @see #addToHead
     */
    public void add(Object value);
    // post: value is added to beginning of list (see addToHead)

    /**
     * Add a value to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> value is added to beginning of list
     * </dl>
     * 
     * @param value The value to be added to the head of the list.
     */
    public void addToHead(Object value);
    // post: value is added to beginning of list

    /**
     * Add a value to the tail of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> value is added to end of list
     * </dl>
     * 
     * @param value The value to be added to the tail of the list.
     */
    public void addToTail(Object value);
    // post: value is added to end of list

    /**
     * Fetch the first element of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> returns first value in list
     * </dl>
     * 
     * @return A reference to first element of the list.
     */
    public Object peek();
    // pre: list is not empty
    // post: returns first value in list

    /**
     * Fetch the last element of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> returns last value in list
     * </dl>
     * 
     * @return A reference to the last element of the list.
     */
    public Object tailPeek();
    // pre: list is not empty
    // post: returns last value in list

    /**
     * Remove a value from the first element of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> removes first value from the list
     * </dl>
     * 
     * @return The value actually removed.
     */
    public Object removeFromHead();
    // pre: list is not empty
    // post: removes first value from the list

    /**
     * Remove the last value from the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> removes the last value from the list
     * </dl>
     * 
     * @return The value actually removed.
     */
    public Object removeFromTail();
    // pre: list is not empty
    // post: removes the last value from the list

    /**
     * Check to see if a value is in the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is not null
     * <dt><b>Postcondition:</b><dd> returns true iff list contains an object equal to value
     * </dl>
     * 
     * @param value The value sought.
     * @return True if the value is within the list.
     */
    public boolean contains(Object value);
    // pre: value is not null
    // post: returns true iff list contains an object equal to value

    /**
     * Remove a value from the list.  At most one of the value
     * will be removed.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes and returns element equal to value
     *       otherwise returns null
     * </dl>
     * 
     * @param value The value to be removed.
     * @return The actual value removed.
     */
    public Object remove(Object value);
    // post: removes and returns element equal to value
    //       otherwise returns null
}


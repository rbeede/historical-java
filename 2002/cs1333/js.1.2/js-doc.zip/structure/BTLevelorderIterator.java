// Level-order iterator for binary trees.
// (c) 1998 McGraw-Hill
package structure;

/**
 * An iterator for traversing binary trees constructed from
 * BinaryTreeNodes.  The iterator performs minimal work before
 * traversal.  Every node is considered after every non-trivial
 * ancestor or left cousin, and before any non-trivial descendant or
 * right cousin.
 * Traversal finishes when
 * all descendants of the start node have been considered.
 * 
 * @version $Id: BTLevelorderIterator.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class BTLevelorderIterator implements Iterator
{
    /**
     * The root of the subtree being traversed.
     */
    protected BinaryTreeNode root; // root of traversed subtree
    /** 
     * Queue of nodes that maintain the state of the iterator.
     */
    protected Queue todo;  // queue of unvisited relatives

    /**
     * Construct a new level-order iterator of a tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Constructs an iterator to traverse in levelorder
     * </dl>
     * 
     * @param root The root of the subtree to be traversed.
     */
    public BTLevelorderIterator(BinaryTreeNode root)
    // post: constructs an iterator to traverse in levelorder
    {
	todo = new QueueList();
	this.root = root;
	reset();
    }	

    /**
     * Reset iterator to beginning of traversal.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Resets the iterator to root node
     * </dl>
     */
    public void reset()
    // post: resets the iterator to root node
    {
	todo.clear();
	// stack is empty; push on nodes from root down to the
	// leftmost descendant
	if (root != null) todo.enqueue(root);
    }

    /**
     * Return true if more nodes are to be considered.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff iterator is not finished
     * </dl>
     * 
     * @return True if more nodes are to be considered.
     */
    public boolean hasMoreElements()
    // post: returns true iff iterator is not finished
    {
	return !todo.isEmpty();
    }

    /**
     * Returns the value of the currently considered node.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> Returns reference to current value
     * </dl>
     * 
     * @return The value of the node currently referenced by iterator.
     */
    public Object value()
    // pre: hasMoreElements()
    // post: returns reference to current value
    {	
	return ((BinaryTreeNode)todo.peek()).value();
    }

    /**
     * Returns currently considered value and increments iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements();
     * <dt><b>Postcondition:</b><dd> Returns current value, increments iterator
     * </dl>
     * 
     * @return Value considered before iterator is incremented.
     */
    public Object nextElement()
    // pre: hasMoreElements();
    // post: returns current value, increments iterator
    {
	BinaryTreeNode current = (BinaryTreeNode)todo.dequeue();
	Object result = current.value();
	if (current.left() != null) 
	    todo.enqueue(current.left());
	if (current.right() != null)
	    todo.enqueue(current.right());
	return result;
    }
}


// An interface for Dictionaries whose keys are ordered.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An interface for a dictionary whose elements 
 * are comparable, and are kept in order in the dictionary.
 * Iterators are guaranteed to traverse the dictionary in
 * ascending order.
 *
 * @version $Id: OrderedDictionary.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 * @see Dictionary
 * @see Table
 */
public interface OrderedDictionary extends Dictionary
{
}

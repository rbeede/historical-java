// An implementation of nodes for use in binary trees.
// (c) 1998 McGraw-Hill
package structure;
import java.lang.Math;

/**
 * This class implements a single node of a binary tree.  It is a
 * recursive structure.  Relationships between nodes are 
 * doubly linked, with parent and child references.  Many characteristics
 * of trees may be detected with static methods.
 * <p>
 * @version $Id: BinaryTreeNode.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 * @see structure.BinaryTree
 * @see structure.BinarySearchTree
 */
public class BinaryTreeNode
{
    /**
     * The value associated with this node
     */
    protected Object val; // value associated with node
    /**
     * The parent of this node
     */
    protected BinaryTreeNode parent; // parent of node
    /**
     * The left child of this node
     */
    protected BinaryTreeNode left; // left child of node
    /**
     * The right child of this node
     */
    protected BinaryTreeNode right; // right child of node

    /**
     * Constructs a tree node with no children.  Value of the node
     * is provided by the user
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns a tree referencing value with two null subtrees
     * </dl>
     * 
     * @param value A (possibly null) value to be referenced by node
     */
    public BinaryTreeNode(Object value)
    // post: returns a tree referencing value with two null subtrees
    {
	val = value;
	parent = left = right = null;
    }

    /**
     * Constructs a tree node with no children.  Value of the node
     * and subtrees are provided by the user
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns a tree referencing value & subtree
     * </dl>
     * 
     * @param value A (possibly null) value to be referenced by node
     * @param left The subtree to be left subtree of node
     * @param right The subtree to be right subtree of node
     */
    public BinaryTreeNode(Object value,
			  BinaryTreeNode left,
			  BinaryTreeNode right) 
    // post: returns a node referencing value & subtrees
    {
	this(value);
	setLeft(left);
	setRight(right);
    }

    /**
     * Get left subtree of current node
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns reference to left subtree, or null
     * </dl>
     *
     * @return The left subtree of this node
     */
    public BinaryTreeNode left()
    // post: returns reference to left subtree, or null
    {
	return left;
    }

    /**
     * Get right subtree of current node
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns reference to right subtree, or null
     * </dl>
     * 
     * @return The right subtree of this node
     */
    public BinaryTreeNode right()
    // post: returns reference to right subtree, or null
    {
	return right;
    }

    /**
     * Get reference to parent of this node
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns reference to parent node, or null
     * </dl>
     * 
     * @return Reference to parent of this node
     */
    public BinaryTreeNode parent()
    // post: returns reference to parent node, or null
    {
	return parent;
    }
    
    /**
     * Update the left subtree of this node.  Parent of the left subtree
     * is updated consistently.  Existing subtree is detached
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Sets left subtree to newLeft
     *       re-parents newLeft if not null
     * </dl>
     * 
     * @param newLeft The root of the new left subtree
     */
    public void setLeft(BinaryTreeNode newLeft)
    // post: sets left subtree to newLeft
    //       re-parents newLeft if not null
    {
	if (left != null &&
	    (left.parent() == this)) left.setParent(null);
	left = newLeft;
	if (left != null) left.setParent(this);
    }

    /**
     * Update the right subtree of this node.  Parent of the right subtree
     * is updated consistently.  Existing subtree is detached
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Sets left subtree to newRight
     *       re-parents newRight if not null
     * </dl>
     * 
     * @param newRight A reference to the new right subtree of this node
     */
    public void setRight(BinaryTreeNode newRight)
    // post: sets left subtree to newRight
    //       re-parents newRight if not null
    {
	if (right != null &&
	    (right.parent() == this)) right.setParent(null);
	right = newRight;
	if (right != null) right.setParent(this);
    }

    /**
     * Update the parent of this node
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Re-parents this node to parent reference, or null
     * </dl>
     *
     * @param newParent A reference to the new parent of this node
     */
    protected void setParent(BinaryTreeNode newParent)
    // post: re-parents this node to parent reference, or null
    {
	parent = newParent;
    }

    /**
     * Returns the number of descendants of node n
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns the size of the subtree rooted at n
     * </dl>
     * 
     * @param n Root of subtree
     * @return Size of subtree
     */
    public static int size(BinaryTreeNode n)
    // post: returns the size of the subtree rooted at n
    {
	if (n == null) return 0;
	return size(n.left()) + size(n.right()) + 1;
    }

    /**
     * Returns reference to root of tree containing n
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns the root of the tree node n
     * </dl>
     * 
     * @param n Node of tree
     * @return Root of tree
     */
    public static BinaryTreeNode root(BinaryTreeNode n)
    // post: returns the root of the tree node n
    {
	if ((n == null) || (n.parent() == null)) return n;
	else return root(n.parent());
    }

    /**
     * Returns height of node in tree.  Height is maximum path
     * length to descendant
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns the height of a node n in its tree
     * </dl>
     * 
     * @param n Node in tree
     * @return The height of the node in the tree
     */
    public static int height(BinaryTreeNode n)
    // post: returns the height of a node n in its tree
    {
	if (n == null) return -1;
	return 1 + Math.max(height(n.left()),height(n.right()));
    }

    /**
     * Compute the depth of a node.  The depth is the path length
     * from node to root
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns the depth of a node in the tree
     * </dl>
     * 
     * @param n A node in a tree
     * @return The path length to root of tree
     */
    public static int depth(BinaryTreeNode n)
    // post: returns the depth of a node in the tree
    {
	if (n == null) return -1;
	return 1 + depth(n.parent());
    }

    /**
     * Returns true if tree is full.  A tree is full if adding a node
     * to tree would necessarily increase its height
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff the tree rooted at n is full
     * </dl>
     * 
     * @param n Root of tree to be considered
     * @return True iff tree is full
     */
    public static boolean isFull(BinaryTreeNode n)
    // post: returns true iff the tree rooted at n is full
    {
	if (n == null) return true;
	if (height(n.left()) != height(n.right())) return false;
	return isFull(n.left()) && isFull(n.right());
    }
    
    /**
     * Return whether tree is complete.  A complete tree has minimal height
     * and any holes in tree would appear in last level to right.	
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff the tree rooted at n is complete
     * </dl>
     * 
     * @param n Root of subtree considered
     * @return True iff the subtree is complete
     */
    public static boolean isComplete(BinaryTreeNode n)
    // post: returns true iff the tree rooted at n is complete
    {
	int leftHeight, rightHeight;
	boolean leftIsFull, rightIsFull;
	boolean leftIsComplete, rightIsComplete;
	if (n == null) return true;
	leftHeight = height(n.left());
	rightHeight = height(n.right());
	leftIsFull = isFull(n.left());
	rightIsFull = isFull(n.right());
	leftIsComplete = isComplete(n.left());
	rightIsComplete = isComplete(n.right());

	// case 1: left is full, right is complete, heights same
	if (leftIsFull && rightIsComplete &&
	    (leftHeight == rightHeight)) return true;
        // case 2: left is complete, right is full, heights differ
	if (leftIsComplete && rightIsFull &&
	    (leftHeight == (rightHeight + 1))) return true;
	return false;
    }

    /**
     * Return true iff the tree is height balanced.  A tree is height
     * balanced iff at every node the difference in heights of subtrees is
     * no greater than one
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff the tree rooted at n is balanced
     * </dl>
     * 
     * @param n Root of subtree to be considered
     * @return True if tree is height balanced
     */
    public static boolean isBalanced(BinaryTreeNode n)
    // post: returns true iff the tree rooted at n is balanced
    {
	if (n == null) return true;
	return (Math.abs(height(n.left())-height(n.right())) <= 1) &&
	       isBalanced(n.left()) && isBalanced(n.right());
    }

    /**
     * Generate an inorder traversal of subtree
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns an inorder traversal of the elements
     * </dl>
     * 
     * @return Inorder iterator on subtree rooted at this
     */
    public Iterator elements()
    // post: returns an inorder traversal of the elements
    {
	return inorderElements();
    }

    /**
     * Return an iterator to traverse nodes of subtree in-order
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> The elements of the binary tree rooted at node n are
     *       traversed in preorder
     * </dl>
     * 
     * @return Iterator to traverse subtree
     */
    public Iterator preorderElements()
    // post: The elements of the binary tree rooted at node n are
    //       traversed in preorder
    {
	return new BTPreorderIterator(this);
    }

    /**
     * Return an iterator to traverse the elements of subtree in-order
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> The elements of the binary tree rooted at node n are
     *       traversed in inorder
     * </dl>
     * 
     * @return An in-order iterator over descendants of node
     */
    public Iterator inorderElements()
    // post: The elements of the binary tree rooted at node n are
    //       traversed in inorder
    {
	return new BTInorderIterator(this);
    }

    /**
     * Return an iterator to traverse the elements of subtree in post-order
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> None
     * <dt><b>Postcondition:</b><dd> The elements of the binary tree rooted at node n are
     *       traversed in postorder
     * </dl>
     * 
     * @return An iterator that traverses descendants of node in postorder
     */
    public Iterator postorderElements()
    // pre: none
    // post: The elements of the binary tree rooted at node n are
    //       traversed in postorder
    {
	return new BTPostorderIterator(this);
    }

    /**
     * Method to return a level-order iterator of subtree
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> None
     * <dt><b>Postcondition:</b><dd> The elements of the binary tree rooted at node n are
     *       traversed in levelorder
     * </dl>
     * 
     * @return An iterator to traverse subtree in level-order
     */
    public Iterator levelorderElements()
    // pre: none
    // post: The elements of the binary tree rooted at node n are
    //       traversed in levelorder
    {
	return new BTLevelorderIterator(this);
    }

    /**
     * Method to perform a right rotation of tree about this node
     * Node must have a left child.  Relation between left child and node
     * are reversed
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> This node has a left subtree
     * <dt><b>Postcondition:</b><dd> Rotates local portion of tree so left child is root
     * </dl>
     */
    protected void rotateRight()
    // pre: this node has a left subtree
    // post: rotates local portion of tree so left child is root
    {
	BinaryTreeNode parent = parent();
	BinaryTreeNode newRoot = left();
	boolean wasChild = parent != null;
	boolean wasLeftChild = isLeftChild();

	// hook in new root (sets newRoot's parent, as well)
        setLeft(newRoot.right());

	// puts pivot below it (sets this's parent, as well)
        newRoot.setRight(this);

	if (wasChild) {
	    if (wasLeftChild) parent.setLeft(newRoot);
	    else              parent.setRight(newRoot);
	}
    }

    /**
     * Method to perform a left rotation of tree about this node
     * Node must have a right child.  Relation between right child and node
     * are reversed
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> This node has a right subtree
     * <dt><b>Postcondition:</b><dd> Rotates local portion of tree so right child is root
     * </dl>
     */
    protected void rotateLeft()
    // pre: this node has a right subtree
    // post: rotates local portion of tree so right child is root
    {
	// all of this information must be grabbed before
	// any of the references are set.  Draw a diagram for help
	BinaryTreeNode parent = parent();
	BinaryTreeNode newRoot = right();
	// is the this node a child; if so, a left child?
	boolean wasChild = parent != null;
	boolean wasRightChild = isRightChild();

	// hook in new root (sets newRoot's parent, as well)
        setRight(newRoot.left());

	// put pivot below it (sets this's parent, as well)
        newRoot.setLeft(this);

	if (wasChild) {
	    if (wasRightChild) parent.setRight(newRoot);
	    else               parent.setLeft(newRoot);
	}
    }

    /**
     * Determine if this node is a left child
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true if this is a left child of parent
     * </dl>
     * 
     * @return True iff this node is a left child of parent
     */
    public boolean isLeftChild()
    // post: returns true if this is a left child of parent
    {
	if (parent() == null) return false;
	return this == parent().left();
    }

    /**
     * Determine if this node is a right child
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true if this is a right child of parent
     * </dl>
     * 
     * @return True iff this node is a right child of parent
     */
    public boolean isRightChild()
    // post: returns true if this is a right child of parent
    {
	if (parent() == null) return false;
	return this == parent().right();
    }

    /**
     * Returns value associated with this node
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns value associated with this node
     * </dl>
     * 
     * @return The node's value
     */
    public Object value()
    // post: returns value associated with this node
    {
	return val;
    }

    /**
     * Set's value associated with this node
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Sets the value associated with this node
     * </dl>
     * 
     * @param value The new value of this node
     */
    public void setValue(Object value)
    // post: sets the value associated with this node
    {
	val = value;
    }

    /**
     * Returns a representation the subtree rooted at this node
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns string representation
     * </dl>
     * 
     * @return String representing this subtree
     */
    public String toString()
    // post: returns string representation
    {
	StringBuffer s = new StringBuffer();
	s.append("<BinaryTreeNode "+value());
	if (left != null) s.append(" "+left());
	else s.append(" -");
	if (right != null) s.append(" "+right());
	else s.append(" -");
	s.append('>');
	return s.toString();
    }
}


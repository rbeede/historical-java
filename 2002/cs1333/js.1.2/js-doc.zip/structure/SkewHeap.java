// Implementation of priority queues/heaps using binary trees.
// (c) 1998 McGraw-Hill
package structure;

/**
 * An implementation of a priority queue using skew heaps.  Skew heaps
 * allow one to construct heaps dynamically without explictly balancing
 * the heaps.  Main operation is a merge.
 *
 * @version $Id: SkewHeap.java,v 3.1 1998/01/19 14:51:27 bailey Exp bailey $
 * @author duane a. bailey
 */
public class SkewHeap implements PriorityQueue
{
    /**
     * The root of the skew heap.
     */
    protected BinaryTreeNode root;
    /**
     * The number of nodes within heap.
     */
    protected int count;

    /**
     * Constructs an empty priority queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> creates an empty priority queue
     * </dl>
     */
    public SkewHeap()
    // post: creates an empty priority queue
    {
	root = null;	
	count = 0;
    }

    /**
     * Fetch lowest valued (highest priority) item from queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns the minimum value in priority queue
     * </dl>
     * 
     * @return The smallest value from queue.
     */
    public Comparable peek()
    // pre: !isEmpty()
    // post: returns the minimum object in queue
    {
	return (Comparable)(root.value());
    }

    /**
     * Returns the minimum value from the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns and removes minimum value from queue
     * </dl>
     * 
     * @return The minimum value in the queue.
     */
    public Comparable remove()
    // pre: !isEmpty()
    // post: returns and removes the minimum object in queue
    {
	Comparable result = (Comparable)(root.value());
	root = merge(root.left(),root.right());
	count--;
	return result;	
    }

    /**
     * Add a value to the priority queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null comparable
     * <dt><b>Postcondition:</b><dd> value is added to priority queue
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void add(Comparable value)
    // pre: value is non-null object
    // post: adds value to priority queue
    {
	BinaryTreeNode smallTree = new BinaryTreeNode(value);
	root = merge(smallTree,root);
	count++;
    }

    /**
     * Determine the size of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements within queue
     * </dl>
     * 
     * @return The number of elements within the queue.
     */
    public int size()
    // post: returns the number of elements in queue.
    {
	return count;
    }

    /**
     * Remove all the elements from the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from queue
     * </dl>
     */
    public void clear()
    // post: removes all elements from the queue
    {
	root = null;
    }

    /**
     * Determine if the queue is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff no elements are in queue
     * </dl>
     * 
     * @return True if the queue is empty.
     */
    public boolean isEmpty()
    // post: returns true iff queue has no elements
    {
	return size() == 0;
    }

    protected static BinaryTreeNode merge(BinaryTreeNode left,
					  BinaryTreeNode right)
    // post: merges two skew heaps into one
    {
	if (left == null) return right;
	if (right == null) return left;
	Comparable leftVal = (Comparable)(left.value());
	Comparable rightVal = (Comparable)(right.value());
	BinaryTreeNode result;
	if (rightVal.compareTo(leftVal) < 0)
	{
	    result = merge(right,left);
	} else {
	    result = left;
	    // assertion left side is smaller than right
	    // left is new root
	    if (result.left() == null)
	    {
		result.setLeft(right);
	    } else {
		BinaryTreeNode temp = result.right();
		result.setRight(result.left());
		result.setLeft(merge(temp,right));
	    }
	}
	return result;
    }

    /**
     * Construct a string representation of the heap.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of heap
     * </dl>
     * 
     * @return The string representing the heap.
     */
    public String toString()
    // post: returns string representation of heap
    {
	if (root == null) return "<SkewHeap: >";
        StringBuffer sb = new StringBuffer();
	sb.append("<SkewHeap:");
	if (root != null) {
	    Iterator i = root.elements();
	    while (i.hasMoreElements())
	    {
		sb.append(" "+i.value());
	    }
	}
	return sb+">";
    }

}

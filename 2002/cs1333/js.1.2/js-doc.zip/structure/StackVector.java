// An implementation of stacks, using vectors.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of stacks using Vectors.
 * 
 * @version $Id: StackVector.java,v 3.1 1998/01/26 19:30:19 bailey Exp $
 * @author duane a. bailey
 */
public class StackVector implements Stack
{
    /**
     * The vector containing the stack data.
     */
    protected Vector data;

    /**
     * Construct an empty stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> an empty stack is created
     * </dl>
     */
    public StackVector()
    // post: an empty stack is created
    {
	data = new Vector();
    }

    /**
     * Construct a stack with initial capacity
     * Vector will grow if the stack fills vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> an empty stack with initial capacity of size is created
     * </dl>
     * 
     * @param size The initial capacity of the vector.
     */
    public StackVector(int size)
    // post: an empty stack with initial capacity of size is created
    {
 	data = new Vector(size);
    }

    /**
     * Add an element from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> item is added to stack
     *       will be popped next if no intervening add
     * </dl>
     * 
     * @param item The element to be added to the stack top.
     * @see #push
     */
    public void add(Object item)
    // post: item is added to stack
    //       will be popped next if no intervening add
    {
	data.addElement(item);
    }

    /**
     * Add an element to top of stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> item is added to stack
     *       will be popped next if no intervening push
     * </dl>
     * 
     * @param item The value to be added to the top of the stack.
     */
    public void push(Object item)
    // post: item is added to stack
    //       will be popped next if no intervening push
    {
	add(item);
    }

    /**
     * Remove an element from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> most recently added item is removed and returned
     * </dl>
     * 
     * @return The item removed from the top of the stack.
     * @see #pop
     */
    public Object remove()
    // pre: stack is not empty
    // post: most recently added item is removed and returned
    {
        Object result = data.elementAt(size()-1);
	data.removeElementAt(size()-1);
	return result;
    }

    /**
     * Remove an element from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> most recently pushed item is removed and returned
     * </dl>
     * 
     * @return A reference to the removed element.
     */
    public Object pop()
    // pre: stack is not empty
    // post: most recently pushed item is removed and returned
    {
	return remove();
    }

    /**
     * Fetch a reference to the top element of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> top value (next to be popped) is returned
     * </dl>
     * 
     * @return A reference to the top element of the stack.
     */
    public Object peek()
    // pre: stack is not empty
    // post: returns reference to most recent element in stack
    {
	// raise an exception if stack is already empty
	return data.elementAt(size()-1);
    }

    /**
     * Returns true iff the stack is empty.  Provided for
     * compatibility with java.util.Vector.empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if and only if the stack is empty
     * </dl>
     * 
     * @return True iff the stack is empty.
     * @see #isEmpty
     */
    public boolean empty()
    // post: returns true iff the stack is empty
    {
	return size() == 0;
    }

    /**
     * Determine the number of elements in stack.
     * 
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of elements in stack
     * </dl>
     * 
     * @return The number of elements in stack.
     */
    public int size()
    // post: returns the number of elements in stack
    {
	return data.size();
    }

    /**
     * Remove all elements from stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from stack
     * </dl>
     */
    public void clear()
    // post: removes all elements from stack
    {
	data.clear();
    }

    /**
     * Returns tree iff the stack is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if and only iff the stack is empty
     * </dl>
     * 
     * @return True iff the stack is empty.
     * @see #empty
     */
    public boolean isEmpty()
    // post: returns true iff the stack is empty
    {
        return size() == 0;
    }

    /**
     * Construct a string representation of stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representation of stack
     * </dl>
     * 
     * @return A string representing the stack.
     */
    public String toString()
    // post: returns a string representation of stack
    {
	StringBuffer sb = new StringBuffer();
	int i;

	sb.append("<StackVector:");
	for (i = data.size()-1; i >= 0; i--)
	{
	    sb.append(" "+i);
	}
	return sb.toString()+">";
    }
}

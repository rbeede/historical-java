// A class for structuring associations that may be compared.
// (c) 1998 McGraw-Hill
package structure;

/**
 * An association that can be compared.
 *
 * @version $Id: ComparableAssociation.java,v 3.2 1998/01/13 14:00:28 bailey Exp bailey $
 * @author duane a. bailey
 */
public class ComparableAssociation extends Association implements Comparable
{
    /**
     * Construct an association that can be ordered, from only a key.
     * The value is set to null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null
     * <dt><b>Postcondition:</b><dd> constructs comparable association with null value
     * </dl>
     * 
     * @param key The (comparable) key.
     */
    public ComparableAssociation(Comparable key)
    // pre: key is non-null
    // post: constructs comparable association with null value
    {
	this(key,null);
    }

    /**
     * Construct a key-value association that can be ordered.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null
     * <dt><b>Postcondition:</b><dd> constructs association between a comparable key and a value
     * </dl>
     * 
     * @param key The (comparable) key.
     * @param value The (possibly comparable) associated value.
     */
    public ComparableAssociation(Comparable key, Object value)
    // pre: key is non-null
    // post: constructs ass'n between comparable key and a value
    {
	super(key,value);
    }

    /**
     * Determine the order of two comparable associations, based on key.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null ComparableAssociation
     * <dt><b>Postcondition:</b><dd> returns integer representing relation between values.
     * </dl>
     * 
     * @param other The other comparable association.
     * @return Value less-than equal to or greater than zero based on comparison
     */
    public int compareTo(Object other)
    // pre: other is non-null ComparableAssociation
    // post: returns integer representing relation between values
    {
	Assert.pre(other instanceof ComparableAssociation,
		   "compareTo expects a ComparableAssociation");
	ComparableAssociation that = (ComparableAssociation)other;
	Comparable thisKey = (Comparable)this.key();
	Comparable thatKey = (Comparable)that.key();

	return thisKey.compareTo(thatKey);
    }

    /**
     * Construct a string representation of the ComparableAssociation.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation
     * </dl>
     * 
     * @return The string representing the ComparableAssociation.
     */
    public String toString()
    // post: returns string representation
    {
	StringBuffer s = new StringBuffer();
	s.append("<ComparableAssociation: "+key()+"="+value()+">");
	return s.toString();
    }
}

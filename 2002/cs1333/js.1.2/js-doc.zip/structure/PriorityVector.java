// An implementation of priority queues that makes use of ordering vectors.
// (c) 1998 McGraw-Hill
package structure;

/**
 * A vector-based implementation of a priority queue.  Similar to
 * an ordered vector, except that only the smallest value may be
 * accessed in this structure.
 * 
 * @see structure.OrderedVector
 * @version $Id: PriorityVector.java,v 3.1 1998/01/19 14:51:27 bailey Exp $
 * @author duane a. bailey
 */
public class PriorityVector implements PriorityQueue
{
    /**
     * The vector of data that is maintained in increasing order.
     */
    protected Vector data;

    /**
     * Construct an empty priority queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new priority queue
     * </dl>
     */
    public PriorityVector()
    // post: constructs a new priority queue
    {
        data = new Vector();
    }

    /**
     * Fetch the smallest value of the priority queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns the minimum value in the priority queue
     * </dl>
     * 
     * @return The smallest value of the structure.
     */
    public Comparable peek()
    // pre: !isEmpty()
    // post: returns the minimum value in the priority queue
    {
	return (Comparable)data.elementAt(0);
    }

    /**
     * Remove the smallest value of the structure.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> removes and returns minimum value in priority queue
     * </dl>
     * 
     * @return The smallest value of the structure.
     */
    public Comparable remove()
    // pre: !isEmpty()
    // post: removes and returns minimum value in priority queue
    {
	Comparable result = (Comparable)data.elementAt(0);
	data.removeElementAt(0);
	return result;
    }
    /**
     * Add a comparable value to the priority queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> inserts value in priority queue
     *       leaves elements in order
     * </dl>
     * 
     * @param value The comparable value to be added.
     */
    public void add(Comparable value)
    // pre: value is non-null
    // post: inserts value in priority queue
    //       leaves elements in order
    {
	int position = indexOf(value);
	data.insertElementAt(value,position);
    }

    protected int indexOf(Comparable target)
    // pre: value is a non-null comparable object
    // post: returns ideal position of value in vector
    {
	Comparable midValue;
	int low = 0;  // lowest possible location
	int high = data.size(); // highest possible location
	int mid = (low + high)/2; // low <= mid <= high
	// mid == high iff low == high
	while (low < high) {
	    Assert.condition(mid < high,"Middle element exists.");
	    midValue = (Comparable)data.elementAt(mid);
	    if (midValue.compareTo(target) < 0) {
		low = mid+1;
	    } else {
		high = mid;
	    }
	    mid = (low+high)/2;
	}
	return low;
    }

    /**
     * Determine if the priority queue is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the priority queue is empty
     * </dl>
     * 
     * @return True iff there are no elements in the priority queue.
     */
    public boolean isEmpty()
    // post: returns true iff the priority queue is empty
    {
	return data.size() == 0;
    }

    /**
     * Determine the size of the priority queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements in priority queue
     * </dl>
     * 
     * @return The number of elements in the priority queue.
     */
    public int size()
    // post: returns number of elements in priority queue
    { 
	return data.size();
    }

    /**
     * Remove all the values from the priority queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from priority queue.
     * </dl>
     */
    public void clear()
    // post: removes all elements from priority queue.
    {
	data.clear();
    }

    /**
     * Construct a string representation of the priority vector.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of priority vector
     * </dl>
     * 
     * @return String describing priority vector.
     */
    public String toString()
    // post: returns string representation of priority vector
    {
	return "<PriorityVector: "+data+">";
    }
}

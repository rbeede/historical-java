// Interface for classes that store multiple values.
// (c) 1998 McGraw-Hill

package structure;

/**
 * This interface describes structures that maintain size information and
 * may be emptied.  Many structures within the structure package are stores.
 * <p>
 * @version $Id: Store.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public interface Store
{
    /**
     * Return the number of elements within the store.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number elements contained in sthe tore.
     * </dl>
     * 
     * @return The number of elements contained within structure.
     */
    public int size();
    // post: returns the number of elements contained in the store

    /**
     * Determine if store is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff store is empty
     * </dl>
     * 
     * @return True iff store logically contains no elements.
     */
    public boolean isEmpty();
    // post: returns true iff store is empty

    /**
     * Empty the store.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> clears store
     * </dl>
     */
    public void clear();
    // post: clears the store
}

// An implementation of an OrderedDictionary.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of an ordered dictionary.  Key-value pairs are 
 * kept in the structure in order.  To accomplish this, the keys of the
 * table must be comparable.
 * 
 * @version $Id: Table.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 * @see Comparable
 */
public class Table implements OrderedDictionary
{
    /**
     * An ordered structure that maintains the ComparableAssociations
     * that store the key-value pairings.
     */
    protected OrderedStructure data;

    /**
     * Construct a new, empty table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new table
     * </dl>
     */
    public Table()
    // post: constructs a new table
    {
        data = new SplayTree();
    }

    /**
     * Retrieve the value associated with the key provided.
     * Be aware, the value may be null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is a non-null object
     * <dt><b>Postcondition:</b><dd> returns value associated with key, or null
     * </dl>
     * 
     * @param key The key of the key-value pair sought.
     * @return The value associated with the key.
     */
    public Object get(Object key)
    // pre: key is a non-null object
    // post: returns value associated with key, or null
    {
        ComparableAssociation ca =
	    new ComparableAssociation((Comparable)key,null);
        ComparableAssociation result =
	    ((ComparableAssociation)data.remove(ca));
        if (result == null) return null;
	data.add(result);
        return result.value();
    }

    /**
     * Enter a key-value pair into the table.  if the key is already
     * in the table, the old value is returned, and the old key-value
     * pair is replaced.  Otherwise null is returned.  The user is cautioned
     * that a null value returned may indicate there was no prior key-value
     * pair, or --- if null values are inserted --- that the key was 
     * previously associated with a null value.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null object
     * <dt><b>Postcondition:</b><dd> key-value pair is added to table
     * </dl>
     * 
     * @param key The unique key in the table.
     * @param value The (possibly null) value associated with key.
     * @return The prior value, or null if no prior value found.
     */
    public Object put(Object key, Object value)
    // pre: key is non-null object
    // post: key-value pair is added to table
    {
        ComparableAssociation ca = 
	    new ComparableAssociation((Comparable)key,value);
	// fetch old key-value pair
	ComparableAssociation old =
	    (ComparableAssociation)data.remove(ca);
	// insert new key-value pair
	data.add(ca);
	// return old value
	if (old == null) return null;
	else return old.value();
    }
    
    /**
     * Determine if the table is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff table is empty
     * </dl>
     * 
     * @return True iff the table has no elements.
     */
    public boolean isEmpty()
    // post: returns true iff table is empty
    {
        return data.isEmpty();
    }

    /**
     * Remove all the elements of the table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from the table
     * </dl>
     */
    public void clear()
    // post: removes all elements from the table
    {
        data.clear();
    }

    /**
     * Construct an iterator over the keys of the table.
     * The order of the keys returned is in ascending order.  It will
     * be consistent with that of the iterator from elements, provided
     * the table is not modified.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator for traversing keys of table
     * </dl>
     * 
     * @return An iterator over the keys of the table.
     */
    public Iterator keys()
    // post: returns an iterator for traversing keys of table
    {
        return new KeyIterator(data.elements());
    }

    /**
     * Construct an iterator over the values of the table.
     * The order of the values returned is determined by order of keys. It will
     * be consistent with that of the iterator returned from keys, provided
     * the table is not modified.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator for traversing values in table
     * </dl>
     * 
     * @return An iterator over the values of the table.
     */
    public Iterator elements()
    // post: returns an iterator for traversing values in table
    {
        return new ValueIterator(data.elements());
    }

    /**
     * Determine if the key is in the table.  The key should
     * not be null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null object
     * <dt><b>Postcondition:</b><dd> returns true iff key indexes a value in table
     * </dl>
     * 
     * @param key A non-null key sought in the table.
     * @return True iff the key is used in association with some value.
     */
    public boolean containsKey(Object key)
    // pre: key is non-null object
    // post: returns true iff key indexes a value in table
    {
        ComparableAssociation a =
	    new ComparableAssociation((Comparable)key,null);
        return data.contains(a);
    }

    /**
     * Returns true if the value is associated with some key in the
     * table.  This is often difficult to implement efficiently.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null object
     * <dt><b>Postcondition:</b><dd> returns true iff value in table
     * </dl>
     * 
     * @param value The value sought (possibly null).
     * @return True, if the value is associated with some key in table.
     */
    public boolean contains(Object value)
    // pre: value is non-null object
    // post: returns true iff value in table
    {
	Iterator i = elements();
	for (;i.hasMoreElements();i.nextElement())
	{
	    if (i.value() != null &&
		i.value().equals(value)) return true;
	}
        return false;
    }

    
    /**
     * Remove a key-value pair, based on key.  The value is returned.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null object
     * <dt><b>Postcondition:</b><dd> removes value indexed in table
     * </dl>
     * 
     * @param key The key of the key-value pair to be removed.
     * @return The value associated with key, no longer in table.
     */
    public Object remove(Object key)
    // pre: key is non-null object
    // post: removes value indexed in table
    {
        ComparableAssociation target = 
	    new ComparableAssociation((Comparable)key,null);
        target = (ComparableAssociation)data.remove(target);
	if (target == null) return null;
	else return target.value();
    }

    /**
     * Determine the number of key-value pairs within the table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of key-value pairs in table
     * </dl>
     * 
     * @return The number of key-value pairs in the table.
     */
    public int size()
    // post: returns number of key-value pairs in table
    {
        return data.size();
    }

    /**
     * Construct a string representing value of table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation
     * </dl>
     * 
     * @return String representing table.
     */
    public String toString()
    // post: returns string representation
    {
	StringBuffer s = new StringBuffer();
	s.append("<Table: size="+size());
	Iterator ti = data.elements();
	while (ti.hasMoreElements()) {
	    ComparableAssociation ca = (ComparableAssociation)ti.nextElement();
	    s.append(" key="+ca.key()+", value="+ca.value());
	}
	s.append(">");
	return s.toString();
    }
}

// Generic base class for describing edges in graphs.
// (c) 1998 McGraw-Hill

package structure;

/**
 * A class implementing common edge type among graphs.  This class
 * supports both directed and undirected edges.  Edge may also have
 * visited flags set and cleared.
 *
 * @version $Id: ComparableEdge.java,v 3.0 1998/01/29 14:10:57 bailey Exp $
 * @author duane a. bailey
 * @see structure.Graph
 */
public class ComparableEdge extends Edge implements Comparable
{
    /**
     * Construct a (possibly directed) edge between two labeled
     * vertices.  When edge is directed, vtx1 specifies source.
     * When undirected, order of vertices is unimportant.  Label
     * on edge is any type, and may be null.
     * Edge is initially unvisited.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> edge associates vtx1 and vtx2. labeled with label.
     *       directed if "directed" set true
     * </dl>
     *
     * @param vtx1 The label of a vertex (source if directed).
     * @param vtx2 The label of another vertex (destination if directed).
     * @param label The label associated with the edge.
     * @param directed True iff this edge is directed.
     */
    public ComparableEdge(Object vtx1, Object vtx2, Object label,
		boolean directed)
    // post: edge associates vtx1 and vtx2. labeled with label.
    //       directed if "directed" set true
    {
	super(vtx1,vtx2,label,directed);
    }

    /**
     * Construct a (possibly directed) edge between two labeled
     * vertices.  When edge is directed, vtx1 specifies source.
     * When undirected, order of vertices is unimportant.  Label
     * on edge is any type, and may be null.
     * Edge is initially unvisited.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> edge associates vtx1 and vtx2. labeled with label.
     *       directed if "directed" set true
     * </dl>
     *
     * @param e The edge to be used as the basis for a comparable edge
     */
    public ComparableEdge(Edge e)
    // post: edge associates vtx1 and vtx2. labeled with label.
    //       directed if "directed" set true
    {
	this(e.here(),e.there(),e.label(),e.isDirected());
    }

    /**
     * Compare edge, based on labels.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> labels are Comparable
     * <dt><b>Postcondition:</b><dd> returns integer representing relation between labels.
     */
    public int compareTo(Object other)
    // pre: labels are Comparable
    // post: returns integer representing relation between labels on edges.
    {
	Comparable thisLabel = (Comparable)label();
	Comparable thatLabel = (Comparable)((Edge)other).label();
	return thisLabel.compareTo(thatLabel);
    }

    /**
     * Construct a string representation of edge.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of edge
     * </dl>
     * 
     * @return String representing edge.
     */
    public String toString()
    // post: returns string representation of edge
    {
	StringBuffer s = new StringBuffer();
	s.append("<Edge:");
	if (visited) s.append(" visited");
	s.append(" "+here());
	if (directed) s.append(" <->");
	else s.append("->");
	s.append(" "+there()+">");
	return s.toString();
    }
}

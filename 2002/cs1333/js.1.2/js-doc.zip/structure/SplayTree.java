// This is a implementation of splay trees, in Java.
// (c) 1996, 1997, 1998 duane a. bailey
// (c) 1998 McGraw-Hill
package structure;

/**
 * An implementation of binary search trees, based on a splay operation
 * by Tarjan et al.  An extension of the binary search tree class.
 *
 * @version $Id: SplayTree.java,v 3.1 1998/01/19 14:51:27 bailey Exp bailey $
 * @author duane a. bailey
 */
public class SplayTree extends BinarySearchTree
{
    /**
     * Construct an empty search tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> construct a new splay tree
     * </dl>
     * 
     */
    public SplayTree()
    // post: construct a new splay tree
    {
	root = null;
	count = 0;
    }

    /**
     * Add a value to the splay tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds a value to the binary search tree.
     * </dl>
     * 
     * @param val The value to be added.
     */
    public void add(Object val)
    // pre: val is non-null
    // post: adds a value to the binary search tree
    {
	BinaryTreeNode newNode = new BinaryTreeNode(val);

	// add value to binary search tree 
	// if there's no root, create value at root.
	if (root == null)
	{
	    root = newNode;
	}
	else
	{
	    Comparable value = (Comparable)val;
	    BinaryTreeNode insertLocation = locate(root,value);
	    Comparable nodeValue = (Comparable)insertLocation.value();

	    // The location returned is the successor or predecessor
	    // of the to-be-inserted value.

	    if (nodeValue.compareTo(value) < 0) {
		insertLocation.setRight(newNode);
	    } else {
		if (insertLocation.left() != null) {
		    // if value is in array, we insert just before
		    predecessor(insertLocation).setRight(newNode);
		} else {
		    insertLocation.setLeft(newNode);
		}
	    }
	    splay(root = newNode);
	}
	count++;
    }

    /**
     * Determine if a particular comparable value is within the search tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff val is a value found within the tree
     * </dl>
     * 
     * @param val The comparable value to be found.
     * @return True iff the comparable value is within the tree.
     */
    public boolean contains(Object val)
    // pre: val is non-null
    // post: returns true iff val is a value found within the tree
    {
	if (root == null) return false;

	BinaryTreeNode possibleLocation = locate(root,(Comparable)val);
	if (val.equals(possibleLocation.value())) {
	    splay(root = possibleLocation);
	    return true;
	} else {
	    return false;
	}
    }

    /**
     * Fetch a reference to the comparable value in the tree.
     * Resulting value may be inspected, but should not be modified in
     * a way that might change its position within tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns object found in tree, or null
     * </dl>
     * 
     * @param val The value to be sought in tree.
     * @return A reference to the value within the tree.
     */
    public Object get(Object val)
    // pre: val is non-null
    // post: returns object found in tree, or null
    {
	if (root == null) return null;

	BinaryTreeNode possibleLocation = locate(root,(Comparable)val);
	splay(root = possibleLocation);
	if (val.equals(possibleLocation.value()))
	    return possibleLocation.value();
	else
	    return null;
    }

    /**
     * Remove a comparable value from the tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes one instance of val, if found
     * </dl>
     * 
     * @param val The value to be removed.
     * @return The actual value removed.
     */
    public Object remove(Object val) 
    // pre: val is non-null
    // post: removes one instance of val, if found
    {
	// remove value from a binary search tree
	// no root, just quit
	Comparable cval = (Comparable)val;

	if (isEmpty()) return null;
      
	if (val.equals(root.value())) // delete root value
	{
	    BinaryTreeNode newroot = removeTop(root);
	    count--;
	    Object result = root.value();
	    root = newroot;
	    return result;
	}
	else
	{
	    BinaryTreeNode location = locate(root,cval);

	    if (cval.equals(location.value())) {
		count--;
		BinaryTreeNode parent = location.parent();
		if (parent.right() == location) {
		    parent.setRight(removeTop(location));
		} else {
		    parent.setLeft(removeTop(location));
		}
		splay(root = parent);
		return location.value();
	    }
	}
	return null;
    }

    protected void splay(BinaryTreeNode splayedNode)
    // pre: splayedNode is non-null node within tree
    // post: splayed node becomes root
    {
        BinaryTreeNode parent,grandParent;

        while ((parent = splayedNode.parent()) != null)
	{
    	    if ((grandParent = parent.parent()) == null)
	    {
 	        if (splayedNode.isLeftChild()) parent.rotateRight();
	        else parent.rotateLeft();
	    }
	    else
	    {
	        if (parent.isLeftChild())
		{
		    if (splayedNode.isLeftChild())
		    {
                        // notice the order of this rotation.
                        // not doing this in order works, but not
                        // efficiently.
		        grandParent.rotateRight();
		        parent.rotateRight();
		    }
		    else
		    {
		        parent.rotateLeft();
		        grandParent.rotateRight();
		    }
	        }
		else
		{
		    if (splayedNode.isRightChild()) {
		        grandParent.rotateLeft();
		        parent.rotateLeft();
		    }
		    else
		    {
		        parent.rotateRight();
		        grandParent.rotateLeft();
		    }
	        }
	    }
        }
    }

    /**
     * Construct an inorder traversal of the elements in the splay tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator that traverses tree nodes in order
     * </dl>
     * 
     * @return An iterator to traverse the tree.
     */
    public Iterator elements()
    // post: returns iterator that traverses tree nodes in order
    {
	return new SplayTreeIterator(root);
    }

    /**
     * Construct a string that represents the splay tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation
     * </dl>
     * 
     * @return A string representing the tree.
     */
    public String toString()
    // post: returns string representation
    {
	StringBuffer s = new StringBuffer();
	s.append("<SplayTree: size="+count+" root="+root+">");
	return s.toString();
    }
}

/**
 * An iterator to traverse a splay tree.
 * 
 * @version $Id: SplayTree.java,v 3.1 1998/01/19 14:51:27 bailey Exp bailey $
 * @author duane a. bailey
 */
class SplayTreeIterator implements Iterator
{
    /**
     * A reference to the root of a splay tree.
     */
    protected BinaryTreeNode tree; // node of splay tree, root computed
    /**
     * The current node being considered in tree.
     */
    protected BinaryTreeNode current; // current node
    // In this iterator, the "stack" normally used is implied by 
    // looking back up the path from the current node.  Those nodes
    // for which the path goes left are on the stack

    /**
     * Construct an iterator that traverses the binary search 
     * tree based at the root.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> root is the root of the tree to be traversed
     * <dt><b>Postcondition:</b><dd> constructs a new iterator to traverse splay tree
     * </dl>
     * 
     * @param root The root of the subtree to be traversed.
     */
    public SplayTreeIterator(BinaryTreeNode root)
    // pre: root is the root of the tree to be traversed
    // post: constructs a new iterator to traverse splay tree
    {
	this.tree = root;
	reset();
    }

    /**
     * Reset the iterator to reference the root of the tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets iterator to smallest node in tree
     * </dl>
     */
    public void reset()
    // post: resets iterator to smallest node in tree
    {
	current = tree;
	if (current != null) {
	    while (current.parent() != null) current = current.parent();
	    while (current.left() != null) current = current.left();
	}
    }

    /**
     * Determine if the iterator has more nodes to be considered.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if there are unvisited nodes
     * </dl>
     * 
     * @return True iff the iterator has more nodes to be considered.
     */
    public boolean hasMoreElements()
    // post: returns true if there are unvisited nodes
    {
	return current != null;
    }

    /**
     * Returns reference to the current element, and increments iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current element and increments iterator
     * </dl>
     * 
     * @return The reference to the current element before incrementing.
     */
    public Object nextElement()
    // pre: hasMoreElements()
    // post: returns current element and increments iterator
    {
	Object result = current.value();
	if (current.right() != null) {
	    current = current.right();
	    while (current.left() != null)
	    {
		current = current.left();
	    }
	} else {
	    // we're finished with current's subtree.  We now "pop" off
	    // nodes until we come to the parent of a leftchild ancestor
	    // of current
	    boolean lefty;
	    do
	    {
		lefty = current.isLeftChild();
		current = current.parent();
	    } while (current != null && !lefty);
	}
	return result;
    }
    
    /**
     * Return a reference to the current value.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current value.
     * </dl>
     * 
     * @return A reference to the current value.
     */
    public Object value()
    // pre: hasMoreElements()
    // post: returns current value
    {
	return current.value();
    }
}

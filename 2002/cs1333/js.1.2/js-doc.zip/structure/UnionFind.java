// A forest implementation of the Union-Find structure.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of a union-find structure.
 * The universe consists of a number of values between 0 and n-1
 * These elements, initially, are all in their own set, labeled 0..n-1
 * respectively.  Sets may be unioned.  The resulting set takes on
 * the identity of one of the two originals.  In addition, the
 * elements may be found in a set --- the result is the integer-label
 * of the set containing the element.  
 *
 * @version $Id: UnionFind.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public class UnionFind
{
    /**
     * The list of elements
     */
    protected UnionFindElement element[];
    /**
     * Construct a union-find set with elementCount elements.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> elementCount >= 0
     * <dt><b>Postcondition:</b><dd> constructs elementCount disjoint sets labeled 0..elementCount-1
     * </dl>
     * 
     * @param elementCount The number of elements in the universe.
     */
    public UnionFind(int elementCount)
    // pre: elementCount >= 0
    // post: constructs elementCount disjoint sets labeled 0..elementCount-1
    {
	int i;

	element = new UnionFindElement[elementCount];
	for (i = 0; i < elementCount; i++)
	{
	    element[i] = new UnionFindElement(i);
	}
    }

    /**
     * Find the number of the set containing the desired element.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= i < elementCount
     * <dt><b>Postcondition:</b><dd> returns the index or name of the set containing i
     * </dl>
     * 
     * @param i The element index.
     * @return The index of the set.
     */
    public int find(int i)
    // pre: 0 <= i < elementCount
    // post: returns the index or name of the set containing i
    {
	int name = i;
	if (element[i].setName != i) {
	    name = find(element[i].setName);
	    element[i].setName = name;
	}
	return name;
    }

    /**
     * Merge sets containing elements i and j.
     * The identity of the ultimate set is the identity of one of
     * the (possibly) two sets that contained i and j.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= i,j < elementCount
     * <dt><b>Postcondition:</b><dd> merges sets containing i and j, and returns new set name.
     * </dl>
     * 
     * @param i An element identifying one set.
     * @param j An element identifying another set.
     * @return The index of the set that is the union of the two sets containing i and j.
     */
    public int union(int i,int j)
    // pre: 0 <= i,j < elementCount
    // post: merges sets containing i and j, and returns new set name.
    {
	i = find(i);
	j = find(j);
	if (i == j) return i;
	if (element[i].size < element[j].size) 
	{ int temp = i; i = j; j = temp; }
	// set i is as large as j
	element[j].setName = i;
	element[i].size += element[j].size;
	return i;
    }

    /**
     * Construct a string representation of the union-find universe.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of sets
     * </dl>
     * 
     * @return A string representing the sets in the union-find structure.
     */
    public String toString()
    // post: returns string representation of sets
    {
	int i,j,first;
	int size = element.length;
	StringBuffer sb = new StringBuffer();

	sb.append("{UnionFind:");
	for (i = 0; i < size; i++)
	{
	    if (element[i].setName == i) {
		sb.append(" {");
		for (j = 0, first = 1; j < size; j++)
		{
		    if (element[j].setName == i)
		    {
			if (first == 1) sb.append(j);
			else sb.append(" "+j);
			first = 0;
		    }
		}
		sb.append("}");
	    }
	}
	sb.append("}");
	return sb.toString();
    }
}

/**
 * A single element of the union-find universe.
 * 
 * @version $Id: UnionFind.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
class UnionFindElement
{
    /**
     * The number of elements in this set.
     * Only meaningful if this element has the same name as its set.
     */
    protected int size;
    /**
     * The name of this element.
     */
    protected int name;
    /*
     * The name of the set containing this element
     */
    protected int setName;

    /**
     * Construct a union find element, numbered i.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new set, with label i
     * </dl>
     * 
     * @param i The label of the union find element.
     */
    public UnionFindElement(int i)
    // post: constructs a new set, with label i
    {
	size = 1;
	name = setName = i;
    }

    /**
     * Determine a string representing the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of set
     * </dl>
     * 
     * @return A string representing the set.
     */
    public String toString()
    // post: returns string representation of set
    {
	return "<UnionFindElement: "+name+" in set "+setName+">";
    }
}

// An interface for Binary Trees.
// (c) 1998 McGraw-Hill
package structure;

/**
 * A binary tree.  
 * Every node refers to as many as two other nodes in the tree.  Each
 * node, in addition, as at most one parent.  The root node, is the
 * unique node with no parent.
 * <p>
 * Associated with the binary tree is a cursor.  This reference points
 * to a current node within the tree, or it is null.  When the tree
 * is first created it is empty, with a null cursor (there is nothing
 * to refer to).  When a node is added, it is added at the location 
 * indicated by the cursor.  The cursor may be moved about with
 * the "move" methods.  When the cursor "falls off" the tree at a current
 * leaf, a new value may be added at that location.
 * <p>
 * Standard pre-, post-, in-, and level-order traversals are provided
 *
 * 
 * @version $Id: BinaryTree.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public class BinaryTree
{
    /**
     * A reference to the unique root of the tree
     */
    protected BinaryTreeNode root;   // the root of the binary tree
    /**
     * A reference to the "current" node of the tree, or null
     */
    protected BinaryTreeNode cursor; // pointer to the current node
    /**
     * If cursor is null, prior points to the last non-null value
     * of the  cursor.  This node will be parent of new value added.
     */
    protected BinaryTreeNode prior;  // cursor's prior value
    /**
     * An indication of direction that cursor last went, when it fell
     * off the tree.  This suggests the relation between any newly
     * added data and the prior node, the new parent.
     */
    protected boolean wentLeft;      // cursor result of moving left
    /**
     * The number of nodes found within the tree
     */
    protected int size;		     // the size of the tree

    /**
     * Construct an empty binary tree.  The tree is empty, no root
     * exists, and the cursor is null.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Creates an empty binary tree
     * </dl>
     */
    public BinaryTree()
    // post: creates an empty binary tree
    {
	clear();
    }

    /**
     * Remove values from tree.  The tree is made empty; all memory
     * associated with nodes is freed.  Cursor is made null.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Removes all nodes from tree
     * </dl>
     */
    public void clear()
    // post: removes all nodes from tree
    {
	root = null;
	cursor = null;
	prior = null;
	size = 0;
	wentLeft = false;	// arbitrary
    }

    /**
     * Add a value to the tree.  The value is added to the location
     * suggested by the cursor.  If the cursor and root are both null
     * value is added to the root of the currently empty tree.  If root
     * is non-null, the value is added as the left child of the prior
     * node if the cursor became invalid by moving left from the prior
     * node.  Otherwise it is made the right child of the prior node.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is null (invalid)
     * <dt><b>Postcondition:</b><dd> If tree is empty, value is inserted at root, otherwise
     *       value is inserted where cursor last moved off tree
     * </dl>
     * 
     * @param value The value to be added to the tree.
     */
    public void insert(Object value)
    // pre: cursor is null (invalid)
    // post: if tree is empty, value is inserted at root; otherwise
    //       value is inserted where cursor last moved off tree
    {
	Assert.pre(cursor == null,"Insertion does not overwrite value.");
	if (prior == null) {
	    Assert.pre(root == null,
		       "Insertion at root only allowed in empty tree.");
	    cursor = root = new BinaryTreeNode(value);
	} else {
	    if (wentLeft) {
		prior.setLeft(cursor = new BinaryTreeNode(value));
	    } else {
		prior.setRight(cursor = new BinaryTreeNode(value));
	    }
	}
	size++;
    }

    /**
     * Remove value at cursor.  Node referenced by cursor should be a leaf.
     * The value at the cursor is removed
     * and the cursor is moved upward to parent, or becomes null
     * if cursor points to root.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is valid and has no children
     * <dt><b>Postcondition:</b><dd> Leaf is removed, cursor is moved to parent, if any
     * </dl>
     * 
     * @return The value removed from tree
     */
    public Object remove()
    // pre: cursor is valid and has no children
    // post: leaf is removed; cursor is moved to parent, if any
    {
	Assert.pre(cursor != null,"Node to be removed exists.");
	Assert.pre(!(hasLeft()||hasRight()),
		   "Node to be removed is leaf.");
	Object value = cursor.value();
	if (isLeftChild()) {
	    moveUp();
	    cursor.setLeft(null);
	} else if (isRightChild()) {
	    moveUp();
	    cursor.setRight(null);
	} else {
	    root = cursor = prior = null;
	}
	size--;
	return value;
    }

    /**
     * Return cursor's value.  Provided the cursor is non-null,
     * this method returns the value stored in the referenced node.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor valid
     * <dt><b>Postcondition:</b><dd> Returns value of object at cursor
     * </dl>
     * 
     * @return The value associated with the cursor
     */
    public Object value()
    // pre: cursor valid
    // post: returns value of object at cursor
    {
	return cursor.value();
    }

    /**
     * Change value of the node referred to by cursor.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor valid
     * <dt><b>Postcondition:</b><dd> Sets value found at cursor
     * </dl>
     * 
     * @param value The new value of the cursor-referenced node.
     */
    public void setValue(Object value)
    // pre: cursor valid
    // post: sets value found at cursor
    {
	cursor.setValue(value);
    }

    /**
     * Sets cursor to root of tree.  If no root exists, cursor
     * remains null.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Moves the cursor to the root, if any
     * </dl>
     */
    public void reset()
    // post: moves the cursor to the root, if any
    {
	cursor = root;
	prior = null;
	wentLeft = false; // arbitrary
    }

    /**
     * Checks validity of cursor.  Cursor is valid if it is pointing
     * to an existing node of the tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true if the cursor points to a valid node.
     * </dl>
     * 
     * @return True iff the cursor refers to a node of the tree.
     */
    public boolean valid()
    // post: returns true if the cursor points to a valid node
    {
	return cursor != null;
    }

    /**
     * Perform a left rotation about cursor.  The relation between
     * the cursor node and its right child are reversed.  Left child
     * of right child becomes right child of cursor.  Cursor becomes
     * left child of right child.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is valid, has right child
     * <dt><b>Postcondition:</b><dd> Rotates the tree to left about cursor
     *       cursor points to new root of subtree
     * </dl>
     */
    public void rotateLeft()
    // pre: cursor is valid, has right child
    // post: rotates the tree to left about cursor.
    //       cursor points to new root of subtree
    {
	Assert.pre(hasRight(),"Current node has right child.");
	cursor.rotateLeft();
	moveUp();
	if (root.parent() != null) root = root.parent();
    }

    /**
     * Perform a right rotation about cursor.  The relation between
     * the cursor node and its left child are reversed.  Right child
     * of left child becomes left child of cursor.  Cursor becomes
     * right child of left child.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is valid, has left child
     * <dt><b>Postcondition:</b><dd> Rotates the tree to left about cursor.
     *       cursor points to new root of subtree
     * </dl>
     * 
     */
    public void rotateRight()
    // pre: cursor is valid, has left child
    // post: rotates the tree to left about cursor
    //       cursor points to new root of subtree
    {
	Assert.pre(hasLeft(),"Current node has left child.");
	cursor.rotateRight();
	moveUp();
	if (root.parent() != null) root = root.parent();
    }

    /**
     * Check for left child.  If cursor has left child, returns
     * true.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff cursor has left child
     * </dl>
     * 
     * @return True iff cursor has left child.
     */
    public boolean hasLeft()
    // post: returns true iff cursor has left child
    {
	return (cursor != null) && (cursor.left() != null);
    }

    /**
     * Check for right child.  If cursor has right child, returns
     * true.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff cursor has right child 
     * </dl>
     * 
     * @return True iff cursor has right child.
     */
    public boolean hasRight()
    // post: returns true iff cursor has right child 
    {
	return (cursor != null) && (cursor.right() != null);
    }

    /**
     * Checks for parent.  Returns true if cursor has a parent node.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is valid
     * <dt><b>Postcondition:</b><dd> Returns true iff cursor has parent
     * </dl>
     * 
     * @return True iff cursor has parent.
     */
    public boolean hasParent()
    // pre: cursor is valid
    // post: returns true iff cursor has parent
    {
	return (cursor != null) && (cursor.parent() != null);
    }

    /**
     * Checks if cursor is a left child.  If cursor is left child of
     * its parent, returns true.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true if cursor has parent and is left child
     * </dl>
     * 
     * @return True iff cursor is left child of its parent.
     */
    public boolean isLeftChild()
    // post: returns true if cursor has parent and is left child
    {
	return (cursor != null) && cursor.isLeftChild();
    }

    /**
     * Checks if cursor is a right child.  If cursor is a right child of
     * its parent, returns true.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true if cursor has parent and is right child
     * </dl>
     * 
     * @return True iff cursor is a right child of its parent.
     */
    public boolean isRightChild()
    // post: returns true if cursor has parent and is right child
    {
	return (cursor != null) && cursor.isRightChild();
    }

    /**
     * Move cursor to left.  If cursor is valid, cursor refers
     * to left child of current node, or null, if none.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is valid
     * <dt><b>Postcondition:</b><dd> Cursor moves to left child of precursor, or off tree
     * </dl>
     */
    public void moveLeft()
    // pre: cursor is valid
    // post: cursor moves to left child of precursor, or off tree
    {
	prior = cursor;
	wentLeft = true;
	cursor = cursor.left();
    }

    /**
     * Move cursor to right.  If cursor is valid, cursor refers
     * to right child of current node, or null, if none.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is valid
     * <dt><b>Postcondition:</b><dd> Cursor moves to right child of precursor, or off tree
     * </dl>
     * 
     */
    public void moveRight()
    // pre: cursor is valid
    // post: cursor moves to right child of precursor, or off tree
    {
	prior = cursor;
	wentLeft = false;
	cursor = cursor.right();
    }

    /**
     * Moves up the tree.  If cursor has parent, cursor points to parent.
     * Otherwise cursor becomes null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Cursor is valid
     * <dt><b>Postcondition:</b><dd> Cursor moves up to parent of precursor.
     * </dl>
     */
    public void moveUp()
    // pre: cursor is valid
    // post: cursor moves up to parent of precursor
    {
	prior = null;
	cursor = cursor.parent();
    }

    /**
     * Returns height of node in tree.  Height is the maximum number of edges
     * between current node and any descendant.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns height of cursor in tree
     *       or -1 if tree is empty
     * </dl>
     * 
     * @return Height of node in tree.
     */
    public int height()
    // post: returns height of cursor in tree
    //       or -1 if tree is empty
    {
	return BinaryTreeNode.height(cursor);
    }

    /**
     * Returns depth of node in tree.  Depth is the number of edges
     * traversed in unique path to root.
     <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns depth of cursor in tree
     *       or -1 if tree is empty
     * </dl>
     * 
     * @return Depth of cursor node in tree.
     */
    public int depth()
    // post: returns depth of cursor in tree
    //       or -1 if tree is empty
    {
	return BinaryTreeNode.depth(cursor);
    }

    /**
     * Detects a full tree rooted at cursor.  A tree is full
     * if adding a node to the tree would increase its height.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff subtree rooted at cursor is full
     * </dl>
     * 
     * @return True iff adding a node to subtree requires increasing height.
     */
    public boolean isFull()
    // post: returns true iff subtree rooted at cursor is full
    {
	return BinaryTreeNode.isFull(cursor);
    }

    /**
     * Detect a complete tree rooted at cursor.  A tree is complete
     * if it is minimum height and any "holes" in the tree appear only to
     * the right in last level.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff subtree rooted at cursor is complete
     * </dl>
     * 
     * @return True iff tree is complete.
     */
    public boolean isComplete()
    // post: returns true iff subtree rooted at cursor is complete
    {
	return BinaryTreeNode.isComplete(cursor);
    }

    /**
     * Returns true iff tree has no data.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff tree is empty
     * </dl>
     * 
     * @return True iff tree has no data.
     */
    public boolean isEmpty()
    // post: returns true iff tree is empty
    {
	return size == 0;
    }

    /**
     * The number of nodes in the tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns number of nodes in tree
     * </dl>
     * 
     * @return The number of nodes in the tree.
     */
    public int size()
    // post: returns number of nodes in tree
    {
	return size;
    }

    /**
     * Returns an iterator that traverses tree in-order.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns inorder traversal of tree
     * </dl>
     * 
     * @return An Iterator for traversing tree in order.
     */
    public Iterator elements()
    // post: returns inorder traversal of tree
    {
	return inorderElements();
    }

    /**
     * Returns an iterator that traverses tree in-order.
     * The root of a subtree is visited after all the nodes
     * of the left subtree, and before all the nodes of the
     * right subtree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns inorder traversal of tree
     * </dl>
     * 
     * @return An Iterator for traversing tree in order.
     */
    public Iterator inorderElements()
    // post: returns inorder traversal of tree
    {
	return new BTInorderIterator(root);
    }

    /**
     * Returns pre-order iterator.  The iterator considers
     * the root of a subtree before any of its values.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns preorder traversal of tree
     * </dl>
     * 
     * @return Iterator traversing tree in pre-order.
     */
    public Iterator preorderElements()
    // post: returns preorder traversal of tree
    {
	return new BTPreorderIterator(root);
    }

    /**
     * Returns post-order iterator.  The iterator considers
     * the root of a subtree after any of its values.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns postorder traversal of tree
     * </dl>
     * 
     * @return Iterator traversing tree in post-order.
     */
    public Iterator postorderElements()
    // post: returns postorder traversal of tree
    {
	return new BTPostorderIterator(root);
    }

    private void format(BinaryTreeNode n,StringBuffer sb)
    // pre: sb non-null, n non-null
    // post: appends to sb a string representation of subtree rooted at n
    {
	if (n.left() == null && n.right() == null) {
	    sb.append(" "+n.value());
	} else {
	    sb.append(" ("+n.value());
	    if (n.left() != null) format(n.left(),sb);
	    else sb.append(" -");
	    if (n.right() != null) format(n.right(),sb);
	    sb.append(")");
	}
    }

    /**
     * Constructs string representation of tree.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns string representation of tree
     * </dl>
     * 
     * @return String describing tree.
     */
    public String toString()
    // post: returns string representation of tree
    {
	StringBuffer sb = new StringBuffer();
	sb.append("<BinaryTree:");
	if (root != null) format(root,sb);
	sb.append(">");
	return sb.toString();
    }
}

// An implementation of hashtables, using external chaining
// Keys need not be comparable.
// (c) 1998 McGraw-Hill

package structure;
import java.lang.Math;
/**
 * This class implements a hash table whose collisions are resolved
 * through external chaining.  Values used as keys in this structure
 * must have a hashcode method that returns the same value when two
 * keys are "equals".  Initially, a hash table of suggested size is
 * allocated.
 *
 * @version $Id: ChainedHashtable.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 * @see structure.Hashtable
 * @see java.util.Hashtable
 */
public class ChainedHashtable implements Dictionary
{
    /**
     * The array of chains used to store values.
     */
    protected List data[];
    /**
     * The number of key-value pairs stored within the table.
     */
    protected int count;
    /**
     * The length of the table.
     */
    protected int capacity;

    /**
     * Constructs a hashtable with capacity for at size elements
     * before chaining is absolutely required.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> size > 0
     * <dt><b>Postcondition:</b><dd> constructs a new ChainedHashtable
     * </dl>
     * 
     * @param size The number of entries initially allocated.
     */
    public ChainedHashtable(int size)
    // pre: size > 0
    // post: constructs a new ChainedHashtable
    {
    	data = new List[size];
    	capacity = size;
    	count = 0;
    }

    /**
     * Constructs a reasonably large hashtable.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new ChainedHashtable
     * </dl>
     */
    public ChainedHashtable()
    // post: constructs a new ChainedHashtable
    {
	this(997);
    }

    /**
     * Removes the values from the hashtable.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all the elements from the ChainedHashtable.
     * </dl>
     */
    public void clear()
    //post: removes all elements from ChainedHashtable
    {
	int i;
	for (i = 0; i < capacity; i++) {
	    data[i].clear();
	}
	count = 0;
    }

    /**
     * Computes the number of elements stored within the hashtable.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements in hash table
     * </dl>
     * 
     * @return The number of elements within the hash table.
     */
    public int size()
    // post: returns number of elements in hash table
    {
	return count;
    }

    /**
     * Returns true if no elements are stored within the table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff hash table has 0 elements
     * </dl>
     * 
     * @return True iff size() == 0.
     */
    public boolean isEmpty()
    // post: returns true iff hash table has 0 elements
    {
	return size() == 0;
    }

    protected List locate(Object key)
    // post: returns list potentially containing key, if in table
    {
	int hash = Math.abs(key.hashCode() % capacity);
	if (data[hash] == null) data[hash] = new SinglyLinkedList();
	return data[hash];
    }

    /**
     * Returns true if a specific value appears within the table.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null Object
     * <dt><b>Postcondition:</b><dd> returns true iff hash table contains value
     * </dl>
     * 
     * @param value The value sought.
     * @return True iff the value appears within the table.
     */
    public boolean contains(Object value)
    // pre: value is non-null Object
    // post: returns true iff hash table contains value
    {
	Iterator elements = elements();

	while (elements.hasMoreElements())
	{
	    if (value.equals(elements.nextElement())) return true;
	}
	return false;
    }

    /**
     * Returns true iff a specific key appears within the table.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null key
     * <dt><b>Postcondition:</b><dd> returns true if key appears in hash table
     * </dl>
     * 
     * @param key The key sought.
     * @return True iff the key sought appears within table.
     */
    public boolean containsKey(Object key)
    // pre: value is non-null key
    // post: returns true if key appears in hash table
    {
	List l = locate(key);
	return l.contains(new Association(key,null));
    }

    /**
     * Returns an iterator that traverses over the values of the
     * hashtable.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator to traverse hash table
     * </dl>
     * 
     * @return A value iterator, over the values of the table.
     */
    public Iterator elements()
    // post: returns iterator to traverse hash table
    {
    	return new ValueIterator(new ChainedHashtableIterator(data));
    }

    /**
     * Get the value associated with a key.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null Object
     * <dt><b>Postcondition:</b><dd> returns value associated with key, or null
     * </dl>
     * 
     * @param key The key used to find the desired value.
     * @return The value associated with the desired key.
     */
    public Object get(Object key)
    // pre: key is non-null Object
    // post: returns value associated with key, or null
    {
	List l = locate(key);
	Association a = (Association)l.remove(new Association(key,null));
	if (a == null) return null;
	l.addToHead(a);
	return a.value();
    }

    /**
     * Get an iterator over the keys of the hashtable.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator to traverse the keys of hash table.
     * </dl>
     * 
     * @return An iterator over the key values appearing within table.
     */
    public Iterator keys()
    // post: returns iterator to traverse the keys of hash table.
    {
    	return new KeyIterator(new ChainedHashtableIterator(data));
    }

    /**
     * Place a key-value pair within the table.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null object
     * <dt><b>Postcondition:</b><dd> key-value pair is added to hash table
     * </dl>
     * 
     * @param key The key to be added to table.
     * @param value The value associated with key.
     * @return The old value associated with key if previously present.
     */
    public Object put(Object key, Object value)
    // pre: key is non-null object
    // post: key-value pair is added to hash table
    {
	List l = locate(key);
	Association newa = new Association(key,value);
	Association olda = (Association)l.remove(newa);
	l.addToHead(newa);
	if (olda != null)
	{
	    return olda.value();
	}
	else
	{
	    count++;
	    return null;
	}
    }

    /**
     * Remove a key-value pair from the table.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null object
     * <dt><b>Postcondition:</b><dd> removes key-value pair associated with key
     * </dl>
     * 
     * @param key The key of the key-value pair to be removed.
     * @return The value associated with the removed key.
     */
    public Object remove(Object key)
    // pre: key is non-null object
    // post: removes key-value pair associated with key
    {
	List l = locate(key);
	Association pair = (Association)l.remove(new Association(key,null));
	if (pair == null) return null;
	count--;
	return pair.value();
    }

    /**
     * Generate a string representation of the chained hash table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representation of hash table.
     * </dl>
     * 
     * @return The string representing the table.
     */
    public String toString()
    // post: returns a string representation of hash table.
    {
	StringBuffer s = new StringBuffer();
	int i;

	s.append("<ChainedHashtable:");
	Iterator hi = new ChainedHashtableIterator(data);
	while (hi.hasMoreElements()) {
	    Association a = (Association)hi.nextElement();
	    s.append(" "+a.key()+"="+a.value());
	}
	s.append(">");
	return s.toString();
    }
}

/**
 * An iterator to traverse chained hash tables.
 * <p>
 * @version $Id: ChainedHashtable.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
class ChainedHashtableIterator implements Iterator
{
    /**
     * The list of values within the table.
     */
    protected List data;
    /**
     * The iterator over the elements of the list.
     */
    protected Iterator elements;

    /**
     * Construct an iterator over a chained hashtable.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new hash table iterator
     * </dl>
     * 
     * @param table The array of lists to be traversed.
     */
    public ChainedHashtableIterator(List[] table)
    // post: constructs a new hash table iterator
    {
	int i;
	int capacity = table.length;
	data = new SinglyLinkedList();
	for (i = 0; i < capacity; i++) {
	    if (table[i] != null) {
		Iterator els = table[i].elements();
		while (els.hasMoreElements())
		{
		    data.addToHead(els.nextElement());
		}
	    }
	}
	elements = data.elements();
    }

    /**
     * Resets the iterator to point to the beginning of the chained table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets iterator to beginning of hash table
     * </dl>
     */
    public void reset()
    // post: resets iterator to beginning of hash table
    {
	elements.reset();
    }

    /**
     * Returns true iff there are unconsidered elements within the table.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if there are unvisited elements
     * </dl>
     * 
     * @return True iff there are elements yet to be considered within table.
     */
    public boolean hasMoreElements()
    // post: returns true if there are unvisited elements
    {
	return elements.hasMoreElements();
    }

    /**
     * Returns current value and increments iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current element, increments iterator
     * </dl>
     * 
     * @return The current value, before incrementing.
     */
    public Object nextElement()
    // pre: hasMoreElements()
    // post: returns current element, increments iterator
    {
	return elements.nextElement();
    }

    /**
     * Get current value of iterator.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns current element
     * </dl>
     * 
     * @return The current value.
     */
    public Object value()
    // post: returns current element
    {
	return elements.value();
    }
}

// The interface for stacks.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An interface describing a Last-In, First-Out structure.
 * Stacks are typically used to store the state of a recursively
 * solved problem.
 * 
 * @version $Id: Stack.java,v 3.2 1998/01/26 19:31:15 bailey Exp $
 * @author duane a. bailey
 */
public interface Stack extends Linear
{
    /**
     * Add an element from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> item is added to stack
     *       will be popped next if no intervening add
     * </dl>
     * 
     * @param item The element to be added to the stack top.
     * @see #push
     */
    public void add(Object item);
    // post: item is added to stack
    //       will be popped next if no intervening add

    /**
     * Add an element to top of stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> item is added to stack
     *       will be popped next if no intervening push
     * </dl>
     * 
     * @param item The value to be added to the top of the stack.
     */
    public void push(Object item);
    // post: item is added to stack
    //       will be popped next if no intervening push

    /**
     * Remove an element from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> most recently added item is removed and returned
     * </dl>
     * 
     * @return The item removed from the top of the stack.
     * @see #pop
     */
    public Object remove();
    // pre: stack is not empty
    // post: most recently added item is removed and returned

    /**
     * Remove an element from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> most recently pushed item is removed and returned
     * </dl>
     * 
     * @return A reference to the removed element.
     */
    public Object pop();
    // pre: stack is not empty
    // post: most recently pushed item is removed and returned

    /**
     * Fetch a reference to the top element of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> top value (next to be popped) is returned
     * </dl>
     * 
     * @return A reference to the top element of the stack.
     */
    public Object peek();
    // pre: stack is not empty
    // post: top value (next to be popped) is returned

    /**
     * Returns true iff the stack is empty.  Provided for
     * compatibility with java.util.Vector.empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if and only if the stack is empty
     * </dl>
     * 
     * @return True iff the stack is empty.
     * @see structure.Store#isEmpty
     */
    public boolean empty();
    // post: returns true if and only if the stack is empty
}

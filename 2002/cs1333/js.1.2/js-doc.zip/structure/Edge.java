// Generic base class for describing edges in graphs.
// (c) 1998 McGraw-Hill

package structure;

/**
 * A class implementing common edge type among graphs.  This class
 * supports both directed and undirected edges.  Edge may also have
 * visited flags set and cleared.
 *
 * @version $Id: Edge.java,v 3.3 1998/02/24 17:10:29 bailey Exp bailey $
 * @author duane a. bailey
 * @see structure.Graph
 */
public class Edge
{
    /**
     * Two element array of vertex labels.
     * When necessary, first element is source.
     */
    protected Object[] vLabel;	// labels of adjacent vertices
    /**
     * Label associated with edge.  May be null.
     */
    protected Object label;     // edge label
    /**
     * Whether or not this edge has been visited.
     */
    protected boolean visited;  // this edge visited
    /**
     * Whether or not this edge is directed.
     */
    protected boolean directed; // this edge directed

    /**
     * Construct a (possibly directed) edge between two labeled
     * vertices.  When edge is directed, vtx1 specifies source.
     * When undirected, order of vertices is unimportant.  Label
     * on edge is any type, and may be null.
     * Edge is initially unvisited.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> edge associates vtx1 and vtx2. labeled with label.
     *       directed if "directed" set true
     * </dl>
     *
     * @param vtx1 The label of a vertex (source if directed).
     * @param vtx2 The label of another vertex (destination if directed).
     * @param label The label associated with the edge.
     * @param directed True iff this edge is directed.
     */
    public Edge(Object vtx1, Object vtx2, Object label,
		boolean directed)
    // post: edge associates vtx1 and vtx2; labeled with label;
    //       directed if "directed" set true
    {
	vLabel = new Object[2];
	vLabel[0] = vtx1;
	vLabel[1] = vtx2;
	this.label = label;
	visited = false;
	this.directed = directed;
    }

    /**
     * Returns the first vertex (or source if directed).
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns first node in edge
     * </dl>
     * 
     * @return A vertex; if directed, the source.
     */
    public Object here()
    // post: returns first node in edge
    {
	return vLabel[0];
    }

    /**
     * Returns the second vertex (or source if undirected).
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns second node in edge
     * </dl>
     * 
     * @return A vertex; if directed, the destination.
     */
    public Object there()
    // post: returns second node in edge
    {
	return vLabel[1];
    }

    /**
     * Sets the label associated with the edge.  May be null.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> sets label of this edge to label 
     * </dl>
     * 
     * @param label Any object to label edge, or null.
     */
    public void setLabel(Object label)
    // post: sets label of this edge to label 
    {
	this.label = label;
    }

    /**
     * Get label associated with edge.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns label associated with this edge
     * </dl>
     * 
     * @return The label found on the edge.
     */
    public Object label()
    // post: returns label associated with this edge
    {
	return label;
    }

    /**
     * Test and set visited flag on vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> visits edge, returns whether previously visited
     * </dl>
     * 
     * @return True iff edge was visited previously.
     */
    public boolean visit()
    // post: visits edge, returns whether previously visited
    {
	boolean was = visited;
	visited = true;
	return was;
    }

    /**
     * Check to see if edge has been visited.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff edge has been visited
     * </dl>
     * 
     * @return True iff the edge has been visited.
     */
    public boolean isVisited()
    // post: returns true iff edge is visited
    {
	return visited;
    }

    /**
     * Check to see if edge is directed.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff edge is directed.
     * </dl>
     * 
     * @return True iff the edge has been visited.
     */
    public boolean isDirected()
    // post: returns true iff edge is directed
    {
	return directed;
    }

    /**
     * Clear the visited flag associated with edge.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets edge's visited flag to initial state
     * </dl>
     */
    public void reset()
    // post: resets edge's visited flag to initial state
    {
	visited = false;
    }

    /**
     * Returns hashcode associated with edge.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns suitable hashcode.
     * </dl>
     * 
     * @return An integer code suitable for hashing.
     */
    public int hashCode()
    // post: returns suitable hashcode.
    {
	if (directed) return here().hashCode()-there().hashCode();
	else          return here().hashCode()^there().hashCode();
    }

    /**
     * Test for equality of edges.  Undirected edges are equal if
     * they connect the same vertices.  Directed edges must have same
     * direction.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff edges connect same vertices
     * </dl>
     * 
     * @param o The other edge.
     * @return True iff this edge is equal to other edge.
     */
    public boolean equals(Object o)
    // post: returns true iff edges connect same vertices
    {   
	Edge e = (Edge)o;
	return ((here().equals(e.here()) && 
		 there().equals(e.there())) ||
		(!directed &&
		 (here().equals(e.there()) && 
		  there().equals(e.here()))));
    }
    
    /**
     * Construct a string representation of edge.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of edge
     * </dl>
     * 
     * @return String representing edge.
     */
    public String toString()
    // post: returns string representation of edge
    {
	StringBuffer s = new StringBuffer();
	s.append("<Edge:");
	if (visited) s.append(" visited");
	s.append(" "+here());
	if (directed) s.append(" <->");
	else s.append("->");
	s.append(" "+there()+">");
	return s.toString();
    }
}

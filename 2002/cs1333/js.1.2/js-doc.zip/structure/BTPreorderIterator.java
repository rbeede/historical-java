// Pre-order iterator for binary trees.
// (c) 1998 McGraw-Hill
package structure;


/**
 * This class implements an iterator that traverses a tree in pre-order.
 * Each node is considered before its descendants.
 *
 * @version $Id: BTPreorderIterator.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class BTPreorderIterator implements Iterator
{
    /**
     * The root of the subtree to be considered by traversal.
     */
    protected BinaryTreeNode root; // root of tree to be traversed
    /**
     * The stack that maintains the state of the iterator.
     */
    protected Stack todo; // stack of unvisited nodes whose
                         // nontrivial ancestors have been visited

    /**
     * Constructs a pre-order traversal of subtree rooted at root.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an iterator to traverse in preorder
     * </dl>
     * 
     * @param root Root of subtree to be traversed.
     */
    public BTPreorderIterator(BinaryTreeNode root)
    // post: constructs an iterator to traverse in preorder
    {
	todo = new StackList();
	this.root = root;
	reset();
    }	

    /**
     * Resets the iterator to the first node of the traversal.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets the iterator to retraverse
     * </dl>
     */
    public void reset()
    // post: resets the iterator to retraverse
    {
	todo.clear();
	// stack is empty.  Push on the current node.
	if (root != null) todo.push(root);
    }

    /**
     * Returns true if some nodes of subtree have yet to be considered.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff iterator is not finished
     * </dl>
     * 
     * @return True iff more nodes to be considered in traversal.
     */
    public boolean hasMoreElements()
    // post: returns true iff iterator is not finished
    {
	return !todo.isEmpty();
    }

    /**
     * Returns the value currently being referenced by iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns reference to current value
     * </dl>
     * 
     * @return The current value.
     */
    public Object value()
    // pre: hasMoreElements()
    // post: returns reference to current value
    {	
	return ((BinaryTreeNode)todo.peek()).value();
    }

    /**
     * Returns the current value and increments the iterator.
     * Iterator is then incremented.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements();
     * <dt><b>Postcondition:</b><dd> returns current value, increments iterator
     * </dl>
     * 
     * @return The value currently being considered.
     */
    public Object nextElement()
    // pre: hasMoreElements();
    // post: returns current value, increments iterator
    {
	BinaryTreeNode old = (BinaryTreeNode)todo.pop();
	Object result = old.value();
	
	if (old.right() != null) todo.push(old.right());
	if (old.left() != null) todo.push(old.left());
	return result;
    }
}

// Implementation of value- iterators for driving Association iterators.
// (c) 1998  McGraw-Hill
package structure;

/**
 * A private master iterator for filtering the value fields from
 * an Association-returning iterator.
 * Used to construct iterators over dictionaries.
 * <p>
 * @version $Id: ValueIterator.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class ValueIterator implements Iterator
{
    /**
     * The underlying iterator.
     * The slave iterator provides the value iterator values which
     * are Associations.  The value iterator returns only the value-portion
     * of the Associations.	
     */
    protected Iterator slave;

    /**
     * Construct a new value iterator that filters the slave iterator,
     * an Association-returning iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> slave is an iterator returning Association elements
     * <dt><b>Postcondition:</b><dd> creates a new iterator returning associated values
     * </dl>
     * 
     * @param slave The slave iterator.
     */
    public ValueIterator(Iterator slave)
    // pre: slave is an iterator returning Association elements
    // post: creates a new iterator returning associated values
    {
	this.slave = slave;
    }

    /**
     * Resets the slave iterator (and thus the value iterator) to the
     * first association in the structure.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets iterator to point to first value
     * </dl>
     */
    public void reset()
    // post: resets iterator to point to first value
    {
	slave.reset();
    }

    /**
     * Returns true if an association is available for generating a value.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if current element is valid
     * </dl>
     * 
     * @return True if a valid value can be generated.
     */
    public boolean hasMoreElements()
    // post: returns true if current value is valid
    {
	return slave.hasMoreElements();
    }

    /**
     * Returns the current value, and increments the iterator.	
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current value and increments iterator
     * </dl>
     * 
     * @return The current value, before iterator is incremented.
     */
    public Object nextElement()
    // pre: hasMoreElements()
    // post: returns current value and increments iterator
    {
	Association pair = (Association)slave.nextElement();
	return pair.value();
    }

    /**
     * Returns the current value from the slave iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> current value is valid
     * <dt><b>Postcondition:</b><dd> returns current value
     * </dl>
     * 
     * @return The current value associated with the iterator.
     */
    public Object value()
    // pre: current value is valid
    // post: returns current value
    {
	Association pair = (Association)slave.value();
	return pair.value();
    }
}

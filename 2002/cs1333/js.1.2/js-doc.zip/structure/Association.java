// A class for binding key/value pairs.
// (c) 1998 McGraw-Hill
package structure;

/**
 * A class implementing a key-value pair.  This class associates an 
 * immutable key with a mutable value.  Used in many other structures.
 *
 * @version $Id: Association.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public class Association
{
    /**
     * The immutable key.  An arbitrary object.
     */
    protected Object theKey; // the key of the key-value pair
    /**
     * The mutable value.  An arbitrary object.
     */
    protected Object theValue; // the value of the key-value pair

    /**
     * Constructs a pair from a key and value.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Key is non-null
     * <dt><b>Postcondition:</b><dd> Constructs a key-value pair
     * </dl>
     * 
     * @param key A non-null object.
     * @param value A (possibly null) object.
     */
    public Association(Object key, Object value)
    // pre: key is non-null
    // post: constructs a key-value pair
    {
	Assert.pre(key != null, "Key must not be null.");
	theKey = key;
	theValue = value;
    }

    /**
     * Constructs a pair from a key; value is null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Key is non-null
     * <dt><b>Postcondition:</b><dd> Constructs a key-value pair.
     * </dl>
     * 
     * @param key A non-null key value.
     */
    public Association(Object key)
    // pre: key is non-null
    // post: constructs a key-value pair; value is null
    {
	this(key,null);
    }

    /**
     * Standard comparison function.  Comparison based on keys only.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> Other is non-null Association
     * <dt><b>Postcondition:</b><dd> Returns true iff the keys are equal
     * </dl>
     * 
     * @param other Another association.
     * @return True iff the keys are equal.
     */
    public boolean equals(Object other)
    // pre: other is non-null Association
    // post: returns true iff the keys are equal
    {
	Association otherAssoc = (Association)other;
	return key().equals(otherAssoc.key());
    }
    
    /**
     * Standard hashcode function.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Return hash code association with this association
     * </dl>
     * 
     * @return A hash code for association.
     * @see Hashtable
     */
    public int hashCode()
    // post: return hash code associated with this association
    {
	return key().hashCode();
    }
    
    /**
     * Fetch value from association.  May return null.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns value from association
     * </dl>
     * 
     * @return The value field of the association.
     */
    public Object value()
    // post: returns value from association
    {
	return theValue;
    }

    /**
     * Fetch key from association.  Should not return null.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns key from association
     * </dl>
     * 
     * @return Key of the key-value pair.
     */
    public Object key()
    // post: returns key from association
    {
	return theKey;
    }

    /**
     * Sets the value of the key-value pair.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Sets association's value to value.
     * </dl>
     * 
     * @param value The new value.
     */
    public void setValue(Object value)
    // post: sets association's value to value
    {
	theValue = value;
    }

    /**
     * Standard string representation of an association.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns string representation
     * </dl>
     * 
     * @return String representing key-value pair.
     */
    public String toString()
    // post: returns string representation
    {
	StringBuffer s = new StringBuffer();
	s.append("<Association: "+key()+"="+value()+">");
	return s.toString();
    }
}

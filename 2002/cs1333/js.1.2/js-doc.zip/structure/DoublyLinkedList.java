// Implementation of lists, using doubly linked elements.
// (c) 1998 McGraw-Hill
package structure;

/**
 * An implementation of lists that makes use of doubly linked elements.
 * This provided efficient implementation of both head and tail operations.
 * 
 * @version $Id: DoublyLinkedList.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public class DoublyLinkedList implements List
{
    /**
     * Number of elements within the list.
     */
    protected int count;
    /**
     * Reference to head of the list.
     */
    protected DoublyLinkedListElement head;
    /**
     * Reference to tail of the list.
     */
    protected DoublyLinkedListElement tail;

    /**
     * Constructs an empty list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an empty list
     * </dl>
     * 
     */
    public DoublyLinkedList()
    // post: constructs an empty list
    {
	head = null;
	tail = null;
	count = 0;
    }

    /**
     * Add a value to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds value to beginning of list.
     * </dl>
     * 
     * @param value The value to be added.
     * @see #addToHead
     */
    public void add(Object value)
    // post: adds value to beginning of list.
    {
	addToHead(value);
    }
    
    /**
     * Add a value to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is not null
     * <dt><b>Postcondition:</b><dd> adds element to head of list
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void addToHead(Object value)
    // pre: value is not null
    // post: adds element to head of list
    {
	// construct a new element, making it the head
	head = new DoublyLinkedListElement(value, head, null);
	// fix tail, if necessary
	if (tail == null) tail = head;
	count++;
    }

    /**
     * Remove a value from the head of the list.
     * Value is returned.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> removes first value from list
     * </dl>
     * 
     * @return The value removed from the list.
     */
    public Object removeFromHead()
    // pre: list is not empty
    // post: removes first value from list
    {
	Assert.pre(!isEmpty(),"List is not empty.");
	DoublyLinkedListElement temp = head;
	head = head.next();
	if (head != null) {
	    head.setPrevious(null);
	} else {
	    tail = null; // remove final value
	}
	temp.setNext(null);// helps clean things up; temp is free
	count--;
	return temp.value();
    }

    /**
     * Add a value to the tail of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is not null
     * <dt><b>Postcondition:</b><dd> adds new value to tail of list
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void addToTail(Object value)
    // pre: value is not null
    // post: adds new value to tail of list
    {
	// construct new element
	tail = new DoublyLinkedListElement(value, null, tail);
	// fix up head
	if (head == null) head = tail;
	count++;
    }

    /**
     * Remove a value from the tail of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> removes value from tail of list
     * </dl>
     * 
     * @return The value removed from the list.
     */
    public Object removeFromTail()
    // pre: list is not empty
    // post: removes value from tail of list
    {
	Assert.pre(!isEmpty(),"List is not empty.");
	DoublyLinkedListElement temp = tail;
	tail = tail.previous();
	if (tail == null) {
	    head = null;
	} else {
	    tail.setNext(null);
	}
	count--;
	return temp.value();
    }

    /**
     * Add a value to the tail of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is not null
     * <dt><b>Postcondition:</b><dd> adds new value to tail of list
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void addToTail(Object value)
    // pre: value is not null
    // post: adds new value to tail of list
    {
	// construct new element
	tail = new DoublyLinkedListElement(value, null, tail);
	count++;
    }

    /**
     * Remove a value from the tail of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> removes value from tail of list
     * </dl>
     * 
     * @return The value actually removed.
     */
    public Object removeFromTail()
    // pre: list is not empty
    // post: removes value from tail of list
    {
	Assert.pre(!isEmpty(),"List is not empty.");
	DoublyLinkedListElement temp = tail;
	tail = tail.previous();
	tail.setNext(null);
	count--;
	return temp.value();
    }

    /**
     * Get a copy of the first value found in the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> returns first value in list.
     * </dl>
     * 
     * @return A reference to first value in list.
     */
    public Object peek()
    // pre: list is not empty
    // post: returns first value in list.
    {
	return head.value();
    }

    /**
     * Get a copy of the last value found in the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> returns last value in list.
     * </dl>
     * 
     * @return A reference to the last value in the list.
     */
    public Object tailPeek()
    // pre: list is not empty
    // post: returns last value in list.
    {
	return tail.value();
    }

    /**
     * Check to see if a value is within the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value not null
     * <dt><b>Postcondition:</b><dd> returns true iff value is in the list
     * </dl>
     * 
     * @param value A value to be found in the list.
     * @return True if value is in list.
     */
    public boolean contains(Object value)
    // pre: value not null
    // post: returns true iff value is in the list
    {
	DoublyLinkedListElement finger = head;
	while ((finger != null) && (!finger.value().equals(value)))
	{
	    finger = finger.next();
	}
	return finger != null;
    }

    /**
     * Remove a value from the list.  At most one value is removed.
     * Any duplicates remain.  Because comparison is done with "equals,"
     * the actual value removed is returned for inspection.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is not null.  List can be empty.
     * <dt><b>Postcondition:</b><dd> first element matching value is removed from list
     * </dl>
     * 
     * @param value The value to be removed.
     * @return The value actually removed.
     */
    public Object remove(Object value)
    // pre: value is not null.  List can be empty.
    // post: first element matching value is removed from list
    {
	DoublyLinkedListElement finger = head;
	while (finger != null &&
	       !finger.value().equals(value))
	{
	    finger = finger.next();
	}
	if (finger != null)
	{
	    // fix next field of element above
	    if (finger.previous() != null)
	    {
		finger.previous().setNext(finger.next());
	    } else {
		head = finger.next();
	    }
	    // fix previous field of element below
	    if (finger.next() != null)
	    {
		finger.next().setPrevious(finger.previous());
	    } else {
		tail = finger.previous();
	    }
	    count--;		// fewer elements
	    return finger.value();
	}
	return null;
    }

    /**
     * Determine the number of elements in the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of elements in list
     * </dl>
     * 
     * @return The number of elements found in the list.
     */
    public int size()
    // post: returns the number of elements in list
    {
	return count;
    }

    /**
     * Determine if the list is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the list has no elements.
     * </dl>
     * 
     * @return True iff list has no values.
     */
    public boolean isEmpty()
    // post: returns true iff the list has no elements.
    {
	return size() == 0;
    }

    /**
     * Remove all values from list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all the elements from the list
     * </dl>
     */
    public void clear()
    // post: removes all the elements from the list
    {
        head = tail = null;
	count = 0;
    }

    /**
     * Construct an iterator to traverse the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator that allows the traversal of list.
     * </dl>
     * 
     * @return An iterator that traverses the list from head to tail.
     */
    public Iterator elements()
    // post: returns iterator that allows the traversal of list.
    {
	return new DoublyLinkedListIterator(head);
    }

    /**
     * Construct a string representation of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representing list
     * </dl>
     * 
     * @return A string representing the elements of the list.
     */
    public String toString()
    // post: returns a string representing list
    {
	StringBuffer s = new StringBuffer();
	s.append("<DoublyLinkedList:");
	Iterator li = elements();
	while (li.hasMoreElements())
	{
	    s.append(" "+li.nextElement());
	}
	s.append(">");
	return s.toString();
    }
}


/**
 * A private iterator for traversing a doubly linked list.
 * <p>
 * @version $Id: DoublyLinkedList.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class DoublyLinkedListIterator implements Iterator
{
    /**
     * Reference to head of the list.
     */
    protected DoublyLinkedListElement head;
    /**
     * Reference to the current node in the list.
     */
    protected DoublyLinkedListElement current;

    /**
     * Construct an iterator over a doubly linked list hanging from head.
     *
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an iterator rooted at list head, h
     * </dl>
     * 
     * @param h The head of the list to be traversed.
     */
    public DoublyLinkedListIterator(DoublyLinkedListElement h)
    // post: constructs an iterator rooted at list head, h
    {
	head = h;
	reset();
    }

    /**
     * Reset the iterator to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets iterator to list head
     * </dl>
     */
    public void reset()
    // post: resets iterator to list head
    {
	current = head;
    }

    /**
     * Determine if there are more elements to be considered.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff current element is valid
     * </dl>
     * 
     * @return True iff there are more elements to be considered.
     */
    public boolean hasMoreElements()
    // post: returns true iff current element is valid
    {
	return current != null;
    }

    /**
     * Returns reference to the current element, then increments iterator.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns current element and increments iterator
     * </dl>
     * 
     * @return Reference to element that was current before increment.
     */
    public Object nextElement()
    // post: returns current element and increments iterator
    {
	Object result = current.value();
	current = current.next();
	return result;
    }

    /**
     * Get reference to value that is current.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements
     * <dt><b>Postcondition:</b><dd> returns current element
     * </dl>
     * 
     * @return A reference to the value that is current.
     */
    public Object value()
    // pre: hasMoreElements
    // post: returns current element
    {
	return current.value();
    }
}

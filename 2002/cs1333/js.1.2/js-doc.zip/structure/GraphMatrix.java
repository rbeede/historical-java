// Graph, implemented with an adjacency matrix
// (c) 1998 McGraw-Hill

package structure;

/**
 * Implementation of graph using adjacency matrices.
 * User must commit to maximum size of graph (in vertices); it may be smaller.
 * Edges are stored in matrix.  Not suitable for large graphs.
 * Class is abstract: you must use GraphMatrixDirected or 
 * GraphMatrixUndirected to construct particular instances of graphs.
 * <p>
 * Typical usage:
 * <pre>
 *     Graph g = new GraphMatrixUndirected();
 *     g.add("harry");
 *     g.add("sally");
 *     g.addEdge("harry","sally","unfriendly");
 *     ...
 * </pre>
 * <p>
 * @version $Id: GraphMatrix.java,v 3.2 1998/02/24 17:10:29 bailey Exp bailey $
 * @author duane a. bailey and kimberly tabtiang
 * @see GraphMatrixDirected
 * @see GraphMatrixUndirected
 * @see GraphList
 */
abstract public class GraphMatrix implements Graph
{
    /**
     * Number of vertices in graph.
     */
    protected int size;          // allocation size for graph
    /**
     * The edge data.  Every edge appears on one (directed)
     * or two (undirected) locations within graph.
     */
    protected Edge data[][];     // matrix - array of arrays
    /**
     * Translation between vertex labels and vertex structures.
     */
    protected Dictionary dict;   // translates labels->vertices
    /**
     * List of free vertex indices within graph.
     */
    protected List freeList;    // available indices in matrix
    /**
     * Whether or not graph is directed.
     */
    protected boolean directed;  // graph is directed

    /**
     * Constructor of directed/undirected GraphMatrix. Protected constructor.
     * <p>
     * @param size Maximum size of graph.
     * @param dir True if graph is to be directed.
     */
    protected GraphMatrix(int size, boolean dir)
    // pre: size > 0
    // post: constructs an empty graph that may be expanded to
    //       at most size vertices.  Graph is directed if dir true
    //       and undirected otherwise
    {
	this.size = size; // set maximum size
	directed = dir;   // fix direction of edges
	// the following constructs a size x size matrix
	data = new Edge[size][size];
	// label to index translation table
	dict = new Hashtable(size);
	// put all indices in the free list
	freeList = new SinglyLinkedList();
	for (int row = size-1; row >= 0; row--)
	    freeList.add(new Integer(row));
    }

    /**
     * Add a vertex to the graph.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label is a non-null label for vertex
     * <dt><b>Postcondition:</b><dd> a vertex with label is added to graph.
     *       if vertex with label is already in graph, no action.
     * </dl>
     * 
     * @param label Label of the vertex; should be non-null.
     */
    public void add(Object label)
    // pre: label is a non-null label for vertex
    // post: a vertex with label is added to graph;
    //       if vertex with label is already in graph, no action
    {
	// if there already, do nothing
	if (dict.containsKey(label)) return;

	Assert.pre(!freeList.isEmpty(), "Matrix not full");
	// allocate a free row and column
	int row = ((Integer) freeList.removeFromHead()).intValue();
	// add vertex to dictionary
	dict.put(label, new GraphMatrixVertex(label, row));
    }

    /**
     * Add an edge between two vertices within the graph.  Edge is directed
     * iff graph is directed.  Duplicate edges are silently replaced.
     * Labels on edges may be null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vtx1 and vtx2 are labels of existing vertices
     * <dt><b>Postcondition:</b><dd> an edge (possibly directed) is inserted between
     *       vtx1 and vtx2.
     * </dl>
     * 
     * @param vtx1 First (or source, if directed) vertex.
     * @param vtx2 Second (or destination, if directed) vertex.
     * @param label Label associated with the edge.
     */
    abstract public void addEdge(Object v1, Object v2, Object label);
    // pre: v1 and v2 are labels of existing vertices, v1 & v2
    // post: an edge (possibly directed) is inserted between v1 and v2;
    //       if edge is new, it is labeled with label (can be null)

    /**
     * Remove a vertex from the graph.  Associated edges are also 
     * removed.  Non-vertices are silently ignored.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label is non-null vertex label
     * <dt><b>Postcondition:</b><dd> vertex with "equals" label is removed, if found
     * </dl>
     * 
     * @param label The label of the vertex within the graph.
     * @return The label associated with the vertex.
     */
    public Object remove(Object label)
    // pre: label is non-null vertex label
    // post: vertex with "equals" label is removed, if found
    {      
	// find and extract vertex
	GraphMatrixVertex vert;
	vert = (GraphMatrixVertex)dict.remove(label);
	if (vert == null) return null;
	// remove vertex from matrix
	int index = vert.index();
	// clear row and column entries
	for (int row=0; row<size; row++) {
	    data[row][index] = null;
	    data[index][row] = null;
	}
	// add node index to free list
	freeList.add(new Integer(index));
	return vert.label();
    }

    /**
     * Remove possible edge between vertices labeled vLabel1 and vLabel2.
     * Directed edges consider vLabel1 to be the source.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vLabel1 and vLabel2 are labels of existing vertices
     * <dt><b>Postcondition:</b><dd> edge is removed, its label is returned
     * </dl>
     * 
     * @param vLabel1 First (or source, if directed) vertex.
     * @param vLabel2 Second (or destination, if directed) vertex.
     * @return The label associated with the edge removed.
     */
    abstract public Object removeEdge(Object vLabel1, Object vLabel2);
    // pre: vLabel1 and vLabel2 are labels of existing vertices
    // post: edge is removed, its label is returned

    /**
     * Get reference to actual label of vertex.  Vertex labels are matched
     * using their equals method, which may or may not test for actual
     * equivalence.  Result remains part of graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns actual label of indicated vertex
     * </dl>
     * 
     * @param label The label of the vertex sought.
     * @return The actual label, or null if none is found.
     */
    public Object get(Object label)
    // post: returns actual label of vertex with label "equals" 'label'
    {
	GraphMatrixVertex vert;
	vert = (GraphMatrixVertex) dict.get(label);
	return vert.label();
    }

    /**
     * Get reference to actual edge.  Edge is identified by
     * the labels on associated vertices.  If edge is directed, the
     * label1 indicates source.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns actual edge between vertices.
     * </dl>
     * 
     * @param label1 The first (or source, if directed) vertex.
     * @param label2 The second (or destination, if directed) vertex.
     * @return The edge, if found, or null.
     */
    public Edge getEdge(Object label1, Object label2)
    // post: returns actual edge between vertices.
    {
	int row,col;
	row = ((GraphMatrixVertex) dict.get(label1)).index();
	col = ((GraphMatrixVertex) dict.get(label2)).index();
	return data[row][col];
    }

    /**
     * Test for vertex membership.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff vertex with "equals" label exists.
     * </dl>
     * 
     * @param label The label of the vertex sought.
     * @return True iff vertex with matching label is found.
     */
    public boolean contains(Object label)
    // post: returns true iff vertex with "equals" label exits.
    {
	return dict.containsKey(label);
    }

    /**
     * Test for edge membership.  If edges are directed, vLabel1
     * indicates source.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff edge with "equals" label exists
     * </dl>
     * 
     * @param vLabel1 First (or source, if directed) vertex.
     * @param vLabel2 Second (or destination, if directed) vertex.
     * @return True iff the edge exists within the graph.
     */
    public boolean containsEdge(Object vLabel1, Object vLabel2)
    // post: returns true iff edge with "equals" label exists
    {
	GraphMatrixVertex vtx1, vtx2;
	vtx1 = (GraphMatrixVertex) dict.get(vLabel1);
	vtx2 = (GraphMatrixVertex) dict.get(vLabel2);
	Assert.condition(vtx1 != null, "Vertex exists");
	Assert.condition(vtx2 != null, "Vertex exists");
	return data[vtx1.index()][vtx2.index()] != null;
    }

    /**
     * Test and set visited flag of vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> sets visited flag on vertex, returns previous value
     * </dl>
     * 
     * @param label Label of vertex to be visited.
     * @return Previous value of visited flag on vertex.
     */
    public boolean visit(Object label)
    // post: sets visited flag on vertex; returns previous value
    { 
	Vertex vert = (Vertex) dict.get(label);
	return vert.visit();
    }

    /**
     * Test and set visited flag of edge.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> sets visited flag on edge; returns previous value
     * </dl>
     * 
     * @param e Edge object that is part of graph.
     * @return Previous value of the Edge's visited flag.
     */
    public boolean visitEdge(Edge e)
    // pre: sets visited flag on edge; returns previous value
    {
	return e.visit();
    }

    /**
     * Return visited flag of vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns visited flag on labeled vertex
     * </dl>
     * 
     * @param label Label of vertex.
     * @return True if vertex has been visited.
     */
    public boolean isVisited(Object label)
    // post: returns visited flag on labeled vertex
    {
	GraphMatrixVertex vert;
	vert = (GraphMatrixVertex) dict.get(label);
	return vert.isVisited();
    }

    /**
     * Return visited flag of edge.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns visited flag on edge between vertices
     * </dl>
     * 
     * @param e Edge of graph to be considered.
     * @return True if the edge has been visited.
     */
    public boolean isVisitedEdge(Edge e)
    // post: returns visited flag on edge
    {
	return e.isVisited();
    }

    /**
     * Clear visited flags of edges and vertices.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets visited flags to false
     * </dl>
     */
    public void reset()
    // post: resets visited flags to false
    {
	Iterator it = dict.elements();
	for (it.reset(); it.hasMoreElements(); it.nextElement()) 
	{
	    ((GraphMatrixVertex)it.value()).reset();
	}
	for (int row=0; row<size; row++)
	    for (int col=0; col<size; col++) {
		Edge e = data[row][col];
		if (e != null) e.reset();
	    }
    }

    /**
     * Determine number of vertices within graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of vertices in graph
     * </dl>
     * 
     * @return The number of vertices within graph.
     */
    public int size()
    // post: returns the actual number of vertices in graph
    {
	return dict.size();
    }

    /**
     * Determine out degree of vertex.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label labels an existing vertex
     * <dt><b>Postcondition:</b><dd> returns the number of vertices adjacent to vertex
     * </dl>
     *
     * @param label Label associated with vertex.
     * @return The number of edges with this vertex as source.
     */
    public int degree(Object label)
    // pre: label labels an existing vertex
    // post: returns number of vertices adjacent to label
    {
	// get index
	int row = ((GraphMatrixVertex)dict.get(label)).index();
	int col;
	int result = 0;
	// count non-null columns in row
	for (col = 0; col < size; col++)
	{
	    if (data[row][col] != null) result++;
	}
	return result;
    }

    /**
     * Determine the number of edges in graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of edges in graph
     * </dl>
     * 
     * @return Number of edges in graph.
     */
    abstract public int edgeCount();
    // post: returns the number of edges in graph

    /**
     * Construct vertex iterator.  Vertices are not visited in 
     * any guaranteed order.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator across all vertices of graph
     * </dl>
     * 
     * @return Iterator traversing vertices in graph.
     */
    public Iterator elements()
    // post: returns iterator across all vertices of graph
    {
	return dict.keys();
    }

    /**
     * Construct an adjacent vertex iterator.   Adjacent vertices
     * (those on destination of edge, if directed) are considered,
     * but not in any guaranteed order.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label is label of vertex in graph
     * <dt><b>Postcondition:</b><dd> returns iterator over vertices adj. to vertex
     *       each edge beginning at label visited exactly once
     * </dl>
     * 
     * @param label Label of the vertex.
     * @return Iterator traversing the adjacent vertices of labeled vertex.
     */
    public Iterator neighbors(Object label)
    // pre: label is label of vertex in graph
    // post: returns iterator vertices adj. to labeled vertex
    {
	GraphMatrixVertex vert;
	vert = (GraphMatrixVertex) dict.get(label);
	List list = new SinglyLinkedList();
	for (int row=size-1; row>=0; row--)
	{
	    Edge e = data[vert.index()][row];
	    if (e != null) {
		if (e.here().equals(vert.label()))
		     list.add(e.there());
		else list.add(e.here());
	    }
	}
	return list.elements();
    }
	  
    /**
     * Construct an iterator over all edges.  Every directed/undirected
     * edge is considered exactly once.  Order is not guaranteed.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator across edges of graph
     *       iterator returns edges; each edge visited once
     * </dl>
     * 
     * @return Iterator over edges.
     */
    abstract public Iterator edges();
    // post: returns iterator across all edges of graph (returns Edges)

    /**
     * Remove all vertices (and thus, edges) of the graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all vertices from graph
     * </dl>
     */
    public void clear()
    // post: removes vertices and edges from graph
    {
	dict.clear();
	for (int row=0; row<size; row++)
	    for (int col=0; col<size; col++)
		data[row][col] = null;
	freeList = new SinglyLinkedList();
	for (int row=size-1; row>=0; row--)
	    freeList.add(new Integer(row));
    }

    /**
     * Determine if graph is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if graph contains no vertices
     * </dl>
     * 
     * @return True iff there are no vertices in graph.
     */
    public boolean isEmpty()
    // post: returns true iff graph is empty
    {
      return dict.isEmpty();
    }

    /**
     * Determine if graph is directed.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if edges of graph are directed
     * </dl>
     * 
     * @return True iff the graph is directed.
     */
    public boolean isDirected()
    // post: returns true iff graph is directed
    {
	return directed;
    }
}

/**
 * 
 * @version $Id: GraphMatrix.java,v 3.2 1998/02/24 17:10:29 bailey Exp bailey $
 * @author duane a. bailey
 */
class GraphMatrixVertex extends Vertex 
{
    protected int index;

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new augmented vertex
     * </dl>
     * 
     * @param label 
     * @param idx 
     */
    public GraphMatrixVertex(Object label, int idx)
    // post: constructs a new augmented vertex
    {
	super(label);
	index = idx;
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns index associated with vertex
     * </dl>
     * 
     * @return 
     */
    public int index()
    // post: returns index associated with vertex
    {
	return index;
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of vertex
     * </dl>
     * 
     * @return 
     */
    public String toString()
    // post: returns string representation of vertex
    {
	return "<GraphMatrixVertex: "+label()+">";
    }
}

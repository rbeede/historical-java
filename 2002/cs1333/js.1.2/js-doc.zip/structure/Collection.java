// An interface for the basic store operations.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An interface for structures that allow you to add, remove, and 
 * check for containment.  Many structures in the structure package
 * are efficiently implemented if you can limit your usage to this
 * interface.
 * 
 * @version $Id: Collection.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public interface Collection extends Store
{
    /**
     * Determine if the structure contains a value.
     <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> returns true iff the collection contains the value
     * </dl>
     * 
     * @param value The value sought.
     * @return True if the structure contains the value.
     */
    public boolean contains(Object value);
    // pre: value is non-null
    // post: returns true iff the collection contains the value
    
    /**
     * Add a value to the structure.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> the value is added to the collection
     *       the replacement policy is not specified.
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void add(Object value);
    // pre: value is non-null
    // post: the value is added to the collection
    //       the replacement policy is not specified.

    /**
     * Remove a value from the store.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> removes an object "equal" to value within collection.
     * </dl>
     * 
     * @param value The value to be removed.
     * @return The value actually removed.
     */
    public Object remove(Object value);
    // pre: value is non-null
    // post: removes an object "equal" to value within collection.

    /**
     * Construct an iterator over the elements of the structure.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator for traversing collection
     * </dl>
     * 
     * @return An iterator over the structure.
     */
    public Iterator elements();
    // post: returns an iterator for traversing collection
}

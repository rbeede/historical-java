// A set implemented using an ordered structure.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of sets of comparable objects.  The underlying
 * structure makes use of the comparability of the values to efficiently
 * implement many of the operations.
 * <p>
 * When writing objects to be stored in comparable sets, make sure that
 * the coding of comapreTo, equals, and the hashcode functions are 
 * consistent.
 *
 * @version $Id: ComparableSet.java,v 3.1 1998/01/19 14:51:27 bailey Exp $
 * @author duane a. bailey
 * @see structure.SetList
 */
public class ComparableSet implements Set
{
    /**
     * The ordered structure that maintains the set.
     * In this case, we use splay trees, but better performing
     * implementations could be substituted.
     */
    protected OrderedStructure t;

    /**
     * Construct a set with no elements.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new, empty set
     * </dl>
     * 
     */
    public ComparableSet()
    // post: constructs a new, empty set
    {
	t = new SplayTree();
    }

    /**
     * Remove all the elements of the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> elements of set are removed
     * </dl>
     * 
     */
    public void clear()
    // post: elements of set are removed
    {
	t = new SplayTree();
    }

    /**
     * Identify if the set is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff set is empty
     * </dl>
     * 
     * @return True iff there are no elements in the set.
     */
    public boolean isEmpty()
    // post: returns true iff set is empty
    {
	return t.isEmpty();
    }

    /**
     * Add an element to the set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> e is non-null object
     * <dt><b>Postcondition:</b><dd> adds element e to set
     * </dl>
     * 
     * @param e is a non-null object.
     */
    public void add(Object e)
    // pre: e is non-null object
    // post: adds element e to set
    {
	t.add(e);
    }

    /**
     * Remove an element from a set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> e is non-null object
     * <dt><b>Postcondition:</b><dd> e is removed from set, value returned
     * </dl>
     * 
     * @param e The value to be removed.
     * @return The actual value removed.
     */
    public Object remove(Object e)
    // pre: e is non-null object
    // post: e is removed from set, value returned
    {
	return t.remove(e);
    }

    /**
     * Determine if a set contains a value.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> e is non-null
     * <dt><b>Postcondition:</b><dd> returns true iff e is in set
     * </dl>
     * 
     * @param e The value sought.
     * @return True iff the sought value is within the set.
     */
    public boolean contains(Object e)
    // pre: e is non-null
    // post: returns true iff e is in set
    {
        return t.contains(e);
    }

    /**
     * Determine if this set is a subset of another.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns true iff this set is subset of other
     * </dl>
     * 
     * @param other Another comparable set.
     * @return True iff every element of this set is in the other.
     */
    public boolean subset(Set other)
    // pre: other is non-null reference to set
    // post: returns true iff this set is subset of other
    {
	Iterator myElements = t.elements();
	for (myElements.reset();
	     myElements.hasMoreElements();
   	     myElements.nextElement())
	{
	    if (!other.contains(myElements.value())) return false;
	}
	return true;
    }

    /**
     * Return a duplicate of the set.
     * This is a shallow clone; elements are not cloned, themselves.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a copy of set
     * </dl>
     * 
     * @return A copy of this set.
     */
    public Object clone()
    // post: returns a copy of set
    {
	Set result = new ComparableSet();
	Iterator myElements = elements();
	for (myElements.reset(); myElements.hasMoreElements(); myElements.nextElement()) {
	    result.add(myElements.value());
	}
	return result;
    }

    /**
     * Compute the union of this set and another.
     * A value is in the result if it is in either of this or other.
     * This set is not modified by the action.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns union of this set and other.
     * </dl>
     * 
     * @param other The set to be unioned with this.
     * @return The union of the two sets.
     */
    public Object union(Set other)
    // pre: other is non-null reference to set
    // post: returns union of this set and other.
    {
	Set result = new ComparableSet();
	Iterator yourElements = other.elements();
	Iterator myElements = elements();
	Comparable myVal;
	Comparable yourVal;
	for (yourElements.reset(),myElements.reset();
	     yourElements.hasMoreElements() && myElements.hasMoreElements();
   	     )
	{
	    yourVal = (Comparable)yourElements.value();
    	    myVal = (Comparable)myElements.value();
	    if (yourVal.compareTo(myVal) < 0)
	    {
		result.add(yourVal);
		yourElements.nextElement();
	    } else
	    {
		result.add(myVal);
		if (myVal.equals(yourVal)) yourElements.nextElement();
		myElements.nextElement();
	    }
	}
	while (yourElements.hasMoreElements())
	{
	    result.add(yourElements.nextElement());
	}
	while (myElements.hasMoreElements())
	{
	    result.add(myElements.nextElement());
	}
	return result;
    }

    /**
     * Compute the intersection of this set and other.
     * Any value in result is a member of both this and other.
     * This set is not modified by the operation.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns set intersection between this and other
     * </dl>
     * 
     * @param other The set to be intersected with this.
     * @return The result of the intersection of this with other.
     */
    public Object intersection(Set other)
    // pre: other is non-null reference to set
    // post: returns set intersection between this and other
    {
	Set result = new ComparableSet();
	Iterator yourElements = other.elements();
	Iterator myElements = elements();
	Comparable myVal;
	Comparable yourVal;
	for (yourElements.reset(),myElements.reset();
	     yourElements.hasMoreElements() && myElements.hasMoreElements();
   	     )
	{
	    yourVal = (Comparable)yourElements.value();
    	    myVal = (Comparable)myElements.value();
	    if (yourVal.compareTo(myVal) < 0)
	    {
		yourElements.nextElement();
	    } else if (myVal.compareTo(yourVal) < 0)
	    {
		myElements.nextElement();
	    } else
	    {
		result.add((Comparable)myVal);
		yourElements.nextElement();
		myElements.nextElement();
	    }
	}
	return result;
    }

    /**
     * Compute the difference between this set and other.
     * Any value in result is in this set, but not other.
     * Computation does not modify this set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns the elements in this but not other.
     * </dl>
     * 
     * @param other The values not to be included in result.
     * @return The set of elements in this, but not other.
     */
    public Object difference(Set other)
    // pre: other is non-null reference to set
    // post: returns the elements in this but not other.
    {
	Set result = new ComparableSet();
	Iterator yourElements = other.elements();
	Iterator myElements = elements();
	Comparable myVal;
	Comparable yourVal;
	for (yourElements.reset(),myElements.reset();
	     yourElements.hasMoreElements() && myElements.hasMoreElements();
   	     )
	{
	    yourVal = (Comparable)yourElements.value();
    	    myVal = (Comparable)myElements.value();
	    if (myVal.compareTo(yourVal) < 0)
	    {
		result.add(myVal);
		myElements.nextElement();
	    } else if (yourVal.compareTo(myVal) < 0)
	    {
		yourElements.nextElement();
	    } else
	    {
		yourElements.nextElement();
		myElements.nextElement();
	    }
	}
	while (myElements.hasMoreElements())
	{
	    result.add(myElements.nextElement());
	}
	return result;
    }

    /**
     * Construct an iterator to traverse the elements of the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator to traverse the elements of set
     * </dl>
     * 
     * @return An iterator to traverse the elements of the set.
     */
    public Iterator elements()
    // post: returns iterator to traverse the elements of set
    {
	return t.elements();
    }

    /**
     * Returns the number of elements within the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements in set
     * </dl>
     * 
     * @return The number of elements within the set.
     */
    public int size()
    // post: returns number of elements in set
    {
	return t.size();
    }

    /**
     * Generate a string representation of the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of this set
     * </dl>
     * 
     * @return A string representing the set.
     */
    public String toString()
    // post: returns string representation of this set
    {
	StringBuffer s = new StringBuffer();
	s.append("<ComparableSet:");
	Iterator si = elements();
	while (si.hasMoreElements())
	{
	    s.append(" "+si.value());
	}
	s.append(">");
	return s.toString();
    }

}

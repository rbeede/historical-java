// Graph, implemented with an adjacency list
// (c) 1998 McGraw-Hill

package structure;

/**
 * A class implementing a directed, adjacency-list based graph.
 * <p>
 * @version $Id: GraphListDirected.java,v 3.1 1998/01/29 13:02:00 bailey Exp $
 * @author duane a. bailey and kimberly tabtiang
 * @see GraphList
 * @see GraphListUndirected
 * @see GraphMatrixDirected
 */
public class GraphListDirected extends GraphList
{

    /**
     * Construct a directed, adjacency-list based graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an directed graph
     * </dl>
     */
    public GraphListDirected()
    // post: constructs an directed graph
    {
	super(true);
    }

    /**
     * Add an edge between two vertices within the graph.  Edge is directed.
     * Duplicate edges are silently replaced.
     * Labels on edges may be null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vLabel1 and vLabel2 are labels of existing vertices, v1 & v2
     * <dt><b>Postcondition:</b><dd> an edge is inserted between v1 and v2.
     *       if edge is new, it is labeled with label (can be null)
     * </dl>
     * 
     * @param vLabel1 Source vertex.
     * @param vLabel2 Destination vertex.
     * @param label Label associated with the edge.
     */
    public void addEdge(Object vLabel1, Object vLabel2, Object label)
    // pre: vLabel1 and vLabel2 are labels of existing vertices, v1 & v2
    // post: an edge is inserted between vLabel1 and vLabel2.
    //       if edge is new, it is labeled with label (can be null)
    {
	GraphListVertex v1 = (GraphListVertex) dict.get(vLabel1);
	GraphListVertex v2 = (GraphListVertex) dict.get(vLabel2);
	Edge e = new Edge(v1.label(), v2.label(), label, true);
	v1.addEdge(e);
    }

    /**
     * Remove a vertex from the graph.  Associated edges are also 
     * removed.  Non-vertices are silently ignored.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label is non-null vertex label
     * <dt><b>Postcondition:</b><dd> vertex with "equals" label is removed, if found
     * </dl>
     * 
     * @param label The label of the vertex within the graph.
     * @return The label associated with the vertex.
     */
    public Object remove(Object label)
    // pre: label is non-null vertex label
    // post: vertex with "equals" label is removed, if found
    {
	GraphListVertex v = (GraphListVertex)dict.get(label);

	Iterator vi = elements();
	while (vi.hasMoreElements())
	{
	    Object v2 = vi.nextElement();
	    if (!label.equals(v2)) removeEdge(v2,label);
	}
	dict.remove(label);
	return v.label();
    }

    /**
     * Remove possible edge between vertices labeled vLabel1 and vLabel2.
     * vLabel1 is the source.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vLabel1 and vLabel2 are labels of existing vertices
     * <dt><b>Postcondition:</b><dd> edge is removed, its label is returned
     * </dl>
     * 
     * @param vLabel1 Source vertex.
     * @param vLabel2 Destination vertex.
     * @return The label associated with the edge removed.
     */
    public Object removeEdge(Object vLabel1, Object vLabel2)  
    // pre: vLabel1 and vLabel2 are labels of existing vertices
    // post: edge is removed, its label is returned
    {
	GraphListVertex v1 = (GraphListVertex) dict.get(vLabel1);
	GraphListVertex v2 = (GraphListVertex) dict.get(vLabel2);
	Edge e = new Edge(v1.label(), v2.label(), null, true);
	e = v1.removeEdge(e);
	if (e == null) return null;
	else return e.label();
    }

    /**
     * Determine the number of edges in graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of edges in graph
     * </dl>
     * 
     * @return Number of edges in graph.
     */
    public int edgeCount()
    // post: returns the number of edges in graph
    {
	int count = 0;
	Iterator i = dict.elements();
	for (i.reset(); i.hasMoreElements(); i.nextElement()) 
	    count += ((GraphListVertex) i.value()).degree();
	return count;
    }

    /**
     * Construct a string representation of graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of graph
     * </dl>
     * 
     * @return String representing graph.
     */
    public String toString()
    // post: returns string representation of graph
    {

	return "<GraphListDirected: "+dict.toString()+">";
    }
}

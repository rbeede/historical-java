// An implementation of and ordered structure, based on vectors.
// (c) 1998 McGraw-Hill

package structure;

/**
 * Implementation of an ordered structure implemented using a vector
 *
 * @see structure.Vector
 * @version $Id: OrderedVector.java,v 3.1 1998/01/19 14:51:27 bailey Exp bailey $
 * @author duane a. bailey
 */
public class OrderedVector implements OrderedStructure
{
    /**
     * The vector of values.  Values are stored in increasing order
     */
    protected Vector data;
    /**
     * Construct an empty ordered vector
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an empty, ordered vector
     * </dl>
     */
    public OrderedVector()
    // post: constructs an empty, ordered vector
    {
	data = new Vector();
    }

    /**
     * Add a comparable value to an ordered vector
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> inserts value, leaves vector in order
     * </dl>
     * 
     * @param value The comparable value to be added to the ordered vector
     */
    public void add(Object value)
    // pre: value is non-null
    // post: inserts value, leaves vector in order
    {
	int position = indexOf((Comparable)value);
	data.insertElementAt(value,position);
    }

    /**
     * Determine if a comparable value is a member of the ordered vector
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> returns true if the value is in the vector
     * </dl>
     * 
     * @param value The comparable value sought
     * @return True if the value is found within the ordered vector
     */
    public boolean contains(Object value)
    // pre: value is non-null
    // post: returns true if the value is in the vector
    { 
	int position = indexOf((Comparable)value);
	return (position < size()) &&
	       data.elementAt(position).equals(value);
    }

    /**
     * Remove a comparable value from an ordered vector
     * At most one value is removed
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> removes one instance of value, if found in vector
     * </dl>
     * 
     * @param value The comparable value to be removed
     * @return The actual comparable removed
     */
    public Object remove(Object value)
    // pre: value is non-null
    // post: removes one instance of value, if found in vector
    {
	if (contains(value)) {
	    // we know value is pointed to by indexOf
	    int position = indexOf((Comparable)value);
	    // since vector contains value, position < size()
	    // keep track of the value for return
	    Object target = data.elementAt(position);
	    // remove the value from the underlying vector
	    data.removeElementAt(position);
	    return target;
	}
        return null;
    }

    /**
     * Determine if the ordered vector is empty.	
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if the OrderedVector is empty
     * </dl>
     * 
     * @return True iff the ordered vector is empty
     */
    public boolean isEmpty()
    // post: returns true if the OrderedVector is empty
    {
	return data.size() == 0;
    }

    /**
     * Removes all the values from a an ordered vector
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> vector is emptied
     * </dl>
     */
    public void clear()
    // post: vector is emptied
    {
	data.setSize(0);
    }

    /**
     * Determine the number of elements within the ordered vector
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of elements in vector
     * </dl>
     * 
     * @return The number of elements within the ordered vector
     */
    public int size()
    // post: returns the number of elements in vector
    {
	return data.size();
    }

    /**
     * Construct an iterator to traverse the ordered vector in ascending
     * order
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator for traversing vector
     * </dl>
     * 
     * @return An iterator to traverse the ordered vector
     */
    public Iterator elements()
    // post: returns an iterator for traversing vector
    {
	return data.elements();
    }

    protected int indexOf(Comparable target)
    // pre: target is a non-null comparable object
    // post: returns ideal position of value in vector
    {
	Comparable midValue;
	int low = 0;  // lowest possible location
	int high = data.size(); // highest possible location
	int mid = (low + high)/2; // low <= mid <= high
	// mid == high iff low == high
	while (low < high) {
	    // get median value
	    midValue = (Comparable)data.elementAt(mid);
	    // determine on which side median resides:
	    if (midValue.compareTo(target) < 0) {
		low = mid+1;
	    } else {
		high = mid;
	    }
	    // low <= high
	    // recompute median index
	    mid = (low+high)/2;
	}
	return low;
    }
    
    /**
     * Construct a string representation of an ordered vector
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> returns string representation of ordered vector
     * </dl>
     * 
     * @return The string representing the ordered vector
     */
    public String toString()
    // pre: returns string representation of ordered vector
    {
	return "<OrderedVector: "+data+">";
    }
}

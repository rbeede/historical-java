// A set implemented using lists.  Fairly slow, but works on non-Comparables.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of a set using lists.
 * <p>
 * @version $Id: SetList.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public class SetList implements Set
{
    /**
     * The underlying structure --- a list.
     */
    protected List l;

    /**
     * Construct a new set list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new, empty set
     * </dl>
     */
    public SetList()
    // post: constructs a new, empty set
    {
	l = new SinglyLinkedList();
    }

    /**
     * Remove all the elements from the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> elements of set are removed
     * </dl>
     */
    public void clear()
    // post: elements of set are removed
    {
	l = new SinglyLinkedList();
    }

    /**
     * Determine if the set is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff set is empty
     * </dl>
     * 
     * @return True iff there are no elements in set.
     */
    public boolean isEmpty()
    // post: returns true iff set is empty
    {
	return l.isEmpty();
    }

    /**
     * Add an element to set, if not already present.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> e is non-null object
     * <dt><b>Postcondition:</b><dd> adds element e to interface
     * </dl>
     * 
     * @param e The new value to be added to set.
     */
    public void add(Object e)
    // pre: e is non-null object
    // post: adds element e to interface
    {
	if (!l.contains(e)) l.add(e);
    }

    /**
     * Remove an element from the set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> e is non-null object
     * <dt><b>Postcondition:</b><dd> e is removed from set, value returned
     * </dl>
     * 
     * @param e The element of the set to be removed.
     * @return The value actually removed.
     */
    public Object remove(Object e)
    // pre: e is non-null object
    // post: e is removed from set, value returned
    {
	return l.remove(e);
    }

    /**
     * Returns true if value is an element of the set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> e is non-null
     * <dt><b>Postcondition:</b><dd> returns true iff e is in set
     * </dl>
     * 
     * @param e The element sought in set.
     * @return True iff the element is in the set.
     */
    public boolean contains(Object e)
    // pre: e is non-null
    // post: returns true iff e is in set
    {
        return l.contains(e);
    }

    /**
     * Determine if this set is a subset of other.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns true iff this set is subset of other
     * </dl>
     * 
     * @param other The potential superset.
     */
    public boolean subset(Set other)
    // pre: other is non-null reference to set
    // post: returns true iff this set is subset of other
    {
	Iterator myElements = l.elements();
	for (myElements.reset();
	     myElements.hasMoreElements();
   	     myElements.nextElement())
	{
	    if (!other.contains(myElements.value())) return false;
	}
	return true;
    }
    
    /**
     * Returns a shallow clone of this set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a copy of set
     * </dl>
     * 
     * @return A new set with same values.
     */
    public Object clone()
    // post: returns a copy of set
    {
	Set result = new SetList();
	Iterator myElements = elements();
	for (myElements.reset(); myElements.hasMoreElements(); myElements.nextElement()) {
	    result.add(myElements.value());
	}
	return result;
    }

    /**
     * Compute the union of this set with other.
     * This set not modified.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns new set containing union of this and other
     * </dl>
     * 
     * @param other The set to be unioned with this.
     * @return Union of this and other.
     */
    public Object union(Set other)
    // pre: other is non-null reference to set
    // post: returns union of this set and other.
    {
	Set result = (Set)clone();
	Iterator yourElements = other.elements();
	for (yourElements.reset();
	     yourElements.hasMoreElements();
   	     yourElements.nextElement())
	{
	    Object v = yourElements.value();
	    if (!result.contains(v))
	    {
		result.add(v);
	    }
	}
	return result;
    }

    /**
     * Compute the intersection of this set and other.
     * Members of result are in both this and other.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns new set containing intersection of this and other
     * </dl>
     * 
     * @param other The other set to be intersected with this.
     * @return Intersection of this and other.
     */
    public Object intersection(Set other)
    // pre: other is non-null reference to set
    // post: returns set intersection between this and other
    {
	Set result = new SetList();
	Iterator myElements = l.elements();
	for (myElements.reset();
	     myElements.hasMoreElements();
   	     myElements.nextElement())
	{
	    Object v = myElements.value();
	    if (other.contains(v))
	    {
		result.add(v);
	    }
	}
	return result;
    }
    
    /**
     * Compute the difference between two sets.
     * Values of the result are members of this, but not other.
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns new set containing difference of this and other
     * </dl>
     * 
     * @param other The set whose values are to be eliminated from this.
     * @return Difference between this and other.
     */
    public Object difference(Set other)
    // pre: other is non-null reference to set
    // post: returns the elements in this but not other.
    {
	Set result = new SetList();
	Iterator myElements = l.elements();
	for (myElements.reset();
	     myElements.hasMoreElements();
   	     myElements.nextElement())
	{
	    Object v = myElements.value();
	    if (!other.contains(v))
	    {
		result.add(v);
	    }
	}
	return result;
    }

    /**
     * Construct an iterator to traverse the elements of the set.
     * Elements will not appear in any particular order.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator to traverse the elements of set
     * </dl>
     * 
     * @return An iterator for inspecting members of the set.
     */
    public Iterator elements()
    // post: returns iterator to traverse the elements of set
    {
	return l.elements();
    }

    /**
     * Determine the number of elements in the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements in set
     * </dl>
     * 
     * @return The number of elements in the set.
     */
    public int size()
    // post: returns number of elements in set
    {
	return l.size();
    }

    /**
     * Construct a string representation of the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representation of set
     * </dl>
     * 
     * @return A string representing the set.
     */
    public String toString()
    // post: returns a string representation of set
    {
	return "<SetList: "+l+">";
    }
    
}

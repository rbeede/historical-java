// An implementation of stacks using lists.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of a stack, based on lists.  The head of the
 * stack is stored at the head of the list.
 * 
 * @version $Id: StackList.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public class StackList implements Stack
{
    /**
     * The list that maintains the stack data.
     */
    protected List data;

    /**
     * Construct an empty stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new stack, based on lists
     * </dl>
     */
    public StackList()
    // post: constructs a new stack, based on lists
    {
	// Think about why we use singly linked lists here:
	// They're simple, and take less space.
	data = new SinglyLinkedList();
    }
    
    /**
     * Remove all elements from the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from stack
     * </dl>
     */
    public void clear()
    // post: removes all elements from stack
    {
	data.clear();
    }

    /**
     * Determine if the stack is empty.
     * Provided for compatibility with java.util.Stack.empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the stack is empty
     * </dl>
     * 
     * @return True iff the stack is empty.
     * @see #isEmpty
     */
    public boolean empty()
    // post: returns true iff stack is empty
    {
	return data.isEmpty();
    }

    /**
     * Determine if the stack is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the stack is empty
     * </dl>
     * 
     * @return True iff the stack is empty.
     * @see #empty
     */
    public boolean isEmpty()
    // post: returns true iff stack is empty
    {
	return data.isEmpty();
    }

    /**
     * Get a reference to the top value in the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> returns the top element (most recently pushed) from stack
     * </dl>
     * 
     * @return A reference to the top element of the top of the stack.
     */
    public Object peek()
    // pre: !isEmpty()
    // post: returns first element of stack
    {
	return data.peek();
    }

    /**
     * Add a value to the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds an element to stack.
     *       Will be next element popped if no intervening push
     * </dl>
     * 
     * @param item The value to be added.
     * @see #push
     */
    public void add(Object value)
    // post: pushes value onto stack.
    //       will be first value popped off.
    {
	data.addToHead(value);
    }

    /**
     * Value is added to the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds an element to stack.
     *       will be next element popped if no intervening push
     * </dl>
     * 
     * @param item The value to be added.
     */
    public void push(Object value)
    // post: pushes value onto stack.
    //       will be first value popped off.
    {
	add(value);
    }

    /**
     * Remove a value from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> removes and returns the top element from stack.
     * </dl>
     * 
     * @return The value removed from the top of the stack.
     * @see #pop
     */
    public Object remove()
    // pre: !isEmpty()
    // post: returns and removes top element of stack
    {
	return data.removeFromHead();
    }

    /**
     * Remove a value from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> removes and returns the top element from stack.
     * </dl>
     * 
     * @return The value removed.
     */
    public Object pop()
    // pre: !isEmpty()
    // post: returns and removes top element of stack
    {
	return remove();
    }

    /**
     * Determine the number of elements in the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the size of the stack
     * </dl>
     * 
     * @return The number of values within the stack.
     */
    public int size()
    // post: returns the number of elements in the stack
    {
	return data.size();
    }

    /**
     * Construct a string representation of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representation of stack
     * </dl>
     * 
     * @return A string representing the stack.
     */
    public String toString()
    // post: returns a string representation of stack
    {
	return "<StackList: "+data+">";
    }
}

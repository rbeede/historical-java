// An implementation of a rectangular vector.
// (c) 1998 McGraw-Hill
package structure;

/**
 * An implementation of rectangular vectors.
 * This implementation of a Matrix is minimal.  Few operations
 * are provided, and no support for mathematical operations
 * is considered.
 * <p>
 * @version $Id: Matrix.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public class Matrix
{
    protected int height, width; // size of matrix
    protected Vector rows;       // vector of row vectors

    /**
     * Construct an empty matrix.
     * <dl>
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs empty matrix<br>
     * </dl>
     *
     */
    public Matrix()
    // post: constructs empty matrix
    {
	this(0,0);
    }

    /**
     * Constructs a matrix such that all values are null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> h >= 0, w >= 0;<br>
     * <dt><b>Postcondition:</b><dd> constructs an h row by w column matrix<br>
     * </dl>
     *
     * @param h Height of the matrix.
     * @param w Width of the matrix.
     */
    public Matrix(int h, int w)
    // pre: h >= 0, w >= 0;
    // post: constructs an h row by w column matrix
    {
	height = h;  // initialize height and width
	width = w;
	// allocate a vector of rows
	rows = new Vector(height);
	for (int r = 0; r < height; r++)
	{   // each row is allocated and filled with nulls
	    Vector theRow = new Vector(width);
	    rows.addElement(theRow);
	    for (int c = 0; c < width; c++)
	    {
		theRow.addElement(null);
	    }
	}
    }

    /**
     * Fetch an element from the matrix.
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= row < height(), 0 <= col < width()<br>
     * <dt><b>Postcondition:</b><dd> returns object at (row, col)<br>
     * </dl>
     *
     * @param row The row of the element
     * @param col The column of the element
     * @return Object located at matrix position (row,col)
     */
    public Object elementAt(int row, int col)
    // pre: 0 <= row < height(), 0 <= col < width()
    // post: returns object at (row, col)
    {
	Assert.pre(0 <= row && row <= height, "Row in bounds.");
	Assert.pre(0 <= col && col <= width, "Col in bounds.");
	Vector theRow = (Vector)rows.elementAt(row);
	return theRow.elementAt(col);
    }

    /**
     * Change the value at location (row, col)
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= row < height(), 0 <= col < width()<br>
     * <dt><b>Postcondition:</b><dd> changes location (row,col) to value<br>
     * </dl>
     *
     * @param value The new Object reference (possibly null).
     * @param row The row of the value to be changed.
     * @param col The column of the value to be changed.
     */
    public void setElementAt(Object value, int row, int col)
    // pre: 0 <= row < height(), 0 <= col < width()
    // post: changes location (row,col) to value
    {
	Assert.pre(0 <= row && row <= height, "Row in bounds.");
	Assert.pre(0 <= col && col <= width, "Col in bounds.");
	Vector theRow = (Vector)rows.elementAt(row);
	theRow.setElementAt(value,col);
    }

    /**
     * Add a new row, whose index will be r.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= r <= height()<br>
     * <dt><b>Postcondition:</b><dd> inserts row of null values to be row r<br>
     * </dl>
     *
     * @param r The index of the  newly inserted row.
     */
    public void insertRowAt(int r)
    // pre: 0 <= r <= height()
    // post: inserts row of null values to be row r
    {
	Assert.pre(0 <= r && r <= width, "Row in bounds.");
	height++;
	Vector theRow = new Vector(width);
	for (int c = 0; c < width; c++)
	{
	    theRow.addElement(null);
	}
	rows.insertElementAt(theRow,r);
    }

    /**
     * Add a new column, whose index will be c.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= c <= width()<br>
     * <dt><b>Postcondition:</b><dd> inserts column of null values to be column c<br>
     * </dl>
     *
     * @param c The index of the newly inserted column.
     */
    public void insertColAt(int c)
    // pre: 0 <= c <= width()
    // post: inserts column of null values to be column c
    {
	Assert.pre(0 <= c && c <= width, "Col in bounds.");
	width++;
	for (int r = 0; r < height; r++)
	{
	    Vector theRow = (Vector)rows.elementAt(r);
	    theRow.insertElementAt(null,c);
	}
    }

    /**
     * Remove the row whose index is r.
     * The row is returned as a vector.
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= r < height()<br>
     * <dt><b>Postcondition:</b><dd> removes row r and returns it as a Vector.<br>
     * </dl>
     *
     * @param r The index of the to-be-removed row.
     * @return A vector of values once in the row.
     */
    public Vector removeRowAt(int r)
    // pre: 0 <= r < height()
    // post: removes row r and returns it as a Vector.
    {
	Assert.pre(0 <= r && r < height,"There is a row to be removed.");
	Vector result = (Vector)rows.elementAt(r);
	height--;
	rows.removeElementAt(r);
	return result;
    }

    /**
     * Remove a column, whose index is c.
     * <dl>
     * <dt><b>Precondition:</b><dd> 0 <= c < width<br>
     * <dt><b>Postcondition:</b><dd> removes column c and returns it as a vector<br>
     * </dl>
     *
     * @param c The index of the column to be removed.
     * @return A vector of the values removed.
     */
    public Vector removeColAt(int c)
    // pre: 0 <= c < width
    // post: removes column c and returns it as a vector
    {
	Assert.pre(0 <= c && c < width,"There is a column to be removed.");
	Vector result = new Vector(height);
	width--;
	for (int r = 0; r < height; r++)
	{
	    Vector theRow = (Vector)rows.elementAt(r);
	    result.addElement(theRow.elementAt(c));
	    theRow.removeElementAt(c);
	}
	return result;
    }

    /**
     * Return the width of the matrix.
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of columns in matrix<br>
     * </dl>
     *
     * @return The number of columns in the matrix.
     */
    public int width()
    // post: returns number of columns in matrix
    {
	return width;
    }

    /**
     * Return the height of the matrix.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of rows in matrix<br>
     * </dl>
     *
     * @return The number of rows in the matrix.
     */
    public int height()
    // post: returns number of rows in matrix
    {
	return height;
    }

    /**
     * Construct a string representation of the matrix.
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string description of matrix.<br>
     * </dl>
     *
     * @return A string, representing the matrix.
     */
    public String toString()
    // post: returns string description of matrix.
    {
	StringBuffer s = new StringBuffer();
	s.append("<Matrix:\n");
	for (int r = 0; r < height; r++)
	{
	    for (int c = 0; c < width; c++)
	    {
		s.append("  <Row "+r+", Col "+c+", value=");
		s.append(elementAt(r,c)+">");
	    }
	    s.append("\n");
	}
	s.append(">");
	return s.toString();
    }
}


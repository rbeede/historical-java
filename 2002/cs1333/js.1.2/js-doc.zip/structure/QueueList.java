// Implementation of queues using doubly linked lists.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of queues based on lists.
 *
 * @version $Id: QueueList.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public class QueueList implements Queue
{
    /**
     * The list holding queue values in order.
     */
    protected List data;

    /**
     * Construct a new queue with no data.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Constructs a new, empty queue
     * </dl>
     */
    public QueueList()
    // post: constructs a new, empty queue
    {
	data = new DoublyLinkedList();
    }

    /**
     * Add a value to the tail of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> The value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value added.
     * @see #enqueue
     */
    public void add(Object value)
    // post: the value is added to the tail of the structure
    {
	data.addToTail(value);
    }

    /**
     * Add a value to the tail of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> The value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void enqueue(Object value)
    // post: the value is added to the tail of the structure
    {
	add(value);
    }

    /**
     * Remove a value from the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> The queue is not empty
     * <dt><b>Postcondition:</b><dd> The head of the queue is removed and returned
     * </dl>
     * 
     * @return The value actually removed.
     * @see #dequeue
     */
    public Object remove()
    // pre: the queue is not empty
    // post: the element at the head of the queue is removed and returned
    {
	return data.removeFromHead();
    }

    /**
     * Remove a value from the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> The queue is not empty
     * <dt><b>Postcondition:</b><dd> The head of the queue is removed and returned
     * </dl>
     * 
     * @return The value removed from the queue.
     */
    public Object dequeue()
    // pre: the queue is not empty
    // post: the element at the head of the queue is removed and returned
    {
	return remove();
    }

    /**
     * Fetch the value at the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> The queue is not empty
     * <dt><b>Postcondition:</b><dd> The element at the head of the queue is returned
     * </dl>
     * 
     * @return Reference to the first value of the queue.
     */
    public Object peek()
    // pre: the queue is not empty
    // post: the element at the head of the queue is returned
    {
	return data.peek();
    }

    /**
     * Determine the number of elements within the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns the number of elements in the queue.
     * </dl>
     * 
     * @return The number of elements within the queue.
     */
    public int size()
    // post: returns the number of elements in the queue
    {
	return data.size();
    }

    /**
     * Remove all the values from the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Removes all elements from the queue.
     * </dl>
     */
    public void clear()
    // post: removes all elements from the queue
    {
        data.clear();
    }

    /**
     * Determine if the queue is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns true iff the queue is empty
     * </dl>
     * 
     * @return True iff the queue is empty.
     */
    public boolean isEmpty()
    // post: returns true iff the queue is empty
    {
	return data.isEmpty();
    }

    /**
     * Construct a string representation of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> Returns string representation of queue
     * </dl>
     * 
     * @return String representing the queue.
     */
    public String toString()
    // post: returns a string representation of the queue
    {
	StringBuffer s = new StringBuffer();
	s.append("<QueueList:");
	Iterator li = data.elements();
	while (li.hasMoreElements())
	{
	    s.append(" "+li.value());
	}
	s.append(">");
	return s.toString();
    }
}

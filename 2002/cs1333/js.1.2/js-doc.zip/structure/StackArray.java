// An implementation of stacks, using vectors.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of a stack using an array.
 * <p>
 * @version $Id: StackArray.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public class StackArray implements Stack
{
    /**
     * An index to the top element of the stack.
     */
    protected int top;
    /**
     * The array of value references.  Top of the stack
     * is higher in array.
     */
    protected Object data[];
    /**
     * Construct a stack capable of holding at least size elements.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> an empty stack with initial capacity of size is created
     * </dl>
     * 
     * @param size The maximum size of the stack.
     */
    public StackArray(int size)
    // post: an empty stack with initial capacity of size is created
    {
 	data = new Object[size];
	clear();
    }

    /**
     * Remove all elements from the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from stack
     * </dl>
     */
    public void clear()
    // post: removes all elements from stack
    {
	top = -1;
    }

    /**
     * Add a value to the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds an element to stack.
     *       Will be next element popped if no intervening push
     * </dl>
     * 
     * @param item The value to be added.
     * @see #push
     */
    public void add(Object item)
    // post: adds an element to stack.
    //       Will be next element popped if no intervening push
    {
	Assert.pre(!isFull(),"Stack is not full.");
	top++;
	data[top] = item;
    }	 

    /**
     * Value is added to the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds an element to stack.
     *       will be next element popped if no intervening push
     * </dl>
     * 
     * @param item The value to be added.
     */
    public void push(Object item)
    // post: adds an element to stack.
    //       will be next element popped if no intervening push
    {
	add(item);
    }

    /**
     * Remove a value from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> removes and returns the top element from stack.
     * </dl>
     * 
     * @return The value removed from the top of the stack.
     * @see #pop
     */
    public Object remove()
    // pre: stack is not empty
    // post: removes and returns the top element from stack.
    {
	Assert.pre(!isEmpty(),"Stack is not empty.");
	Object result = data[top];
	data[top] = null;
	top--;
	return result;
    }

    /**
     * Remove a value from the top of the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> removes and returns the top element from stack.
     * </dl>
     * 
     * @return The value removed.
     */
    public Object pop()
    // pre: stack is not empty
    // post: removes and returns the top element from stack.
    {
	return remove();
    }

    /**
     * Get a reference to the top value in the stack.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> stack is not empty
     * <dt><b>Postcondition:</b><dd> returns the top element (most recently pushed) from stack
     * </dl>
     * 
     * @return A reference to the top element of the top of the stack.
     */
    public Object peek()
    // pre: stack is not empty
    // post: returns the top element (most recently pushed) from stack
    {
	// raise an exception if stack is already empty
	Assert.pre(!isEmpty(),"Stack is not empty.");
	return data[top];
    }

    /**
     * Determine if the stack is empty.
     * Provided for compatibility with java.util.Stack.empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the stack is empty
     * </dl>
     * 
     * @return True iff the stack is empty.
     * @see #isEmpty
     */
    public boolean empty()
    // post: returns true iff the stack is empty
    {
	return isEmpty();
    }

    /**
     * Determine the number of elements in the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the size of the stack
     * </dl>
     * 
     * @return The number of values within the stack.
     */
    public int size()
    // post: returns the size of the stack
    {
	return top+1;
    }

    /**
     * Determine if the stack is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the stack is empty
     * </dl>
     * 
     * @return True iff the stack is empty.
     * @see #empty
     */
    public boolean isEmpty()
    // post: returns true iff the stack is empty
    {
        return size() == 0;
    }

    /**
     * Determine if the stack is full.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the stack is empty
     * </dl>
     * 
     * @return True iff there is no more room in the stack.
     */
    public boolean isFull()
    // post: returns true iff the stack is empty
    {
        return top == (data.length-1);
    }

    /**
     * Construct a string representation of the stack.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representation of stack
     * </dl>
     * 
     * @return A string representing the stack.
     */
    public String toString()
    // post: returns a string representation of stack
    {
	StringBuffer sb = new StringBuffer();
	int i;
	sb.append("<StackArray: ");
	for (i = top; i >= 0; i--)
	{
	    sb.append(" "+data[i]);
	}
	sb.append(">");
	return sb.toString();
    }
}

// An implementation of an ordered structure, using lists
// (c) 1998 McGraw-Hill

package structure;
/**
 * A class that implements a collection of values that are kept in order.
 * Base values must be comparable.  Unlike Lists there is no notion of head
 * or tail.
 * <p>
 * @version $Id: OrderedList.java,v 3.2 1998/01/22 04:44:42 bailey Exp bailey $
 * @author duane a. bailey
 */
public class OrderedList implements OrderedStructure
{
    /**
     * Pointer to the smallest element, maintained as a singly linked list
     */
    protected SinglyLinkedListElement data; // smallest value
    /**
     * Number of elements in list
     */
    protected int count;	// number of values in list

    /**
     * Construct an empty ordered list
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an empty ordered list
     * </dl>
     */
    public OrderedList()
    // post: constructs an empty ordered list
    {
	clear();
    }

    /**
     * Remove all the elements from the ordered list
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the ordered list is empty
     * </dl>
     */
    public void clear()
    // post: the ordered list is empty
    {
	data = null;
	count = 0;
    }
    
    /**
     * Add a value to the ordered list, keeping values in order
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> value is added to the list, leaving it in order
     * </dl>
     * 
     * @param value The value to be added to the list
     */
    public void add(Object value)
    // pre: value is non-null
    // post: value is added to the list, leaving it in order
    {
	SinglyLinkedListElement previous = null; // element to adjust
	SinglyLinkedListElement finger = data;   // target element
	Comparable cValue = (Comparable)value;   // the inserted value
	// search for the correct location
	while ((finger != null) &&
	       (((Comparable)finger.value()).compareTo(cValue) < 0))
	{
	    previous = finger;
	    finger = finger.next();
	}
	// spot is found, insert
        if (previous == null) // check for insert at top
	{      
	    data = new SinglyLinkedListElement(cValue,data);
	} else {
	    previous.setNext(
	       new SinglyLinkedListElement(cValue,previous.next()));
	}
	count++;
    }

    /**
     * Determine if the ordered list contains a value
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null comparable object
     * <dt><b>Postcondition:</b><dd> returns true iff contains value
     * </dl>
     * 
     * @param value The value sought in the list
     * @return The actual value found, or null, if not
     */
    public boolean contains(Object value)
    // pre: value is non-null comparable object
    // post: returns true iff contains value
    {
	SinglyLinkedListElement finger = data; // target
	Comparable cValue = (Comparable)value; // value sought
	// search down list until we fall off or find bigger value
	while ((finger != null) &&
	       (((Comparable)finger.value()).compareTo(cValue) < 0))
	{
	    finger = finger.next();
	}
	return finger != null && cValue.equals(finger.value());
    }

    /**
     * Remove a value from the ordered list.  At most one value
     * is removed.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> an instance of value is removed, if in list
     * </dl>
     * 
     * @param value The value to be removed
     * @return The actual value removed from the list
     */
    public Object remove(Object value)
    // pre: value is non-null
    // post: an instance of value is removed, if in list
    {
	SinglyLinkedListElement previous = null; // element to adjust
	SinglyLinkedListElement finger = data;	 // target element
	Comparable cValue = (Comparable)value;   // value to remove
	// search for value or fall off list
	while ((finger != null) &&
	       (((Comparable)finger.value()).compareTo(cValue) < 0))
	{
	    previous = finger;
	    finger = finger.next();
	}
	// did we find it?
	if ((finger != null) && cValue.equals(finger.value())) {
	    // yes, remove it
	    if (previous == null)  // at top? 
	    {
		data = finger.next();
	    } else {
		previous.setNext(finger.next());
	    }
	    count--;
	    // return value
	    return finger.value();
	}
	// return nonvalue
	return null;
    }

    /**
     * Determine the number of elements in the list
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> returns the number of elements in the ordered list
     * </dl>
     * 
     * @return The number of elements in the list
     */
    public int size()
    // pre: returns the number of elements in the ordered list
    {
        return count;
    }

    /**
     * Determine if the list is empty
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the size is non-zero
     * </dl>
     * 
     * @return True if the ordered list is empty
     */
    public boolean isEmpty()
    // post: returns true iff the size is non-zero
    {
	return size() == 0;
    }
    /**
     * Construct an iterator for traversing elements of ordered list
     * in ascending order
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator over ordered list
     * </dl>
     * 
     * @return An iterator traversing elements in ascending order
     */
    public Iterator elements()
    // post: returns an iterator over ordered list
    {
	return new SinglyLinkedListIterator(data);
    }

    /**
     * Generate string representation of the ordered list
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of list
     * </dl>
     * 
     * @return String representing ordered list
     */
    public String toString()
    // post: returns string representation of list
    {
	StringBuffer s = new StringBuffer();
	s.append("<OrderedList:");
	Iterator si = elements();
	while (si.hasMoreElements())
	{
	    s.append(" "+si.value());
	}
	s.append(">");
	return s.toString();
    }
}

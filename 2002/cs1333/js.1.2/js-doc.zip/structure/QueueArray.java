// An implementation of queues, based on arrays.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of a queue based on arrays.
 * <p>
 * @version $Id: QueueArray.java,v 3.1 1998/01/22 04:22:56 bailey Exp bailey $
 * @author duane a. bailey
 */
public class QueueArray implements Queue
{
    /**
     * The references to values stored within the queue.
     */
    protected Object data[]; // an array of the data
    /**
     * index of the head of queue.
     */
    protected int head; // next dequeue-able value
    /**
     * current size of queue
     */
    protected int count; // current size of queue

    /**
     * Construct a queue holding at most size elements.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> create a queue capable of holding at most size values.
     * </dl>
     * 
     * @param size The maximum size of the queue.
     */
    public QueueArray(int size)
    // post: create a queue capable of holding at most size values
    {
        data = new Object[size];
        head = 0;
	count = 0;
    }

    /**
     * Add a value to the tail of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not full
     * <dt><b>Postcondition:</b><dd> the value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value added.
     * @see #enqueue
     */
    public void add(Object value)
    // pre: queue is not full
    // post: the value is added to the tail of the structure
    {
	Assert.pre(!isFull(),"Queue is not full.");
	int tail = (head + count) % data.length;
	data[tail] = value;
	count++;
    }

    /**
     * Add a value to the tail of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not full
     * <dt><b>Postcondition:</b><dd> the value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void enqueue(Object value)
    // pre: queue is not full
    // post: the value is added to the tail of the structure
    {
	add(value);
    }

    /**
     * Remove a value from the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the head of the queue is removed and returned
     * </dl>
     * 
     * @return The value actually removed.
     * @see #dequeue
     */
    public Object remove()
    // pre: the queue is not empty
    // post: the element at the head of the queue is removed and returned
    {
	Assert.pre(!isEmpty(),"The queue is not empty.");
	Object value = data[head];
	head = (head + 1) % data.length;
	count--;
	return value;
    }

    /**
     * Remove a value from the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the head of the queue is removed and returned
     * </dl>
     * 
     * @return The value removed from the queue.
     */
    public Object dequeue()
    // pre: the queue is not empty
    // post: the element at the head of the queue is removed and returned
    {
	return remove();
    }

    /**
     * Fetch the value at the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the element at the head of the queue is returned
     * </dl>
     * 
     * @return Reference to the first value of the queue.
     */
    public Object peek()
    // pre: the queue is not empty
    // post: the element at the head of the queue is returned
    {
	Assert.pre(!isEmpty(),"The queue is not empty.");
	return data[head];
    }

    /**
     * Determine the number of elements within the queue
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of elements in the queue.
     * </dl>
     * 
     * @return The number of elements within the queue.
     */
    public int size()
    // post: returns the number of elements in the queue
    {
	return count;
    }

    /**
     * Remove all the values from the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from the queue.
     * </dl>
     */
    public void clear()
    // post: removes all elements from the queue
    {
	// we could remove all the elements from the queue
	count = 0;
	head = 0;
    }
    
    /**
     * Determines if the queue is not able to accept any new values.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if the queue is at its capacity.
     * </dl>
     * 
     * @return True iff the queue is full.
     */
    public boolean isFull()
    // post: returns true if the queue is at its capacity
    {
	return count == data.length;
    }

    /**
     * Determine if the queue is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the queue is empty
     * </dl>
     * 
     * @return True iff the queue is empty.
     */
    public boolean isEmpty()
    // post: returns true iff the queue is empty
    {
	return count == 0;
    }

    /**
     * Construct a string representation of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of queue
     * </dl>
     * 
     * @return String representing the queue.
     */
    public String toString()
    // post: returns string representation of queue
    {
	StringBuffer s = new StringBuffer();
	int i,l;

	s.append("<QueueArray:");
	for (i = 0, l = head; i < count; i++, l = (l+1)%data.length)
	{
	    s.append(" "+data[l]);
	}
	s.append(">");
	return s.toString();
    }
}

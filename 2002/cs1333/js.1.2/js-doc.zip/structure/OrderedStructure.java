// Interface for container classes that manipulated ordered structures.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An interface the supports a Collection whose values are kept
 * in increasing order.  Values stored within ordered structures
 * should implement Comparable; ie. they should have an implemented
 * lessThan method.
 * 
 * @see java.lang.Comparable
 * @see java.lang.Comparable#compareTo
 * @version $Id: OrderedStructure.java,v 3.1 1998/01/19 14:51:27 bailey Exp $
 * @author duane a. bailey
 */
public interface OrderedStructure extends Collection
{
}

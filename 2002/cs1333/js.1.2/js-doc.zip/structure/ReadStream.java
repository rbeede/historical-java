// A stream for reading basic types from input.
// (c) 1998 McGraw-Hill

package structure;
import java.io.*;

/**
 * A ReadStream provides reasonable access to the typewritten
 * data on an input stream.  Usually, a ReadStream is constructed
 * with no parameters, causing the ReadStream to open access to
 * System.in.
 * <p>
 * The access methods allow one to read from the stream, much as is done
 * with Pascal.  
 * 
 * @version $Id: ReadStream.java,v 3.4 1998/09/21 17:37:58 bailey Exp bailey $
 * @author duane a. bailey
 */
public class ReadStream extends FilterInputStream 
{
    /**
     * The underlying data stream.	
     */
    protected DataInputStream strm;
    /**
     * True iff we've seen the end-of-file
     */
    protected boolean atEOF;		// are we at the end-of-file
    /**
     * The buffer to hold pushback characters
     */
    protected char buffer[];		// pushback buffer
    /**
     * The number of characters to be stored in buffer.
     */
    protected int buffersize;		// current size of pushback buffer	
    /**
     */
    protected int buffertop;		// top element of pushback stack

    /**
     * Whether or not accept the CR as part of previous newline.
     */
    protected boolean absorbNL = false; // absorb NL if next (part of cr)

    /**
     * Construct an empty ReadStream, obtaining info from System.in.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a pascal-like stream based on System.in
     * </dl>
     */
    public ReadStream()
    // post: constructs a pascal-like stream based on System.in
    {
	this(System.in);
    }

    /**
     * Construct a ReadStream based on pre-existing input stream.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> strm is a valid input stream.
     * <dt><b>Postcondition:</b><dd> constructs a pascal-like stream based on strm
     * </dl>
     * 
     * @param strm The pre-existing input stream.
     */
    public ReadStream(InputStream strm)
    // pre: strm is a valid input stream.
    // post: constructs a pascal-like stream based on strm
    {
  
	// This stream filters input from a data input stream
	// which filters input from strm.
        super(new DataInputStream(strm));
	this.strm = (DataInputStream)in;
	atEOF = false;
	buffer = new char[8];
        buffersize = 8;
	buffertop = -1;
    }

    /**
     * Determine if we've seen end-of-file.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> are we at the end-of-file?
     * </dl>
     * 
     * @return True if the next character to be read is EOF.
     */
    public boolean eof()
    // pre: are we at the end-of-file?
    {
	// have we already detected EOF?
	if (atEOF) return true;
	// check stream by attempting a read
	peek();
        return atEOF;
    }

    static private boolean isWhite(char c)
    // post: returns true if char is whitespace
    {
	return Character.isWhitespace(c); /* JDK 1.1 */
    }

    /**
     * Read (but don't consume) next char in stream.
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns next character in stream, without consuming it
     * </dl>
     * 
     * @return The next character to be read.
     */
    public char peek()
    // post: returns next character in stream, without consuming it
    {
	char c = readChar();
	pushbackChar(c);
	return c;
    }

    /**
     * Return true if the next character to be read is an end-of-line mark.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if next stream char is a eoln char
     * </dl>
     * 
     * @return True iff the next character is an end-of-line mark.
     */
    public boolean eoln()
    // post: returns true if next stream char is a eoln char
    {
	char c = peek();
	return eof() || (c == '\n') || (c == '\r');
    }

    /**
     * Read characters up to and including the end-of-line
     * mark.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads input stream until end-of-line (\r or \n)
     * </dl>
     */
    public void readln()
    // post: reads input stream until end-of-line (\r or \n or \n\r)
    {
	char c;
	for (c = readChar(); !eoln(); c = readChar());
    }

    /**
     * Consume all the white-space characters until EOF or
     * other data.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> input pointer is at EOF, or non-whitespace char.
     * </dl>
     */
    public void skipWhite()
    // post: input pointer is at EOF, or non-whitespace char.
    {
	char c;
	for (c = readChar(); isWhite(c);  c = readChar());
	pushbackChar(c);
    }

    /**
     * Skip white space and read in the next non-whitespace word
     * as a string.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads next word as a string
     * </dl>
     * 
     * @return The next word on the input.
     */
    public String readString()
    // post: reads next word as string
    {
	char buffer[] = new char[512];
	char c = 0;
	int count = 0;

	skipWhite();
	while (!eof())
	{
	    c = readChar();
	    if (isWhite(c))
	    {
		pushbackChar(c);
		break;
	    }
	    buffer[count++] = c;
	}
	return new String(buffer,0,count);
    }

    private boolean acceptChar(char c)
    // post: returns true if the next character is upper or lower c
    {
	char d = readChar();
	if (Character.toLowerCase(c) ==
	    Character.toLowerCase(d)) return true;
	pushbackChar(d);
	return false;
    }

    private boolean acceptWord(String s)
    // post: returns true if word in s in on input (consumed)
    //       or false
    {
	char c;
	skipWhite();
	for (int i = 0; i < s.length(); i++)
	{
	    if (!acceptChar(s.charAt(i))) {
		for (int j = i-1; j>= 0; j--) {
		    pushbackChar(s.charAt(j));
		}
		return false;
	    }
	}
	return true;
    }

    /**
     * Read the next word "true" or "false" as a boolean.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns next boolean value read from input
     * </dl>
     * 
     * @return The value true or false, depending on input.
     */
    public boolean readBoolean()
    // post: returns next boolean value read from input
    {
	if (acceptWord("true")) return true;
	else if (!acceptWord("false")) Assert.fail("Boolean not found on input.");
	return false;
    }

    /**
     * Read next character, whitespace or not.  Fail on eof.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns next character, or 0 for eof
     * </dl>
     * 
     * @return The next character, or the value 0 indicating EOF.
     */
    public char readChar()
    // post: returns next character, or 0 for eof
    {
	char c = (char)0;
	try {
	    if (atEOF) return (char)0;
	    if (buffertop >= 0) {
		c = buffer[buffertop--];
	    } else {
		c = (char)strm.readByte();
	    }
	}
	catch (EOFException e) {
	    atEOF = true;
	}
	catch (IOException e) {
	    Assert.fail("Input error free.");
	}
	finally {
	    if (absorbNL && (c == '\n')) {
		absorbNL = false;
		c = readChar();
	    }
	    absorbNL = c == '\r';
	    return c;
	}
    }

    /**
     * Return character to input stream for reading at later time.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> pushes back character, possibly clearing EOF.
     *       if c == 0, does nothing
     * </dl>
     * 
     * @param c The character to push back onto input stream.
     */
    public void pushbackChar(char c)
    // post: pushes back character, possibly clearing EOF.
    //       if c == 0, does nothing
    {
	if (c == (char)0) return;
	atEOF = false;
	buffertop++;
	if (buffertop == buffersize) {
	    // buffer too small, extend it.
	    char old[] = buffer;
	    buffersize = buffersize*2;
	    buffer = new char[buffersize];
	    for (int i = 0; i < buffertop; i++)
	    {
		buffer[i] = old[i];
	    }
	}
	buffer[buffertop] = c;
	absorbNL = false;
    }

    /**
     * Reads the next double value from input stream.
     * Whitespace is skipped beforehand.
     * CURRENTLY NOT WORKING.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads in double value
     * </dl>
     * 
     * @return The next double found on input.
     */
    public double readDouble()
    // post: reads in double value
    {
	StringBuffer sb = new StringBuffer();
	char c;
	skipWhite();
	if (acceptChar('+')) sb.append('+');
	else if (acceptChar('-')) sb.append('-');
	c = readChar();
	while (Character.isDigit(c))
	{
	    sb.append(c);
	    c = readChar();
	}
	pushbackChar(c);
	if (acceptChar('.')) {
	    sb.append('.');
	    c = readChar();
	    while (Character.isDigit(c))
	    {
		sb.append(c);
		c = readChar();
	    }
	    pushbackChar(c);
	}
	if (acceptChar('E'))
	{
	    sb.append('E');
	    if (acceptChar('+')) sb.append('+');
	    else if (acceptChar('-')) sb.append('-');
	    c = readChar();
	    while (Character.isDigit(c))
	    {
		sb.append(c);
		c = readChar();
	    }
	    pushbackChar(c);
	}
	String s = sb.toString();
	//	System.out.println("["+s+"]");
	return Double.valueOf(s).doubleValue();
    }

    /**
     * Read floating point value from input
     * (Currently not working).
     * Skips whitespace before reading.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads floating point value and returns value
     * </dl>
     * 
     * @return Next floating point number.
     */
    public float readFloat()
    // post: reads floating point value and returns value
    {
	return (float)readDouble();
    }

    /**
     * Read an array of bytes from input.
     * <p>
     * @param b The array of bytes; holds result.
     */
    public void readFully(byte b[]) throws IOException
    // post: reads an array of bytes from stream???
    {
        strm.readFully(b);
    }

    /**
     * Read input into byte array.
     * <p>
     * @param b Target array of bytes.
     * @param off Offset into byte array to start reading.
     * @param len Number of bytes to be read.
     */
    public void readFully(byte b[], int off, int len) throws IOException
    // post: reads a portion of an array of bytes from stream
    {
        strm.readFully(b,off,len);
    }

    /**
     * Reads an integer from input stream.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads a short integer from stream
     * </dl>
     * 
     * @return The integer read form input.
     */
    public short readShort()
    // post: reads a short integer from stream
    {
	return (short)readLong();
    }

    /**
     * Reads an integer from input stream.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads an integer from stream
     * </dl>
     * 
     * @return The integer read form input.
     */
    public int readInt()
    // post: reads an integer from stream
    {
	return (int)readLong();
    }

    /**
     * Read a (potentially long) input.
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads a long integer from stream
     * </dl>
     * 
     * @return The integer read from input.
     */
    public long readLong()
    // post: reads a long integer from stream
    {
	boolean negate = false;
	int digitsRead = 0;
	long value = 0;
	int base = 10;
	char c;
	int d;
	skipWhite();
	if (eof()) return 0;
	for (;;)
	{
	    if (eof()) break;
	    c = readChar();
	    if (digitsRead == 0) {
		if (c == '-') { 
		    negate = true;
		    continue;
		}
	    }
	    if ((digitsRead == 0) && (c == '0')) {
	        base = 8;
                digitsRead++;
		continue;
            }
	    if ((digitsRead == 1) && (base == 8) && ((c == 'x') ||
						     (c == 'X'))) {
		base = 16;
		digitsRead++;
		continue;
	    }
	    d = c - '0';
	    if ((c >= 'a') && (c <= 'f')) {
		d = c - 'a' + 10;
	    } else if ((c >= 'A') && (c <= 'F')) {
		d = c - 'A' + 10;
	    }
	    if ((d < 0) || (d >= base)) {
		pushbackChar(c);
		break;
	    }
	    digitsRead++;
	    value = value*base+d;
        }
	if (negate) value = -value;
	return value;
    }

    /**
     * Read the remainder of line, including end-of-line mark.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> reads remainder of line, returns as string
     * </dl>
     * 
     * @return The string containing all the characters to end-of-line.
     */
    public String readLine()
    // post: reads remainder of line, returns as string
    {
	StringBuffer result = new StringBuffer();
	char c;
	while (!eoln())
	{
	    result.append(readChar());
	}
	readChar();
	return result.toString();
    }

    /**
     * Read unicode from input.
     * <p>
     * @return String version of UTF character.
     */
    public String readUTF() throws IOException
    // post: not supported.  Avoid use.
    {
        return strm.readUTF();
    }
}


// Implementation of lists, using singly linked elements.
// (c) 1998 McGraw-Hill

package structure;

/**
 * Singly linked lists have elements connected by a single reference.
 * They are space-efficient, but tail-related operations may be more
 * costly than with doubly linked lists.
 * <p>
 * @version $Id: SinglyLinkedList.java,v 3.2 1998/01/22 03:06:25 bailey Exp bailey $
 * @author duane a. bailey
 * @see DoublyLinkedList
 */
public class SinglyLinkedList implements List
{
    /**
     * The number of elements in list.
     */
    protected int count;   	            // list size
    /**
     * The head of the list.  A reference to a singly linked list element.
     */
    protected SinglyLinkedListElement head; // ref. to first element

    /**
     * Construct an empty list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> generates an empty list.
     * </dl>
     */
    public SinglyLinkedList()
    // post: generates an empty list.
    {
    	head = null;
	count = 0;
    }

    /**
     * Add an object to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> value is added to beginning of list (see addToHead)
     * </dl>
     * 
     * @param value The value to be added to the head of the list.
     * @see #addToHead
     */
    public void add(Object value)
    // post: adds value to beginning of list.
    {
	addToHead(value);
    }
    
    /**
     * Add a value to the head of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> value is added to beginning of list
     * </dl>
     * 
     * @param value The value to be added to the head of the list.
     */
    public void addToHead(Object value)
    // post: adds value to beginning of list.
    {
	// note the order that things happen:
	// head is parameter, then assigned
	head = new SinglyLinkedListElement(value, head);
	count++;
    }

    /**
     * Remove a value from the first element of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> removes and returns value from beginning of list
     * </dl>
     * 
     * @return The value actually removed.
     */
    public Object removeFromHead()
    // pre: list is not empty
    // post: removes and returns value from beginning of list
    {
	SinglyLinkedListElement temp = head;
	head = head.next(); // move head down the list
	count--;
	return temp.value();
    }

    /**
     * Add a value to the tail of the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> adds value to end of list
     * </dl>
     * 
     * @param value The value to be added to the tail of the list.
     */
    public void addToTail(Object value)
    // post: adds value to end of list
    {
	// location for the new value
	SinglyLinkedListElement temp =
	    new SinglyLinkedListElement(value,null);
	if (head != null)
	{
	    // pointer to possible tail
	    SinglyLinkedListElement finger = head;
	    while (finger.next() != null)
	    {
		finger = finger.next();
	    }
	    finger.setNext(temp);
	} else head = temp;
	count++;
    }

    /**
     * Remove the last value from the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> removes the last value from the list
     * </dl>
     * 
     * @return The value actually removed.
     */
    public Object removeFromTail()
    // pre: list is not empty
    // post: last value in list is returned
    {
	SinglyLinkedListElement finger = head;
	SinglyLinkedListElement previous = null;
	Assert.pre(head != null,"List is not empty.");
	while (finger.next() != null) // find end of list
	{
	    previous = finger;
	    finger = finger.next();
	}
	// finger is null, or points to end of list
	if (previous == null)
	{
	    // has exactly 1 element
	    head = null;
        }
	else
	{
	    // pointer to last element is reset.
	    previous.setNext(null);
	}
	count--;
	return finger.value();
    }

    /**
     * Fetch the first element of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> returns first value in list
     * </dl>
     * 
     * @return A reference to first element of the list.
     */
    public Object peek()
    // pre: list is not empty
    // post: returns the first value in the list
    {
	return head.value();
    }

    /**
     * Fetch the last element of the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> list is not empty
     * <dt><b>Postcondition:</b><dd> returns last value in list
     * </dl>
     * 
     * @return A reference to the last element of the list.
     */
    public Object tailPeek()
    // pre: list is not empty
    // post: returns the last value in the list
    {
	SinglyLinkedListElement finger = head;
	Assert.condition(finger != null,"List is not empty.");
	while (finger != null &&
	       finger.next() != null)
	{
	    finger = finger.next();
	}
	return finger.value();
    }

    /**
     * Check to see if a value is in the list.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is not null
     * <dt><b>Postcondition:</b><dd> returns true iff value is found in list.
     * </dl>
     * 
     * @param value The value sought.
     * @return True if the value is within the list.
     */
    public boolean contains(Object value)
    // pre: value is not null
    // post: returns true iff value is found in list.
    {
	SinglyLinkedListElement finger = head;
	while (finger != null &&
	       !finger.value().equals(value))
	{
	    finger = finger.next();
	}
	return finger != null;
    }

    /**
     * Remove a value from the list.  At most one value will be removed.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is not null
     * <dt><b>Postcondition:</b><dd> removes first element with matching value, if any.
     * </dl>
     * 
     * @param value The value to be removed.
     * @return The actual value removed.
     */
    public Object remove(Object value)
    // pre: value is not null
    // post: removes first element with matching value, if any.
    {
	SinglyLinkedListElement finger = head;
	SinglyLinkedListElement previous = null;
	while (finger != null &&
	       !finger.value().equals(value))
	{
	    previous = finger;
	    finger = finger.next();
	}
	// finger points to target value
	if (finger != null) {
	    // we found the element to remove
	    if (previous == null) // it is first
	    {
		head = finger.next();
	    } else {              // it's not first
		previous.setNext(finger.next());
	    }
	    count--;
	    return finger.value();
	}
	// didn't find it, return null
	return null;
    }

    /**
     * Determine the number of elements in the list.	
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of elements in list
     * </dl>
     * 
     * @return The number of elements in the list.
     */
    public int size()
    // post: returns the number of elements in list
    {
	return count;
    }

    /**
     * Determine if list is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the list is empty
     * </dl>
     * 
     * @return True iff the list is empty.
     */
    public boolean isEmpty()
    // post: returns true iff the list is empty
    {
	return size() == 0;
    }
    
    /**
     * Remove all values from list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from the list
     * </dl>
     */
    public void clear()
    // post: removes all elements from the list
    {
        head = null;
	count = 0;
    }

    /**
     * Returns an iterator traversing list from head to tail.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns enumeration allowing traversal of list
     * </dl>
     * 
     * @return An iterator to traverse list.
     */
    public Iterator elements()
    // post: returns enumeration allowing traversal of list
    {
	return new SinglyLinkedListIterator(head);
    }
    // THIS CODE IS NOT AVAILABLE

    /**
     * To determine the number of elements in the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of elements in the list
     * </dl>
     * 
     * @return The number of elements in the list.
     */
    public int size()
    // post: returns the number of elements in the list
    {
        // number of elements we've seen in list
        int elementCount = 0;
        // reference to potential first element
        SinglyLinkedListElement finger = head;
 
        while (finger != null) {
            // finger references a new element, count it
            elementCount++;
	    // reference possible next element
            finger = finger.next();
        }
        return elementCount;
    }
    
    /**
     * Determine if the list is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff list has no elements
     * </dl>
     * 
     * @return True iff the list has no elements.
     */
    public boolean isEmpty()
    // post: returns true iff list has no elements
    {
        return size() == 0;
    }

    /**
     * Construct a string representing the list.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns a string representing list
     * </dl>
     * 
     * @return A string representing the list.
     */
    public String toString()
    // post: returns a string representing list
    {
	StringBuffer s = new StringBuffer();
	s.append("<SinglyLinkedList:");
	Iterator li = elements();
	while (li.hasMoreElements())
	{
	    s.append(" "+li.nextElement());
	}
	s.append(">");
	return s.toString();
    }
}


// A simple bitset class.
// (c) 1998 McGraw-Hill

package structure;

/**
 * A simple class implementing a set of numbered bits.
 *
 * @version $Id: BitSet.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 * @see java.util.BitSet
 */
public class BitSet
{
    /**
     * The number of bits contained in a single integer.
     */
    protected final int bitsPerInt = 32;
    /**
     * The initial capacity of the set, by default.
     */
    protected final int initialCapacity = 256;
    /**
     * The array of integers that contains the set's bits
     */
    protected int data[];
    /**
     * The current number of integers allocated.
     */
    protected int allocated;

    /**
     * Constructs an empty bitset.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an empty set of small integers
     * </dl>
     */
    public BitSet()
    // post: constructs an empty set of small integers
    {	
	clear(initialCapacity);
    }

    /**
     * Constructs an empty bitset with potential to hold values between
     * 0..count-1.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an empty set with count potential elements
     * </dl>
     * 
     * @param count The number of distinct values possibly in set.
     */
    public BitSet(int count)
    // post: constructs an empty set with count potential elements
    {	
	clear(count);
    }

    /**
     * Adds a bit to the bitset, if not already there.
     * Set is potentially extended.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> i >= 0
     * <dt><b>Postcondition:</b><dd> i is added to the set
     * </dl>
     * 
     * @param i  The number of  the bit to be added.
     */
    public void add(int i)
    // pre: i >= 0
    // post: i is added to the set
    {
	extend(i);
	int index = indexOf(i);
	int offset = offsetOf(i);
	data[index] |= 1<<offset;
    }

    /**
     * Remove bit i from the bitset.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> i >= 0
     * <dt><b>Postcondition:</b><dd> removes i from set if present
     * </dl>
     * 
     * @param i The index of the bit to be removed.
     */
    public void remove(int i)
    // pre: i >= 0
    // post: removes i from set if present
    {
	if (probe(i)) {
	    int index = indexOf(i);
	    int offset = offsetOf(i);
	    data[index] &= ~(1<<offset);
	}
    }
    /**
     * Determine if a bit is a member of the set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> i >= 0
     * <dt><b>Postcondition:</b><dd> returns true iff i in set
     * </dl>
     * 
     * @param i The bit index of potential bit.
     * @return True iff bit i is in the set.
     */
    public boolean contains(int i)
    // pre: i >= 0
    // post: returns true iff i in set
    {
	return probe(i) && (0 != (data[indexOf(i)] & (1<<offsetOf(i))));
    }

    /**
     * Remove all bits from the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all values from set
     * </dl>
     */
    public void clear()
    // post: removes all values from set
    {
	clear(initialCapacity);
    }

    /**
     * Remove bits from set; set size to count.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all values from set, sets set size to count
     * </dl>
     * 
     * @param count The new capacity of the newly empty set.
     */
    public void clear(int count)
    // post: removes all values from set, sets set size to count
    {
	int i;
	allocated = (count+bitsPerInt-1)/bitsPerInt;
	data = new int[allocated];
	for (i = 0; i < allocated; i++)
	{
	    data[i] = 0;
	}
    }

    /**
     * Returns a copy of the set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a copy of the set
     * </dl>
     * 
     * @return A new BitSet with the same values as this.
     */
    public Object clone()
    // post: constructs a copy of the set
    {
	BitSet duplicate = new BitSet(allocated*bitsPerInt);
	int i;
	for (i = 0; i < allocated; i++)
	{
	    duplicate.data[i] = data[i];
	}
	return duplicate;
    }

    /**
     * Compute a new set that is the union of this set and other.
     * Elements of the new set appear in at least one of the two sets.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null
     * <dt><b>Postcondition:</b><dd> constructs set w/elements from this and other
     * </dl>
     * 
     * @param other The set to be unioned with this.
     * @return The union of the two sets.
     */
    public Object union(BitSet other)
    // pre: other is non-null
    // post: constructs set w/elements from this and other
    {
	int leftSize = allocated;
	int rightSize = other.allocated;
        if (leftSize < rightSize) return other.union(this);
	BitSet result = new BitSet(leftSize*bitsPerInt);
	int i;
	for (i = 0; i < rightSize; i++)
	{
	    result.data[i] = data[i] | other.data[i];
	}
	for (;i < leftSize; i++)
	{
	    result.data[i] = data[i];
	}
	return result;
    }

    /**
     * Return the intersection of this set and the other.
     * A bit is in the result if it is in this set and other.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is not null
     * <dt><b>Postcondition:</b><dd> constructs set w/elements in this and other
     * </dl>
     * 
     * @param other The other set to be intersected with this.
     */
    public Object intersection(BitSet other)
    // pre: other is not null
    // post: constructs set w/elements in this and other
    {
	int leftSize = allocated;
	int rightSize = other.allocated;
        if (leftSize < rightSize) return other.intersection(this);
	BitSet result = new BitSet(rightSize*bitsPerInt);
	int i;
	for (i = 0; i < rightSize; i++)
	{
	    result.data[i] = data[i] & other.data[i];
	}
	return result;
    }

    /**
     * Computes the difference between this set and the other.
     * An element is in the difference if it is in this, but not in other.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is not null
     * <dt><b>Postcondition:</b><dd> constructs set w/elements from this but not other
     * </dl>
     * 
     * @param other The difference between this set and other.
     */
    public Object difference(BitSet other)
    // pre: other is not null
    // post: constructs set w/elements from this but not other
    {
	int leftSize = allocated;
	int rightSize = other.allocated;
	BitSet result = new BitSet(leftSize*bitsPerInt);
	int i;
	if (leftSize <= rightSize) {
	    for (i = 0; i < leftSize; i++)
	    {
		result.data[i] = data[i] & ~other.data[i];
	    }
	} else {
	    for (i = 0; i < rightSize; i++)
	    {
		result.data[i] = data[i] & ~other.data[i];
	    }
	    for (i = rightSize; i < leftSize; i++)
	    {
		result.data[i] = data[i];
	    }
	}
	return result;
    }

    /**
     * Returns true iff this set is a subset of the other.
     * A set is a subset of another if its elements are elements
     * of the other.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is not null
     * <dt><b>Postcondition:</b><dd> returns true iff elements of this are all in other
     * </dl>
     * 
     * @param other The potential superset.
     * @return The difference between this and other.
     */
    public boolean subset(BitSet other)
    // pre: other is not null
    // post: returns true iff elements of this are all in other
    {
	int leftSize = allocated;
	int rightSize = other.allocated;
	int i;
	if (leftSize <= rightSize) {
	    for (i = 0; i < leftSize; i++)
	    {
		if (0 != (data[i] & ~other.data[i])) return false;
	    }
	} else {
	    for (i = 0; i < rightSize; i++)
	    {
		if (0 != (data[i] & ~other.data[i])) return false;
	    }
	    for (i = rightSize; i < leftSize; i++)
	    {
		if (0 != data[i]) return false;
	    }
	}
	return true;
    }

    /**
     * Determine if a set is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff this set is empty
     * </dl>
     * 
     * @return True iff this set is empty.
     */
    public boolean isEmpty()
    // post: returns true iff this set is empty
    {
	int i;
	for (i = 0; i < allocated; i++) {
	    if (data[i] != 0) return false;
	}
	return true;
    }

    /**
     * Return true iff this set and o contain the same elements.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> o is not null
     * <dt><b>Postcondition:</b><dd> returns true iff this and o have same elements
     * </dl>
     * 
     * @param o Another non-null bitset. 
     * @return True iff this set has the same elements as o.
     */
    public boolean equals(Object o)
    // pre: o is not null
    // post: returns true iff this and o have same elements
    {
	BitSet other = (BitSet)o;
	int leftSize = allocated;
	int rightSize = other.allocated;
	if (leftSize < rightSize) return other.equals(this);
	int i;
	for (i = 0; i < rightSize; i++) {
	    if (data[i] != other.data[i]) return false;
	}
	for (i = rightSize; i < leftSize; i++) {
	    if (data[i] != 0) return false;
	}
	return true;
    }

    /**
     * Determine the int index associated with a bit number.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> bit >= 0
     * <dt><b>Postcondition:</b><dd> returns index of integer containing bit b
     * </dl>
     * 
     * @return the index in array of bit b.
     */
    protected int indexOf(int b)
    // pre: bit >= 0
    // post: returns index of integer containing bit b
    {
	return b/bitsPerInt;
    }	

    /**
     * Return the bit index within the associated int of bit "bit"
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> bit >= 0
     * <dt><b>Postcondition:</b><dd> returns bit position of bit in word.
     * </dl>
     *
     * @param bit The index of the bit in set.
     * @return The index of the bit desired, within the word.
     */
    protected int offsetOf(int bit)
    // pre: bit >= 0
    // post: returns bit position of bit in word
    {
	return bit%bitsPerInt;
    }

    /**
     * Ensures that bit "bit" is within capacity of set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> bit >= 0
     * <dt><b>Postcondition:</b><dd> ensures set is large enough to contain bit
     * </dl>
     */
    protected void extend(int bit)
    // pre: bit >= 0
    // post: ensures set is large enough to contain bit
    {
	if (!probe(bit)) {
	    int index = indexOf(bit);
	    int newData[];
	    int newAllocated = allocated;
	    int i;
	    while (newAllocated <= index) newAllocated *= 2;
	    newData = new int[newAllocated];
	    for (i = 0; i < allocated; i++) {
		newData[i] = data[i];
	    }
	    for (i = allocated; i < newAllocated; i++) {
		newData[i] = 0;
	    }
	    data = newData;
	    allocated = newAllocated;
	}
    }


    /**
     * Determines if bit is within capacity of set.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> bit >= 0
     * <dt><b>Postcondition:</b><dd> Returns rue if set is large enough to contain bit.
     * </dl>
     * 
     * @param bit The index of desired bit.
     * @return True if index of bit is within array.
     */
    protected boolean probe(int bit)
    // pre: bit >= 0
    // post: returns true if set is large enough to contain bit
    {
	int index = indexOf(bit);
	return data.length > index;
    }

    /**
     * Constructs string representing set.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of set
     * </dl>
     * 
     * @return String representing bitset.
     */
    public String toString()
    // post: returns string representation of set
    {
	StringBuffer s = new StringBuffer();
	int i;
	s.append("<BitSet:");
	for (i = 0; probe(i); i++) {
	    if (contains(i)) s.append(" "+Integer.toString(i));
	}
	s.append(">");
	return s.toString();
    }
}

// An interface for an ordered structure that allows you to remove min elts
// (c) 1998 McGraw-Hill
package structure;

// ideally this would extend linear, but there are problems....
/**
 * Interface describing an queue of prioritized values.
 * This linear-like structure has values that
 * are inserted in such a way as to allow them to be removed in
 * increasing order.
 * <p>
 * @version $Id: PriorityQueue.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public interface PriorityQueue
{
    /**
     * Fetch lowest valued (highest priority) item from queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns the minimum value in priority queue
     * </dl>
     * 
     * @return The smallest value from queue.
     */
    public Comparable peek();
    // pre: !isEmpty()
    // post: returns the minimum value in priority queue

    /**
     * Returns the minimum value from the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> !isEmpty()
     * <dt><b>Postcondition:</b><dd> returns and removes minimum value from queue
     * </dl>
     * 
     * @return The minimum value in the queue.
     */
    public Comparable remove();
    // pre: !isEmpty()
    // post: returns and removes minimum value from queue

    /**
     * Add a value to the priority queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null comparable
     * <dt><b>Postcondition:</b><dd> value is added to priority queue
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void add(Comparable value);
    // pre: value is non-null comparable
    // post: value is added to priority queue

    /**
     * Determine if the queue is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff no elements are in queue
     * </dl>
     * 
     * @return True if the queue is empty.
     */
    public boolean isEmpty();
    // post: returns true iff no elements are in queue

    /**
     * Determine the size of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements within queue
     * </dl>
     * 
     * @return The number of elements within the queue.
     */
    public int size();
    // post: returns number of elements within queue

    /**
     * Remove all the elements from the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from queue
     * </dl>
     */
    public void clear();
    // post: removes all elements from queue
}

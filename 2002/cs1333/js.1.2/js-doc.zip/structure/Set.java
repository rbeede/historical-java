// A simple Set interface.
// (c) 1998 McGraw-Hill

package structure;

/**
 * Implementation of a set of elements.
 * As with the mathematical object, the elements of the set are
 * not duplicated.  No order is implied or enforced in this structure.
 * <p>
 * @version $Id: Set.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
public interface Set extends Collection
{
    /**
     * Determine if this set is a subset of other.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns true iff this set is subset of other
     * </dl>
     * 
     * @param other The potential superset.
     */
    public boolean subset(Set other);
    // pre: other is non-null reference to set
    // post: returns true iff this set is subset of other

    /**
     * Compute the union of this set with other.
     * This set not modified.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns new set containing union of this and other
     * </dl>
     * 
     * @param other The set to be unioned with this.
     * @return Union of this and other.
     */
    public Object union(Set other);
    // pre: other is non-null reference to set
    // post: returns new set containing union of this and other

    /**
     * Compute the intersection of this set and other.
     * Members of result are in both this and other.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns new set containing intersection of this and other
     * </dl>
     * 
     * @param other The other set to be intersected with this.
     * @return Intersection of this and other.
     */
    public Object intersection(Set other);
    // pre: other is non-null reference to set
    // post: returns new set containing intersection of this and other

    /**
     * Compute the difference between two sets.
     * Values of the result are members of this, but not other.
     * <dl>
     * <dt><b>Precondition:</b><dd> other is non-null reference to set
     * <dt><b>Postcondition:</b><dd> returns new set containing difference of this and other
     * </dl>
     * 
     * @param other The set whose values are to be eliminated from this.
     * @return Difference between this and other.
     */
    public Object difference(Set other);
    // pre: other is non-null reference to set
    // post: returns new set containing difference of this and other
}

// An implementation of queues, based on vectors.
// (c) 1998 McGraw-Hill

package structure;

/**
 * An implementation of queues written using vectors.
 * <p>
 * @version $Id: QueueVector.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public class QueueVector implements Queue
{
    /**
     * The vector that maintains the queue data
     */
    protected Vector data;

    /**
     * Construct an empty queue
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an empty queue.
     * </dl>
     */
    public QueueVector()
    // post: constructs an empty queue
    {
        data = new Vector();
    }

    /**
     * Constructs an empty queue with an initial allocation of size.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs an empty queue of appropriate size
     * </dl>
     * 
     * @param size Approximate largest queue size needed.
     */
    public QueueVector(int size)
    // post: constructs an empty queue of appropriate size
    {
        data = new Vector(size);
    }

    /**
     * Add a value to the tail of the queue
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value added.
     * @see #enqueue
     */
    public void add(Object value)
    // post: the value is added to the tail of the structure
    {
	data.addElement(value);
    }

    /**
     * Add a value to the tail of the queue
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the value is added to the tail of the structure
     * </dl>
     * 
     * @param value The value to be added.
     */
    public void enqueue(Object value)
    // post: the value is added to the tail of the structure
    {
	add(value);
    }
    

    /**
     * Remove a value from the head of the queue
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the head of the queue is removed and returned
     * </dl>
     * 
     * @return The value actually removed.
     * @see #dequeue
     */
    public Object remove()
    // pre: the queue is not empty
    // post: the element at the head of the queue is removed and returned
    {
	Object result = data.elementAt(0);
	data.removeElementAt(0);
	return result;
    }
    /**
     * Remove a value from the head of the queue
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the head of the queue is removed and returned
     * </dl>
     * 
     * @return The value removed from the queue
     */
    public Object dequeue()
    // pre: the queue is not empty
    // post: the element at the head of the queue is removed and returned
    {
	return remove();
    }

    /**
     * Fetch the value at the head of the queue.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> the queue is not empty
     * <dt><b>Postcondition:</b><dd> the element at the head of the queue is returned
     * </dl>
     * 
     * @return Reference to the first value of the queue.
     */
    public Object peek()
    // pre: the queue is not empty
    // post: the element at the head of the queue is returned
    {
	return data.elementAt(0);
    }

    /**
     * Determine the number of elements within the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of elements in the queue.
     * </dl>
     * 
     * @return The number of elements within the queue.
     */
    public int size()
    // post: returns the number of elements in the queue
    {
	return data.size();
    }

    /**
     * Remove all the values from the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all elements from the queue.
     * </dl>
     */
    public void clear()
    // post: removes all elements from the queue
    {
	data.clear();
    }
    
    /**
     * Determine if the queue is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff the queue is empty
     * </dl>
     * 
     * @return True iff the queue is empty.
     */
    public boolean isEmpty()
    // post: returns true iff the queue is empty
    {
	return data.isEmpty();
    }

    /**
     * Construct a string representation of the queue.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of queue
     * </dl>
     * 
     * @return String representing the queue.
     */
    public String toString()
    // post: returns string representation of queue
    {
	StringBuffer s = new StringBuffer();
	int i;

	s.append("<QueueArray:");
	for (i = 0; i < data.size(); i++)
	{
	    s.append(" "+data.elementAt(i));
	}
	s.append(">");
	return s.toString();
    }
}

// Implementation of an iterator for elements of a singly linked list.
// (c) 1998 McGraw-Hill
package structure;
/**
 * An iterator for traversing the elements of a singly linked list.
 * The iterator traverses the list beginning at the head, and heads toward
 * tail.
 * <p>
 * Typical use:
 * <pre>
 *      List l = new SinglyLinkedList();
 *      // ...list gets built up...
 *      Iterator li = l.elements();
 *      while (li.hasMoreElements())
 *      {
 *          System.out.println(li.value());
 *          li.nextElement();
 *      }
 *      li.reset();
 *      while (li.hasMoreElements())
 *      { .... }
 * </pre>
 * @version $Id: SinglyLinkedListIterator.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
class SinglyLinkedListIterator implements Iterator
{
    /**
     * The reference to the currently considered element within the list.
     */
    protected SinglyLinkedListElement current;
    /**
     * The head of the list.
     */
    protected SinglyLinkedListElement head;

    /**
     * Construct an iterator that traverses the list beginning at t.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns an iterator that traverses a linked list.
     * </dl>
     * 
     * @param t The first element of the list to be traversed.
     */
    public SinglyLinkedListIterator(SinglyLinkedListElement t)
    // post: returns an iterator that traverses a linked list
    {
	head = t;
	reset();
    }
    
    /**
     * Reset iterator to beginning of the structure.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> the iterator is reset to beginning of the traversal
     * </dl>
     */
    public void reset()
    // post: resets the iterator to point to the head of the list
    {
	current = head;
    }

    /**
     * Determine if the iteration is finished.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if there is more structure to be viewed:
     *       ie, if value (nextElement) can return a useful value.
     * </dl>
     * 
     * @return True if the iterator has more elements to be considered.
     */
    public boolean hasMoreElements()
    // post: returns true iff there are unvisited elements
    {
	return current != null;
    }

    /**
     * Return current value and increment Iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> traversal has more elements
     * <dt><b>Postcondition:</b><dd> returns current value and increments the iterator
     * </dl>
     * 
     * @return The current value, before increment.
     */
    public Object nextElement()
    // pre: hasMoreElements()
    // post: returns value and advances iterator
    {
	Object temp = current.value();
	current = current.next();
	return temp;
    }

    /**
     * Return structure's current object reference.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> traversal has more elements
     * <dt><b>Postcondition:</b><dd> returns the current value referenced by the iterator 
     * </dl>
     * 
     * @return Object currently referenced.
     */
    public Object value()
    // pre: hasMoreElements()
    // post: returns the current element referenced by the iterator
    {
	return current.value();
    }
}

// An interface for Dictionaries, much like java.util.Dictionary.
// (c) 1998 McGraw-Hill

package structure;

/**
 * This interface describes a Dictionary --- a collection of key-value
 * pairs.  The interface is motivated largely by the interface found in
 * java.util.  In this model, every entry of the dictionary is identified
 * by a unique key.  This key is associated with a value, which may or 
 * may not be unique.  The values associated with keys may be modified, but
 * the keys may not.  (Key-value pairs may be removed and the value
 * reinserted.)
 * <p>
 * Traversal through the structure is accomplished with two iterators,
 * elements, and keys.  These iterators are guaranteed to traverse the
 * structure in the same order, so that the key-value relationship may
 * be extracted by parallel iteration.
 * <p>
 * @version $Id: Dictionary.java,v 3.0 1998/01/12 16:03:23 bailey Exp bailey $
 * @author duane a. bailey
 */
public interface Dictionary extends Store
{
    /**
     * Enter a key-value pair into the dictionary.  if the key is already
     * in the dictionary, the old value is returned, and the old key-value
     * pair is replaced.  Otherwise null is returned.  The user is cautioned
     * that a null value returned may indicate there was no prior key-value
     * pair, or --- if null values are inserted --- that the key was 
     * previously associated with a null value.
     * <p>
     * 
     * <b>pre:</b> key is non-null
     * <b>post:</b> puts key-value pair in Dictionary, returns old value
     *
     * @param key The unique key in the dictionary.
     * @param value The (possibly null) value associated with key.
     * @return The prior value, or null if no prior value found.
     */
    public Object put(Object key, Object value);
    // pre: key is non-null
    // post: puts key-value pair in Dictionary, returns old value

    /**
     * Returns true if the value is associated with some key in the
     * dictionary.  This is often difficult to implement efficiently.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> returns true iff the dictionary contains the value
     * </dl>
     * 
     * @param value The value sought (possibly null).
     * @return True, if the value is associated with some key in 
     * dictionary.
     */
    public boolean contains(Object value);
    // pre: value is non-null
    // post: returns true iff the dictionary contains the value

    /**
     * Determine if the key is in the dictionary.  The key should
     * not be null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null
     * <dt><b>Postcondition:</b><dd> returns true iff the dictionary contains the key
     * </dl>
     * 
     * @param key A non-null key sought in the dictionary.
     * @return True iff the key is used in association with some value.
     */
    public boolean containsKey(Object key);
    // pre: key is non-null
    // post: returns true iff the dictionary contains the key

    /**
     * Remove a key-value pair, based on key.  The value is returned.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> removes an object "equal" to value within dictionary.
     * </dl>
     * 
     * @param key The key of the key-value pair to be removed.
     * @return The value associated with key, no longer in dictionary.
     */
    public Object remove(Object key);
    // pre: value is non-null
    // post: removes an object "equal" to value within dictionary
    
    /**
     * Retrieve the value associated with the key provided.
     * Be aware, the value may be null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> key is non-null
     * <dt><b>Postcondition:</b><dd> returns value associated with key, in dictionary
     * </dl>
     * 
     * @param key The key of the key-value pair sought.
     * @return The value associated with the key.
     */
    public Object get(Object key);
    // pre: key is non-null
    // post: returns value associated with key, in dictionary

    /**
     * Construct an iterator over the keys of the dictionary.
     * The order of the keys returned is not predictable, but it will
     * be consistent with that of the iterator from elements, provided
     * the dictionary is not modified.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator for traversing keys in dictionary
     * </dl>
     * 
     * @return An iterator over the keys of the dictionary.
     */
    public Iterator keys();
    // post: returns iterator for traversing keys in dictionary

    /**
     * Construct an iterator over the values of the dictionary.
     * The order of the values returned is not predictable, but it will
     * be consistent with that of the iterator returned from keys, provided
     * the dictionary is not modified.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator for traversing values in dictionary
     * </dl>
     * 
     * @return An iterator over the values of the dictionary.
     */
    public Iterator elements();
    // post: returns iterator for traversing values in dictionary

    /**
     * Determine the number of key-value pairs within the dictionary.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns number of elements in dictionary
     * </dl>
     * 
     * @return The number of key-value pairs within the dictionary.
     */
    public int size();
    // post: returns number of elements in dictionary
}

// An interface for LIFO/FIFO structures.
// (c) 1998 McGraw-Hill

package structure;

/**
 * Linear classes are contains that have completely determined
 * add and remove methods.  Classic examples are stacks and queues.
 * <p>
 * @version $Id: Linear.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 * @see structure.Stack
 * @see structure.Queue
 */
public interface Linear extends Store
{
    /**
     * Add a value to the structure.  The type of structure determines
     * the location of the value added.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> value is non-null
     * <dt><b>Postcondition:</b><dd> the value is added to the collection,
     *       the consistent replacement policy not specified.
     * </dl>
     * 
     * @param value The value to be added to the structure.
     */
    public void add(Object value);
    // pre: value is non-null
    // post: the value is added to the collection,
    //       the consistent replacement policy not specified.

    /**
     * Preview the object to be removed.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> structure is not empty
     * <dt><b>Postcondition:</b><dd> returns reference to next object to be removed.
     * </dl>
     *
     * @return A reference to the next object to be removed.
     */
    public Object peek();
    // pre: structure is not empty
    // post: returns reference to next object to be removed.

    /**
     * Remove a value from the structure.  The particular value
     * to be removed is determined by the structure.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> structure is not empty.
     * <dt><b>Postcondition:</b><dd> removes an object from store
     * </dl>
     * 
     * @return Value removed from structure.
     */
    public Object remove();
    // pre: structure is not empty.
    // post: removes an object from store
}

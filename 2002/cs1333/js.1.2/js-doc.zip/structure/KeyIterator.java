// Implementation of key- iterators for driving Association iterators.
// (c) 1998 McGraw-Hill
package structure;

/**
 * A private master iterator for filtering the key fields from
 * an Association-returning iterator.
 * Used to construct iterators over dictionaries.
 * <p>
 * @version $Id: KeyIterator.java,v 3.0 1998/01/12 16:03:23 bailey Exp $
 * @author duane a. bailey
 */
class KeyIterator implements Iterator
{
    /**
     * The underlying iterator.
     * The slave iterator provides the key iterator values which
     * are Associations.  The key iterator returns only the key-portion
     * of the Associations.	
     */
    protected Iterator slave;

    /**
     * Construct a new key iterator that filters the slave iterator,
     * an Association-returning iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> slave is a fully reset iterator over Association elements
     * <dt><b>Postcondition:</b><dd> creates a new iterator that returns keys of slave iterator
     * </dl>
     * 
     * @param slave The slave iterator.
     */
    public KeyIterator(Iterator slave)
    // pre: slave is a fully reset iterator over Association elements
    // post: creates a new iterator that returns keys of slave iterator
    {
	this.slave = slave;
    }

    /**
     * Resets the slave iterator (and thus the key iterator) to the
     * first association in the structure.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets iterator to point to first key
     * </dl>
     */
    public void reset()
    // post: resets iterator to point to first key
    {
	slave.reset();
    }

    /**
     * Returns true if an association is available for generating a key.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if current element is valid
     * </dl>
     * 
     * @return True if a valid key can be generated.
     */
    public boolean hasMoreElements()
    // post: returns true if current element is valid
    {
	return slave.hasMoreElements();
    }

    /**
     * Returns the current key, and increments the iterator.	
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current value and increments iterator
     * </dl>
     * 
     * @return The current key, before iterator is incremented.
     */
    public Object nextElement()
    // pre: hasMoreElements()
    // post: returns current value and increments iterator
    {
	Association pair = (Association)slave.nextElement();
	return pair.key();
    }

    /**
     * Returns the current key from the slave iterator.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> current value is valid
     * <dt><b>Postcondition:</b><dd> returns current value
     * </dl>
     * 
     * @return The current key associated with the iterator.
     */
    public Object value()
    // pre: current value is valid
    // post: returns current value
    {
	Association pair = (Association)slave.value();
	return pair.key();
    }
}
 

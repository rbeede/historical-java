// Graph, implemented with an Adjacency List
// (c) 1998 McGraw-Hill

package structure;

/**
 * Implementation of graph using adjacency lists.
 * Edges are stored in lists off of vertex structure.
 * Class is abstract: you must use GraphListDirected or 
 * GraphListUndirected to construct particular instances of graphs.
 * <p>
 * Typical usage:
 * <pre>
 *     Graph g = new GraphListDirected();
 *     g.add("harry");
 *     g.add("sally");
 *     g.addEdge("harry","sally","friendly");
 *     ...
 * </pre>
 * <p>
 * @version $Id: GraphList.java,v 3.2 1998/02/08 04:08:37 bailey Exp bailey $
 * @author duane a. bailey and kimberly tabtiang
 * @see GraphListDirected
 * @see GraphListUndirected
 * @see GraphMatrix
 */
abstract public class GraphList implements Graph
{
    /**
     * Dictionary associating vertex labels with vertex structures.
     */
    protected Dictionary dict;	// label to vertex dictionary
    /**
     * Whether or not graph is directed.
     */
    protected boolean directed;	// is graph directed?

    /**
     * Constructor of directed/undirected GraphList. Protected constructor.
     * <p>
     * @param dir True if graph is to be directed.
     */
    protected GraphList(boolean dir)
    // post: constructs an empty graph;
    //       graph is directed iff dir is true
    {
	dict = new Hashtable();
	directed = dir;
    }
    /**
     * Add a vertex to the graph.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label is a non-null label for vertex
     * <dt><b>Postcondition:</b><dd> a vertex with label is added to graph.
     *       if vertex with label is already in graph, no action.
     * </dl>
     * 
     * @param label Label of the vertex; should be non-null.
     */
    public void add(Object label)
    // pre: label is a non-null label for vertex
    // post: a vertex with label is added to graph;
    //       if vertex with label is already in graph, no action
    {
        if (dict.containsKey(label)) return; // vertex exists
        GraphListVertex v = new GraphListVertex(label);
        dict.put(label,v);
    }

    /**
     * Add an edge between two vertices within the graph.  Edge is directed
     * iff graph is directed.  Duplicate edges are silently replaced.
     * Labels on edges may be null.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vtx1 and vtx2 are labels of existing vertices
     * <dt><b>Postcondition:</b><dd> an edge (possibly directed) is inserted between
     *       vtx1 and vtx2.
     * </dl>
     * 
     * @param vtx1 First (or source, if directed) vertex.
     * @param vtx2 Second (or destination, if directed) vertex.
     * @param label Label associated with the edge.
     */
    abstract public void addEdge(Object v1, Object v2, Object label);
    // pre: v1 and v2 are labels of existing vertices
    // post: an edge (possibly directed) is inserted between v1 and v2
    //       if edge is new, it is labeled with label (can be null)

    /**
     * Remove a vertex from the graph.  Associated edges are also 
     * removed.  Non-vertices are silently ignored.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label is non-null vertex label
     * <dt><b>Postcondition:</b><dd> vertex with "equals" label is removed, if found
     * </dl>
     * 
     * @param label The label of the vertex within the graph.
     * @return The label associated with the vertex.
     */
    abstract public Object remove(Object label);
    // pre: label is non-null vertex label
    // post: vertex with "equals" label is removed, if found

    /**
     * Remove possible edge between vertices labeled vLabel1 and vLabel2.
     * Directed edges consider vLabel1 to be the source.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> vLabel1 and vLabel2 are labels of existing vertices
     * <dt><b>Postcondition:</b><dd> edge is removed, its label is returned
     * </dl>
     * 
     * @param vLabel1 First (or source, if directed) vertex.
     * @param vLabel2 Second (or destination, if directed) vertex.
     * @return The label associated with the edge removed.
     */
    abstract public Object removeEdge(Object vLabel1, Object vLabel2);
    // pre: vLabel1 and vLabel2 are labels of existing vertices
    // post: edge is removed, its label is returned

    /**
     * Get reference to actual label of vertex.  Vertex labels are matched
     * using their equals method, which may or may not test for actual
     * equivalence.  Result remains part of graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns actual label of indicated vertex
     * </dl>
     * 
     * @param label The label of the vertex sought.
     * @return The actual label, or null if none is found.
     */
    public Object get(Object label)
    // pre: label labels a valid vertex
    // post: returns actual label of vertex with label "equals" 'label'
    {
	Assert.condition(dict.containsKey(label), "Vertex exists");
	return ((GraphListVertex)dict.get(label)).label();
    }

    /**
     * Get reference to actual edge.  Edge is identified by
     * the labels on associated vertices.  If edge is directed, the
     * label1 indicates source.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns actual edge between vertices.
     * </dl>
     * 
     * @param label1 The first (or source, if directed) vertex.
     * @param label2 The second (or destination, if directed) vertex.
     * @return The edge, if found, or null.
     */
    public Edge getEdge(Object label1, Object label2)
    // post: returns actual edge between vertices.
    {    
	Assert.condition(dict.containsKey(label1), "Vertex exists");
	Edge e = new Edge(get(label1),get(label2), null, directed); 
	return ((GraphListVertex) dict.get(label1)).getEdge(e);
    }

    /**
     * Test for vertex membership.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff vertex with "equals" label exists.
     * </dl>
     * 
     * @param label The label of the vertex sought.
     * @return True iff vertex with matching label is found.
     */
    public boolean contains(Object label)
    // post: returns true iff vertex with "equals" label exits.
    {
	return dict.containsKey(label);   
    }

    /**
     * Test for edge membership.  If edges are directed, vLabel1
     * indicates source.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff edge with "equals" label exists
     * </dl>
     * 
     * @param vLabel1 First (or source, if directed) vertex.
     * @param vLabel2 Second (or destination, if directed) vertex.
     * @return True iff the edge exists within the graph.
     */
    public boolean containsEdge(Object vLabel1, Object vLabel2)
    // post: returns true iff edge with "equals" label exists
    {
	Assert.condition(dict.containsKey(vLabel1), "Vertex exists");
	Edge e = new Edge(vLabel1, vLabel2, null, directed); 
	return ((GraphListVertex) dict.get(vLabel1)).containsEdge(e);
    }

    /**
     * Test and set visited flag of vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> sets visited flag on vertex, returns previous value
     * </dl>
     * 
     * @param label Label of vertex to be visited.
     * @return Previous value of visited flag on vertex.
     */
    public boolean visit(Object label)
    // post: sets visited flag on vertex, returns previous value
    {
	return ((GraphListVertex)dict.get(label)).visit();
    }
    
    /**
     * Test and set visited flag of edge.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> sets visited flag on edge; returns previous value
     * </dl>
     * 
     * @param e Edge object that is part of graph.
     * @return Previous value of the Edge's visited flag.
     */
    public boolean visitEdge(Edge e)
    // pre: sets visited flag on edge; returns previous value
    {
	return e.visit();
    }

    /**
     * Return visited flag of vertex.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns visited flag on labeled vertex
     * </dl>
     * 
     * @param label Label of vertex.
     * @return True if vertex has been visited.
     */
    public boolean isVisited(Object label)
    // post: sets visited flag on vertex, returns previous value
    {
	return ((GraphListVertex)dict.get(label)).isVisited();
    }

    /**
     * Return visited flag of edge.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns visited flag on edge between vertices
     * </dl>
     * 
     * @param e Edge of graph to be considered.
     * @return True if the edge has been visited.
     */
    public boolean isVisitedEdge(Edge e)
    // post: returns visited flag on edge between vertices
    {
	return e.isVisited();
    }

    /**
     * Clear visited flags of edges and vertices.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets visited flags to false
     * </dl>
     */
    public void reset()
    // post: resets visited flags
    {
	// reset the vertices
	Iterator vi = dict.elements();
	while (vi.hasMoreElements())
	{
	    Vertex vtx = (Vertex)vi.nextElement();
	    vtx.reset();
	}
	// reset the edges
	Iterator ei = edges();
	while (ei.hasMoreElements())
	{
	    Edge e = (Edge)ei.nextElement();
	    e.reset();
	}
    }

    /**
     * Determine number of vertices within graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of vertices in graph
     * </dl>
     * 
     * @return The number of vertices within graph.
     */
    public int size()
    // post: returns the number of vertices in graph
    { 
	return dict.size(); 
    }

    /**
     * Determine out degree of vertex.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label labels an existing vertex
     * <dt><b>Postcondition:</b><dd> returns the number of vertices adjacent to vertex
     * </dl>
     *
     * @param label Label associated with vertex.
     * @return The number of edges with this vertex as source.
     */
    public int degree(Object label)
    // pre: label is a label of a vertex
    // post: returns the degree of vertex
    {
	Assert.condition(dict.containsKey(label), "Vertex exists.");
	return ((GraphListVertex) dict.get(label)).degree();
    }

    /**
     * Determine the number of edges in graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the number of edges in graph
     * </dl>
     * 
     * @return Number of edges in graph.
     */
    abstract public int edgeCount();
    // post: returns the number of edges in graph

    /**
     * Construct vertex iterator.  Vertices are not visited in 
     * any guaranteed order.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator across all vertices of graph
     * </dl>
     * 
     * @return Iterator traversing vertices in graph.
     */
    public Iterator elements()
    // post: returns iterator across all vertices of graph
    {
	return dict.keys();
    }

    /**
     * Construct an adjacent vertex iterator.   Adjacent vertices
     * (those on destination of edge, if directed) are considered,
     * but not in any guaranteed order.
     * <p>
     * <dl>
     * <dt><b>Precondition:</b><dd> label is label of vertex in graph
     * <dt><b>Postcondition:</b><dd> returns iterator over vertices adj. to vertex
     *       each edge beginning at label visited exactly once
     * </dl>
     * 
     * @param label Label of the vertex.
     * @return Iterator traversing the adjacent vertices of labeled vertex.
     */
    public Iterator neighbors(Object label)
    // pre: label labels an existing vertex
    // post: returns an iterator traversing neighbor vertices
    {
	// return towns adjacent to vertex labeled label
	Assert.condition(dict.containsKey(label), "Vertex exists");
	return ((GraphListVertex) dict.get(label)).adjacentVertices();
    }

    /**
     * Construct an iterator over all edges.  Every directed/undirected
     * edge is considered exactly once.  Order is not guaranteed.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator across edges of graph
     *       iterator returns edges; each edge visited once
     * </dl>
     * 
     * @return Iterator over edges.
     */
    public Iterator edges()
    // post: returns iterator over all edges
    {
	return new GraphListEIterator(dict);
    }

    /**
     * Remove all vertices (and thus, edges) of the graph.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes all vertices from graph
     * </dl>
     */
    public void clear()
    // post: removes all vertices from graph
    {
      dict.clear();
    }

    /**
     * Determine if graph is empty.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if graph contains no vertices
     * </dl>
     * 
     * @return True iff there are no vertices in graph.
     */
    public boolean isEmpty()
    // post: returns true iff graph contains no vertices
    {
      return dict.isEmpty();
    }

    /**
     * Determine if graph is directed.
     * <p>
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if edges of graph are directed
     * </dl>
     * 
     * @return True iff the graph is directed.
     */
    public boolean isDirected()
    // post: returns true iff graph is directed
    {
	return directed;
    }
}

/**
 * 
 * @version $Id: GraphList.java,v 3.2 1998/02/08 04:08:37 bailey Exp bailey $
 * @author duane a. bailey
 */
class GraphListEIterator implements Iterator
{
    protected Iterator edges;

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new iterator across edges of
     *       vertices within dictionary
     * </dl>
     * 
     * @param dict 
     */
    public GraphListEIterator(Dictionary dict)
    // post: constructs a new iterator across edges of
    //       vertices within dictionary
    {
	List l = new DoublyLinkedList();
	Iterator dictIterator = dict.elements();
	while (dictIterator.hasMoreElements())
	{
	    GraphListVertex vtx =
		(GraphListVertex)dictIterator.nextElement();
	    Iterator vtxIterator = vtx.adjacentEdges();
	    while (vtxIterator.hasMoreElements())
	    {
		Edge e = (Edge)vtxIterator.nextElement();
		if (vtx.label().equals(e.here())) l.addToTail(e);
	    }
	}
	edges = l.elements();
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets the iterator to first edge
     * </dl>
     * 
     */
    public void reset()
    // post: resets the iterator to first edge
    {
	edges.reset();
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true iff current element is valid
     * </dl>
     * 
     * @return 
     */
    public boolean hasMoreElements()
    // post: returns true iff current element is valid
    {
	return edges.hasMoreElements();
    }

    /**
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns the current element
     * </dl>
     * 
     * @return 
     */
    public Object value()
    // pre: hasMoreElements()
    // post: returns the current element
    {
	return edges.value();
    }

    /**
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements()
     * <dt><b>Postcondition:</b><dd> returns current value and increments iterator
     * </dl>
     * 
     * @return 
     */
    public Object nextElement()
    // pre: hasMoreElements()
    // post: returns current value and increments iterator
    {
	return edges.nextElement();
    }
}

/**
 * 
 * @version $Id: GraphList.java,v 3.2 1998/02/08 04:08:37 bailey Exp bailey $
 * @author duane a. bailey
 */
class GraphListVertex extends Vertex
{
    protected Collection adjacencies; // adjacent edges

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> constructs a new vertex, not incident to any edge
     * </dl>
     * 
     * @param key 
     */
    public GraphListVertex(Object key)
    // post: constructs a new vertex, not incident to any edge
    {
	super(key); // init Vertex fields
	// new adjacency list
	adjacencies = new SinglyLinkedList();
    }

    /**
     * <dl>
     * <dt><b>Precondition:</b><dd> e is an edge that mentions this vertex
     * <dt><b>Postcondition:</b><dd> adds edge to this vertex's adjacency list
     * </dl>
     * 
     * @param e 
     */
    public void addEdge(Edge e)
    // pre: e is an edge that mentions this vertex
    // post: adds edge to this vertex's adjacency list
    {
	if (!containsEdge(e)) adjacencies.add(e);
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if e appears on adjacency list
     * </dl>
     * 
     * @param e 
     * @return 
     */
    public boolean containsEdge(Edge e)
    // post: returns true if e appears on adjacency list
    {
	return adjacencies.contains(e);
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> removes and returns adjacent edge "equal" to e
     * </dl>
     * 
     * @param e 
     * @return 
     */
    public Edge removeEdge(Edge e)
    // post: removes and returns adjacent edge "equal" to e
    {
	return (Edge)adjacencies.remove(e);
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the edge that "equals" e, or null
     * </dl>
     * 
     * @param e 
     * @return 
     */
    public Edge getEdge(Edge e)
    // post: returns the edge that "equals" e, or null
    {
	Iterator edges = adjacencies.elements();
	while (edges.hasMoreElements())
	{
	    Edge adjE = (Edge)edges.nextElement();
	    if (e.equals(adjE)) return adjE;
	}
	return null;
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns the degree of this node
     * </dl>
     * 
     * @return 
     */
    public int degree()
    // post: returns the degree of this node
    { 
	return adjacencies.size(); 
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator over adj. vertices
     * </dl>
     * 
     * @return 
     */
    public Iterator adjacentVertices()
    // post: returns iterator over adj. vertices
    {
	return new GraphListAIterator(adjacentEdges(), label());
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns iterator over adj. edges
     * </dl>
     * 
     * @return 
     */
    public Iterator adjacentEdges()
    // post: returns iterator over adj. edges
    {
	return adjacencies.elements();
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns string representation of vertex
     * </dl>
     * 
     * @return 
     */
    public String toString()
    // post: returns string representation of vertex
    {
	return "<GraphListVertex: "+label()+">";
    }
}

/**
 * 
 * @version $Id: GraphList.java,v 3.2 1998/02/08 04:08:37 bailey Exp bailey $
 * @author duane a. bailey
 */
class GraphListAIterator implements Iterator
{
    protected Iterator edges;
    protected Object vertex;

    /**
     * <dl>
     * <dt><b>Precondition:</b><dd> i is an edge iterator
     * <dt><b>Postcondition:</b><dd> returns iterator over vertices adj. to v.
     * </dl>
     * 
     * @param i 
     * @param v 
     */
    public GraphListAIterator(Iterator i, Object v)
    // pre: i is an edge iterator
    // post: returns iterator over vertices adj. to v.
    {
	edges = i;
	vertex = v;
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> resets iterator
     * </dl>
     * 
     */
    public void reset()
    // post: resets iterator
    {
	edges.reset();
    }

    /**
     * <dl>
     * <dt><b>Postcondition:</b><dd> returns true if more adj. vertices to traverse
     * </dl>
     * 
     * @return 
     */
    public boolean hasMoreElements()
    // post: returns true if more adj. vertices to traverse
    {
	return edges.hasMoreElements();
    }

    /**
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements
     * <dt><b>Postcondition:</b><dd> returns the next adjacent vertex
     * </dl>
     * 
     * @return 
     */
    public Object nextElement()
    // pre: hasMoreElements
    // post: returns the next adjacent vertex
    {
	Edge e = (Edge)edges.nextElement();
	if (vertex.equals(e.here())) 
	{
	    return e.there();
	} else { // N.B could be vertex if self-loop edge
	    return e.here();
	}
    }

    /**
     * <dl>
     * <dt><b>Precondition:</b><dd> hasMoreElements
     * <dt><b>Postcondition:</b><dd> returns the current adj. vertex
     * </dl>
     * 
     * @return 
     */
    public Object value()
    // pre: hasMoreElements
    // post: returns the current adj. vertex
    {
	Edge e = (Edge)edges.value();
	if (vertex.equals(e.here())) 
	{
	    return e.there();
	} else { // NB. could be vertex if self-loop edge
	    return e.here();
	}
    }
}

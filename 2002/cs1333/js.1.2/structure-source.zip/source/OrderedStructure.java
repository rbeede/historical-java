// Interface for container classes that manipulated ordered structures.
// (c) 1998 McGraw-Hill

package structure;

public interface OrderedStructure extends Collection
{
}

// An interface for Dictionaries whose keys are ordered.
// (c) 1998 McGraw-Hill

package structure;

public interface OrderedDictionary extends Dictionary
{
}
